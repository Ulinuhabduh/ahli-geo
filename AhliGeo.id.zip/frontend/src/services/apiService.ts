
import {
  Project, Expert, User, ChatSession, Payment, Proposal,
  ProjectStatus, Skill, ChatMessage
} from '../../types';

const BASE_URL = 'http://localhost:3001/api/v1'; // Your backend API base URL

// Helper to get the auth token from localStorage
const getAuthToken = (): string | null => {
  return localStorage.getItem('ahliGeoToken');
};

// Helper for making API requests
interface RequestOptions extends RequestInit {
  includeAuth?: boolean;
}

const apiRequest = async <T>(endpoint: string, options: RequestOptions = {}): Promise<T> => {
  const { includeAuth = true, ...fetchOptions } = options;
  const headers = new Headers(fetchOptions.headers || {});

  // --- PERBAIKI LOGIKA INI ---
  // Jangan set Content-Type jika body adalah FormData.
  // Browser akan menanganinya secara otomatis.
  if (!(fetchOptions.body instanceof FormData)) {
    if (!headers.has('Content-Type')) {
        headers.append('Content-Type', 'application/json');
    }
  }
  // --- AKHIR PERBAIKAN ---

  if (includeAuth) {
    const token = getAuthToken(); // Asumsi getAuthToken() sudah ada
    if (token) {
      headers.append('Authorization', `Bearer ${token}`);
    }
  }

  const response = await fetch(`${BASE_URL}${endpoint}`, {
    ...fetchOptions,
    headers,
  });

  if (!response.ok) {
    let errorData;
    try {
      errorData = await response.json();
    } catch (e) {
      errorData = { message: response.statusText || 'An unknown API error occurred' };
    }
    console.error('API Error:', response.status, errorData);
    throw new Error(errorData.message || `API request failed with status ${response.status}`);
  }

  const contentType = response.headers.get("content-type");
  if (response.status === 204) { // Handle No Content
    return null as unknown as T;
  }
  if (contentType && contentType.indexOf("application/json") !== -1) {
    return response.json() as Promise<T>;
  }
  return response.text() as unknown as T; // Or handle as appropriate
};


// --- User & Auth ---
export const loginUser = async (email: string, passwordCandidate: string): Promise<{ user: User, token: string }> => {
  return apiRequest<{ user: User, token: string }>(`/auth/login`, {
    method: 'POST',
    body: JSON.stringify({ email, password: passwordCandidate }),
    includeAuth: false,
  });
};

// Define more specific types for registration payload
interface ExpertRegistrationProfileData {
  headline: string;
  location: string;
  experienceYears: number;
  bio: string;
  profileImageUrl?: string;
  hourlyRate?: number;
  skillIds: string[];      // Array of skill IDs
  softwareIds: string[];  // Array of software IDs
}

interface ClientRegistrationProfileData {
  companyName?: string;
}

type UserRegistrationCore = Omit<User, 'id' | 'profileSetupCompleted'> & { password?: string };

// This represents the data structure specifically sent by RegisterPage.tsx
export type ComprehensiveRegistrationData = UserRegistrationCore & (
  ({ role: 'expert' } & ExpertRegistrationProfileData) |
  ({ role: 'client' } & ClientRegistrationProfileData) |
  ({ role: 'admin' } & {})
);


/**
 * Registers a new user.
 * For experts, the registrationData MUST include:
 * - Basic user info (name, email, password, role: 'expert')
 * - Expert profile info: headline, location, experienceYears, bio,
 *   profileImageUrl (optional), hourlyRate (optional),
 *   skillIds (array of strings), softwareIds (array of strings).
 * 
 * The backend is responsible for:
 * 1. Creating a record in the 'users' table.
 * 2. If role is 'expert', creating a linked record in the 'expert_profiles' table
 *    using the expert-specific data.
 * 3. If role is 'expert', creating entries in join tables (e.g., 'expert_skills', 'expert_software')
 *    using skillIds and softwareIds to link to the 'expert_profiles' record.
 * 4. Returning the created user object and a token.
 */
export const registerUser = async (
  registrationData: ComprehensiveRegistrationData
): Promise<{ user: User, token?: string }> => {
  // Log the payload being sent to the backend for debugging
  console.log("Sending registration data to backend:", JSON.stringify(registrationData, null, 2));

  return apiRequest<{ user: User, token?: string }>(`/auth/register`, {
    method: 'POST',
    body: JSON.stringify(registrationData),
    includeAuth: false,
  });
};

export const updateUserProfile = async (
  userId: string,
  profileData: Partial<User & Expert>
): Promise<User> => {
  // Endpoint ini sekarang khusus untuk update profil expert yang sedang login
  // dan harus cocok dengan rute di backend (expertRoutes.js)
  const endpoint = `/experts/profile`;

  return apiRequest<User>(endpoint, {
    method: 'PUT', // Menggunakan PUT untuk update
    body: JSON.stringify(profileData),
    includeAuth: true,
  });
};

export const fetchCurrentUser = async (): Promise<User> => {
  return apiRequest<User>('/auth/me', {
    method: 'GET',
    includeAuth: true,
  });
};

// --- Projects ---
interface ProjectFilters {
  searchTerm?: string;
  selectedSkills?: string[];
  selectedSoftware?: string[];
  locationType?: string;
  limit?: number;
  clientId?: string;
  status?: ProjectStatus | '';
}

export const fetchProjects = async (filters: ProjectFilters = {}): Promise<Project[]> => {
  // Gunakan URLSearchParams untuk membangun string query
  const params = new URLSearchParams();

  // Tambahkan setiap filter ke params jika nilainya ada
  if (filters.searchTerm) {
    params.append('searchTerm', filters.searchTerm);
  }
  if (filters.locationType) {
    params.append('locationType', filters.locationType);
  }
  if (filters.clientId) {
    params.append('clientId', filters.clientId);
  }
  if (filters.status) {
    params.append('status', filters.status);
  }
  if (filters.limit) {
    params.append('limit', filters.limit.toString());
  }

  // Untuk array, loop dan append satu per satu
  if (filters.selectedSkills && filters.selectedSkills.length > 0) {
    filters.selectedSkills.forEach(skillId => params.append('skills', skillId));
  }
  if (filters.selectedSoftware && filters.selectedSoftware.length > 0) {
    filters.selectedSoftware.forEach(softwareId => params.append('software', softwareId));
  }

  // Ubah params menjadi string.
  const queryString = params.toString();

  // Bangun endpoint final, tambahkan '?' hanya jika ada query string.
  const endpoint = `/projects${queryString ? `?${queryString}` : ''}`;

  // Tambahkan log untuk debugging
  console.log("Requesting projects from endpoint:", endpoint);

  // **GUNAKAN apiRequest HELPER ANDA**
  return apiRequest<Project[]>(endpoint, {
    method: 'GET',
    includeAuth: false // Atau true jika Anda ingin hanya user terotentikasi yang bisa melihat
  });
};

export const fetchProjectById = async (projectId: string): Promise<Project | null> => {
  try {
    return await apiRequest<Project>(`/projects/${projectId}`, { method: 'GET', includeAuth: false });
  } catch (error: any) {
    if (error.message.includes('404') || error.message.toLowerCase().includes('not found')) return null;
    throw error;
  }
};

export const postProject = async (
  projectData: Omit<Project, 'id' | 'postedDate' | 'proposalsCount' | 'status'>,
  _clientUser: User
): Promise<Project> => {
  return apiRequest<Project>(`/projects`, {
    method: 'POST',
    body: JSON.stringify(projectData),
    includeAuth: true,
  });
};

export const updateProject = async (
  projectId: string,
  projectData: Partial<Project>
): Promise<Project> => {
  return apiRequest<Project>(`/projects/${projectId}`, {
    method: 'PUT',
    body: JSON.stringify(projectData),
    includeAuth: true,
  });
};

// --- Experts ---
interface ExpertFilters {
  searchTerm?: string;
  selectedSkills?: string[];
  selectedSoftware?: string[];
  minExperience?: number;
  showVerifiedOnly?: boolean;
  limit?: number;
}

export const fetchExperts = async (filters: ExpertFilters = {}): Promise<Expert[]> => {
  const queryParams = new URLSearchParams();
  if (filters.searchTerm) queryParams.append('search', filters.searchTerm);
  if (filters.selectedSkills && filters.selectedSkills.length > 0) {
    filters.selectedSkills.forEach(skillId => queryParams.append('skills', skillId));
  }
  if (filters.selectedSoftware && filters.selectedSoftware.length > 0) {
    filters.selectedSoftware.forEach(softwareId => queryParams.append('software', softwareId));
  }
  if (filters.minExperience !== undefined) queryParams.append('minExperience', filters.minExperience.toString());
  if (filters.showVerifiedOnly) queryParams.append('verified', 'true');
  if (filters.limit) queryParams.append('limit', filters.limit.toString());

  return apiRequest<Expert[]>(`/experts?${queryParams.toString()}`, { method: 'GET', includeAuth: false });
};

export const fetchExpertById = async (expertId: string): Promise<Expert | null> => {
  try {
    return await apiRequest<Expert>(`/experts/${expertId}`, { method: 'GET', includeAuth: false });
  } catch (error: any) {
    if (error.message.includes('404') || error.message.toLowerCase().includes('not found')) return null;
    throw error;
  }
};

// --- Skills, Software, Locations (Master Data) ---
export const fetchAllSkills = async (): Promise<Skill[]> => {
  return apiRequest<Skill[]>('/master/skills', { method: 'GET', includeAuth: false });
};

export const fetchAllSoftware = async (): Promise<Skill[]> => {
  return apiRequest<Skill[]>('/master/software', { method: 'GET', includeAuth: false });
};

export const fetchAllLocations = async (): Promise<string[]> => {
  return apiRequest<string[]>('/master/locations', { method: 'GET', includeAuth: false });
};

export const fetchExpertApplications = async (expertId: string): Promise<Proposal[]> => {
  return apiRequest<Proposal[]>(`/proposals/by-expert/${expertId}`, {
    method: 'GET',
    includeAuth: true
  });
};

export const checkHasApplied = async (projectId: string): Promise<boolean> => {
  try {
    const response = await apiRequest<{ hasApplied: boolean }>(`/proposals/check/${projectId}`, {
      method: 'GET',
      includeAuth: true,
    });
    return response.hasApplied;
  } catch (error) {
    // Jika terjadi error (misal, 403 jika bukan expert), anggap saja tidak bisa apply
    console.error("Error checking application status:", error);
    return true; // Return true untuk menonaktifkan tombol jika ada error
  }
};

export const fetchMyApplications = async (): Promise<Proposal[]> => {
  return apiRequest<Proposal[]>('/proposals/my-applications', {
    method: 'GET',
    includeAuth: true,
  });
};

// --- Payments ---
export const makePayment = async (
  paymentData: Omit<Payment, 'id' | 'paymentDate' | 'status' | 'transactionId' | 'expertId'>,
  _project: Project,
  _clientUser: User
): Promise<Payment> => {
  return apiRequest<Payment>(`/payments`, {
    method: 'POST',
    body: JSON.stringify(paymentData),
    includeAuth: true,
  });
};

// --- Chat ---
export const fetchChatSession = async (
  targetType: 'expert' | 'project',
  targetId: string,
  _currentUserId: string,
  _currentUserName: string
): Promise<ChatSession> => {
  return apiRequest<ChatSession>(`/chat/session/${targetType}/${targetId}`, {
    method: 'GET',
    includeAuth: true,
  });
};

export const acceptProposal = async (
  proposalId: string,
  projectId: string,
  expertId: string
): Promise<{ success: boolean; message: string }> => {
  // Endpoint ini harus cocok dengan yang Anda definisikan di proposalRoutes.js
  const endpoint = `/proposals/${proposalId}/accept`;

  return apiRequest<{ success: boolean; message: string }>(endpoint, {
    method: 'PUT',
    // Kirim projectId dan expertId di dalam body karena controller kita membutuhkannya
    body: JSON.stringify({ projectId, expertId }),
    includeAuth: true,
  });
};

export const fetchProposalsForProject = async (projectId: string): Promise<Proposal[]> => {
  // Endpoint ini harus cocok dengan yang Anda definisikan di proposalRoutes.js
  const endpoint = `/proposals/project/${projectId}`;

  return apiRequest<Proposal[]>(endpoint, {
    method: 'GET',
    includeAuth: true, // Hanya client pemilik proyek yang bisa melihat, otorisasi di backend
  });
};

export const submitProposal = async (
  proposalData: { projectId: string, coverLetter: string, proposedRate?: number }
): Promise<Proposal> => {
  return apiRequest<Proposal>('/proposals', {
    method: 'POST',
    body: JSON.stringify(proposalData),
    includeAuth: true,
  });
};

export const sendInvitation = async (expertId: string, projectId: string): Promise<any> => {
  return apiRequest('/notifications/invitations', {
    method: 'POST',
    body: JSON.stringify({ expertId, projectId }),
    includeAuth: true,
  });
};

export const fetchMyNotifications = async (): Promise<Notification[]> => { // Asumsi Anda punya tipe Notification
  return apiRequest<Notification[]>('/notifications', {
    method: 'GET',
    includeAuth: true,
  });
};

export const initiateChat = async (recipientId: string): Promise<{ sessionId: string }> => {
  return apiRequest('/chat/sessions/initiate', {
    method: 'POST',
    body: JSON.stringify({ recipientId }),
    includeAuth: true
  });
};

export const getMyChatSessions = async (): Promise<ChatSession[]> => {
  return apiRequest('/chat/sessions', { includeAuth: true });
};

export const getMessages = async (sessionId: string): Promise<ChatMessage[]> => {
  return apiRequest(`/chat/sessions/${sessionId}/messages`, { includeAuth: true });
};

export const sendMessage = async (sessionId: string, messageText: string): Promise<ChatMessage> => {
  return apiRequest(`/chat/sessions/${sessionId}/messages`, {
    method: 'POST',
    body: JSON.stringify({ messageText }),
    includeAuth: true
  });
};

export const createPaymentForProposal = async (
  proposalId: string
): Promise<{ paymentId: string; transactionToken: string }> => {
  const endpoint = `/payments/proposal/${proposalId}`; // This should match your new backend route

  return apiRequest<{ paymentId: string; transactionToken: string }>(endpoint, {
    method: 'POST',
    includeAuth: true,
  });
};

export const submitDelivery = async (projectId: string, deliveryData: { deliveryText: string; deliveryAttachments?: any[] }): Promise<Project> => {
  return apiRequest(`/projects/${projectId}/deliver`, {
    method: 'POST',
    body: JSON.stringify(deliveryData),
    includeAuth: true,
  });
};

export const completeProject = async (projectId: string): Promise<Project> => {
  return apiRequest(`/projects/${projectId}/complete`, {
    method: 'POST',
    includeAuth: true,
  });
};

export const createReview = async (reviewData: { projectId: string; rating: number; comment: string; }): Promise<any> => {
  return apiRequest('/reviews', {
    method: 'POST',
    body: JSON.stringify(reviewData),
    includeAuth: true,
  });
};

export const getReviewsForUser = async (userId: string): Promise< Review[]> => {
  return apiRequest(`/reviews/user/${userId}`, { includeAuth: false });
};

// --- Admin Functions ---

export const adminGetAllUsers = async (): Promise<User[]> => {
  // Ganti 'await api.get(...)' dengan 'apiRequest<...>'
  return apiRequest<User[]>('/admin/users', {
    method: 'GET',
    includeAuth: true, // Admin routes require authentication
  });
};

export const adminUpdateUser = async (userId: string, data: Partial<User>): Promise<User> => {
  // Ganti 'await api.put(...)' dengan 'apiRequest<...>'
  return apiRequest<User>(`/admin/users/${userId}`, {
    method: 'PUT',
    body: JSON.stringify(data),
    includeAuth: true,
  });
};

export const adminDeleteUser = async (userId: string): Promise<void> => {
  // Ganti 'await api.delete(...)' dengan 'apiRequest<...>'
  // Untuk DELETE, kita tidak mengharapkan konten balasan, jadi <void> sudah pas.
  return apiRequest<void>(`/admin/users/${userId}`, {
    method: 'DELETE',
    includeAuth: true,
  });
};

export const adminRestoreUser = async (userId: string): Promise<User> => {
  // Kita mengharapkan backend mengembalikan user yang sudah direstore
  const response = await apiRequest<{ message: string, user: User }>(`/admin/users/${userId}/restore`, {
    method: 'PUT', // Menggunakan PUT karena kita mengupdate state resource
    includeAuth: true,
  });
  return response.user; // Kembalikan objek user yang diperbarui dari respons
};

export const adminGetAllProjects = async (filters: { status?: string, searchTerm?: string } = {}): Promise<Project[]> => {
  const params = new URLSearchParams();
  if (filters.status) {
    params.append('status', filters.status);
  }
  if (filters.searchTerm) {
    params.append('searchTerm', filters.searchTerm);
  }

  const queryString = params.toString();
  const endpoint = `/admin/projects${queryString ? `?${queryString}` : ''}`;

  return apiRequest<Project[]>(endpoint, {
    method: 'GET',
    includeAuth: true,
  });
};

export const adminUpdateProjectStatus = async (projectId: string, status: string): Promise<Project> => {
  return apiRequest<Project>(`/admin/projects/${projectId}/status`, {
    method: 'PUT',
    body: JSON.stringify({ status }),
    includeAuth: true,
  });
};

export const adminGetAllExpertsList = async (): Promise<{ id: string; name: string }[]> => {
  return apiRequest<{ id: string; name: string }[]>('/admin/list/experts', {
    method: 'GET',
    includeAuth: true,
  });
};

export const adminReassignExpert = async (projectId: string, newExpertId: string): Promise<{ message: string, project: Project }> => {
  return apiRequest<{ message: string, project: Project }>(`/admin/projects/${projectId}/reassign`, {
    method: 'PUT',
    body: JSON.stringify({ newExpertId }),
    includeAuth: true,
  });
};

export const createNewSkill = async (data: { name: string }): Promise<Skill> => {
  // Pastikan includeAuth: true
  return apiRequest('/master/skills', { method: 'POST', body: JSON.stringify(data)});
};

export const createNewSoftware = async (data: { name: string }): Promise<Skill> => {
  return apiRequest('/master/software', { method: 'POST', body: JSON.stringify(data)});
};

// frontend/src/services/apiService.ts
export const uploadProfileImage = async (formData: FormData): Promise<{ imageUrl: string }> => {
  // Panggil apiRequest, yang merupakan pembungkus untuk 'fetch'
  return apiRequest('/master/upload-image', { 
    method: 'POST', 
    body: formData, 
    includeAuth: true, 
  });
};

// Di dalam file: frontend/src/services/apiService.ts

// Definisikan tipe untuk data payout agar lebih aman
interface PayoutAccountData {
  bankName: string;
  accountHolderName: string;
  accountNumber: string;
}

// Definisikan tipe untuk respons dari backend, termasuk ID
interface PayoutAccountResponse extends PayoutAccountData {
  id: string;
  expertId: string;
}

// Fungsi untuk mengambil detail rekening payout yang sedang login
export const getPayoutAccount = async (): Promise<PayoutAccountResponse | null> => {
  try {
    return await apiRequest<PayoutAccountResponse>('/payouts/account', {
      method: 'GET',
      includeAuth: true,
    });
  } catch (error: any) {
    // --- PERBAIKAN DI SINI ---
    // Cek apakah pesan error spesifik dari backend (yang menandakan 404)
    if (error.message === 'Payout account not found.') { 
      return null; // Jika akun tidak ditemukan, kembalikan null tanpa melempar error
    }
    // Untuk semua error lain (misal: 500, jaringan), lempar error tersebut
    throw error; 
    // --- AKHIR PERBAIKAN ---
  }
};

// Fungsi untuk menyimpan atau memperbarui detail rekening payout
export const savePayoutAccount = async (data: PayoutAccountData): Promise<PayoutAccountResponse> => {
  // Endpoint ini juga harus cocok dengan yang di backend
  return apiRequest<PayoutAccountResponse>('/payouts/account', {
    method: 'POST',
    body: JSON.stringify(data),
    includeAuth: true,
  });
};