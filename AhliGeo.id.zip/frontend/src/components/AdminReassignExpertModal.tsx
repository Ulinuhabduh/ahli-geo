// frontend/src/components/AdminReassignExpertModal.tsx (LENGKAP DAN DIPERBARUI)

import React, { useState, useEffect } from 'react';
import { adminGetAllExpertsList } from '../services/apiService';
import { Project } from '../../types';
import Spinner from './Spinner';

interface AdminReassignExpertModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: (newExpertId: string) => Promise<void>;
    project: Project | null;
}

const AdminReassignExpertModal: React.FC<AdminReassignExpertModalProps> = ({
    isOpen,
    onClose,
    onConfirm,
    project
}) => {
    const [experts, setExperts] = useState<{ id: string, name: string }[]>([]);
    const [selectedExpert, setSelectedExpert] = useState<string>('');
    const [loading, setLoading] = useState<boolean>(false);
    const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

    useEffect(() => {
        if (isOpen) {
            setLoading(true);
            adminGetAllExpertsList()
                .then(data => {
                    setExperts(data); // Tampilkan semua expert

                    // Set pilihan default ke expert yang sedang ditugaskan,
                    // atau expert pertama jika tidak ada yang ditugaskan
                    if (project?.assignedExpertId) {
                        setSelectedExpert(project.assignedExpertId);
                    } else if (data.length > 0) {
                        setSelectedExpert(data[0].id);
                    }
                })
                .catch(err => console.error("Failed to fetch experts:", err))
                .finally(() => setLoading(false));
        }
    }, [isOpen, project]);

    const handleConfirm = async () => {
        if (!selectedExpert || selectedExpert === project?.assignedExpertId) {
            // Jangan lakukan apa-apa jika expert yang dipilih sama dengan yang sekarang
            onClose();
            return;
        }
        setIsSubmitting(true);
        await onConfirm(selectedExpert);
        setIsSubmitting(false);
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
                <h2 className="text-xl font-bold text-slate-800 mb-4">Re-assign Expert</h2>

                {loading ? (
                    <Spinner />
                ) : (
                    <>
                        <div className="mb-4 text-sm">
                            <p><span className="font-semibold">Project:</span> {project?.title}</p>
                            <p><span className="font-semibold">Current Expert:</span> {project?.expertName || 'None'}</p>
                        </div>

                        <div className="mb-6">
                            <label htmlFor="expert-select" className="block text-sm font-medium text-slate-700 mb-1">
                                Select New Expert
                            </label>
                            <select
                                id="expert-select"
                                value={selectedExpert}
                                // --- PERBAIKAN DI BARIS INI ---
                                onChange={(e) => setSelectedExpert(e.target.value)}
                                // -----------------------------
                                className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500"
                                disabled={isSubmitting}
                            >
                                {experts.length > 0 ? (
                                    experts.map(expert => (
                                        <option key={expert.id} value={expert.id}>
                                            {expert.name} {expert.id === project?.assignedExpertId ? '(Current)' : ''}
                                        </option>
                                    ))
                                ) : (
                                    <option disabled>No experts found in the system</option>
                                )}
                            </select>
                        </div>

                        <div className="flex justify-end space-x-3">
                            <button
                                onClick={onClose}
                                disabled={isSubmitting}
                                className="px-4 py-2 bg-slate-200 text-slate-800 rounded-md hover:bg-slate-300 disabled:opacity-50"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={handleConfirm}
                                disabled={!selectedExpert || isSubmitting || selectedExpert === project?.assignedExpertId}
                                className="px-4 py-2 bg-cyan-600 text-white rounded-md hover:bg-cyan-700 disabled:bg-cyan-400 disabled:cursor-not-allowed flex items-center"
                            >
                                {isSubmitting && <Spinner size="sm" className="mr-2" />}
                                Confirm Re-assignment
                            </button>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
};

export default AdminReassignExpertModal;