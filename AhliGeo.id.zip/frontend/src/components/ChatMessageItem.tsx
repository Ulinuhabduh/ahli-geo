
import React from 'react';
import { ChatMessage } from '../types';
// import { MOCK_EXPERTS } from '../constants'; // Removed

interface ChatMessageItemProps {
  message: ChatMessage;
  currentUserId: string;
}

const ChatMessageItem: React.FC<ChatMessageItemProps> = ({ message, currentUserId }) => {
  const isCurrentUser = message.senderId === currentUserId;

  const formatDate = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
  };

  // Avatar logic simplified:
  // Assume message.sender might have an avatarUrl in the future from the backend.
  // For now, it will use initials if no specific avatarUrl is present.
  const avatarUrl = !isCurrentUser ? (message as any).senderAvatarUrl : undefined; // Placeholder for potential future prop
  const senderInitial = message.senderName ? message.senderName.charAt(0).toUpperCase() : '?';

  return (
    <div className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'} mb-3`}>
      <div className={`flex items-end max-w-xs lg:max-w-md ${isCurrentUser ? 'flex-row-reverse' : 'flex-row'}`}>
        {!isCurrentUser && (
          <div className="flex-shrink-0 mr-2">
            {avatarUrl ? (
              <img src={avatarUrl} alt={message.senderName} className="h-8 w-8 rounded-full object-cover" />
            ) : (
              <div className="h-8 w-8 rounded-full bg-slate-300 flex items-center justify-center text-slate-600 font-semibold">
                {senderInitial}
              </div>
            )}
          </div>
        )}
        <div
          className={`px-4 py-2 rounded-xl shadow ${isCurrentUser
            ? 'bg-cyan-600 text-white rounded-br-none'
            : 'bg-slate-200 text-slate-800 rounded-bl-none'
            }`}
        >
          {!isCurrentUser && (
            <p className="text-xs font-semibold mb-0.5 text-slate-500">{message.senderName || 'User'}</p>
          )}
          <p className="text-sm break-words">{message.text}</p>
          <p className={`text-xs mt-1 ${isCurrentUser ? 'text-cyan-200' : 'text-slate-500'} text-right`}>
            {formatDate(message.timestamp)}
          </p>
        </div>
      </div>
    </div>
  );
};

export default ChatMessageItem;
