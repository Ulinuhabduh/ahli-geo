// src/components/ProtectedRoute.tsx

import React from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { UserRole } from '../../types';
import Spinner from '../../components/Spinner'; // Impor Spinner Anda

const ProtectedRoute: React.FC<{ allowedRoles?: UserRole[] }> = ({ allowedRoles }) => {
    const { isAuthenticated, user, isLoading } = useAuth();
    const location = useLocation();

    if (isLoading) {
        return (
            <div className="flex justify-center items-center h-screen">
                <Spinner size="lg" />
            </div>
        );
    }

    if (!isAuthenticated) {
        return <Navigate to="/login" state={{ from: location }} replace />;
    }

    if (allowedRoles && user && !allowedRoles.includes(user.role)) {
        // Arahkan ke dashboard mereka sendiri jika mencoba akses halaman yang tidak diizinkan
        const ownDashboard = user.role === 'client' ? '/dashboard/client' : '/dashboard/expert';
        return <Navigate to={ownDashboard} replace />;
    }

    // Jika semua pemeriksaan lolos, render komponen anak
    return <Outlet />;
};

export default ProtectedRoute;