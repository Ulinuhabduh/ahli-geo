// frontend/src/components/Footer.tsx

import React from 'react';
import { Link } from 'react-router-dom';
// Impor ikon yang mungkin Anda butuhkan (contoh, jika ada media sosial)
import {
  GlobeAltIcon,
  FacebookIcon,
  TwitterIcon,
  LinkedInIcon,
  InstagramIcon
} from './icons/HeroIcons';

const APP_NAME = "AhliGeo";

const FooterLink: React.FC<{ to: string; children: React.ReactNode }> = ({ to, children }) => (
  <Link to={to} className="text-slate-400 hover:text-cyan-400 transition-colors duration-200">
    {children}
  </Link>
);

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-400 border-t border-slate-700">
      <div className="container mx-auto px-6 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
          {/* Kolom 1: Logo dan Deskripsi Singkat */}
          <div className="space-y-4">
            <Link to="/" className="inline-flex items-center space-x-2 text-2xl font-bold text-cyan-400 hover:text-cyan-300">
              <GlobeAltIcon className="h-8 w-8" />
              <span>{APP_NAME}</span>
            </Link>
            <p className="text-sm leading-relaxed">
              {APP_NAME} is dedicated to bridging the gap between Indonesia's industries and top-tier geoscience expertise, fostering innovation and sustainable development.
            </p>
          </div>

          {/* Kolom 2: Quick Links */}
          <div>
            <h5 className="text-lg font-semibold text-slate-200 mb-4">Quick Links</h5>
            <ul className="space-y-2 text-sm">
              <li><FooterLink to="/projects">Find Projects</FooterLink></li>
              <li><FooterLink to="/experts">Find Experts</FooterLink></li>
              <li><FooterLink to="/how-it-works">How It Works</FooterLink></li>
            </ul>
          </div>

          {/* Kolom 3: Company */}
          <div>
            <h5 className="text-lg font-semibold text-slate-200 mb-4">Company</h5>
            <ul className="space-y-2 text-sm">
              <li><FooterLink to="/about">About Us</FooterLink></li>
              <li><FooterLink to="/contact">Contact Us</FooterLink></li>
              <li><FooterLink to="/terms">Terms of Service</FooterLink></li>
              <li><FooterLink to="https://www.termsfeed.com/live/5e3c4d0b-d43d-425f-93ff-dfa7bf6c39a7">Privacy Policy</FooterLink></li>
            </ul>
          </div>

          {/* Kolom 4: Connect With Us (Contoh Media Sosial) */}
          <div>
            <h5 className="text-lg font-semibold text-slate-200 mb-4">Connect With Us</h5>
            <p className="text-sm mb-3">
              Stay updated with the latest news and opportunities in the geoscience sector.
            </p>
            <div className="flex space-x-4 mb-6">
              <a href="YOUR_FACEBOOK_LINK" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-cyan-400 transition-colors">
                <FacebookIcon className="h-6 w-6" />
              </a>
              <a href="YOUR_TWITTER_LINK" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-cyan-400 transition-colors">
                <TwitterIcon className="h-6 w-6" />
              </a>
              <a href="YOUR_LINKEDIN_LINK" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-cyan-400 transition-colors">
                <LinkedInIcon className="h-6 w-6" />
              </a>
              <a href="https://www.instagram.com/ulinuhabduh_?igsh=ZDk3bmJzMzQweDRt" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-cyan-400 transition-colors">
                <InstagramIcon className="h-6 w-6" />
              </a>
            </div>
            {/* Jika ada newsletter */}
            <form className="mt-4">
              <label htmlFor="newsletter-email" className="sr-only">Email for newsletter</label>
              <div className="flex">
                <input
                  type="email"
                  id="newsletter-email"
                  placeholder="Your email address"
                  className="w-full px-3 py-2 text-sm bg-slate-800 border border-slate-700 rounded-l-md focus:ring-cyan-500 focus:border-cyan-500 text-slate-300 placeholder-slate-500"
                />
                <button type="submit" className="bg-cyan-600 hover:bg-cyan-700 text-white px-4 py-2 rounded-r-md text-sm font-semibold">
                  Subscribe
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Bagian Copyright Bawah */}
        <div className="border-t border-slate-700 pt-8 text-center">
          <p className="text-sm">
            © {new Date().getFullYear()} {APP_NAME}. All rights reserved.
          </p>
          <p className="text-xs mt-1">
            Connecting Geoscience Talent with Opportunity in Indonesia.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;