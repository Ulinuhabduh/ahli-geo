// frontend/src/components/AdminRoute.tsx
import React, { useContext } from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import AuthContext from '../contexts/AuthContext';
import Spinner from './Spinner';

const AdminRoute: React.FC = () => {
    const authContext = useContext(AuthContext);

    if (!authContext) {
        // Seharusnya tidak pernah terjadi jika dibungkus dalam AuthProvider
        return <Navigate to="/login" />;
    }

    const { user, loading } = authContext;

    if (loading) {
        return <Spinner />; // Tampilkan spinner saat data user masih loading
    }

    // Jika tidak loading, cek apakah user ada dan adalah admin
    if (user && user.role === 'admin') {
        return <Outlet />; // Tampilkan konten halaman admin
    }

    // Jika tidak, arahkan ke halaman utama atau halaman "unauthorized"
    return <Navigate to="/" replace />;
};

export default AdminRoute;