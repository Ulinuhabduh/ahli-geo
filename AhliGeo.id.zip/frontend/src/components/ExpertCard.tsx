// src/components/ExpertCard.tsx

import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Expert, Skill } from '../../types';
import Button from './Button';
import { StarIcon, MapPinIcon, BriefcaseIcon, AcademicCapIcon } from './icons/HeroIcons';

// Sub-komponen untuk menampilkan rating, kita bisa gunakan lagi di sini
const StarRatingDisplay: React.FC<{
  rating: number | string | null | undefined,
  reviewCount: number | undefined
}> = ({ rating, reviewCount }) => {
  const numericRating = rating ? parseFloat(String(rating)) : 0;

  if (isNaN(numericRating) || numericRating <= 0) {
    return <p className="text-sm text-slate-500">No rating yet</p>;
  }

  return (
    <div className="flex items-center gap-2">
      <div className="flex items-center">
        <StarIcon className="h-5 w-5 text-yellow-400" />
        <span className="font-semibold text-slate-700 ml-1">{numericRating.toFixed(2)}</span>
      </div>
      {reviewCount !== undefined && (
        <span className="text-sm text-slate-500">({reviewCount} reviews)</span>
      )}
    </div>
  );
};


const ExpertCard: React.FC<{ expert: Expert }> = ({ expert }) => {
  const location = useLocation();

  const {
    id, name, headline, location: expertLocation, experienceYears,
    skills = [], profileImageUrl, rating, hourlyRate, reviewCount
  } = expert;

  const getInitials = (nameStr: string) => {
    const initials = nameStr.split(' ').map(n => n[0]).join('');
    return initials.substring(0, 2).toUpperCase();
  };

  return (
    <div className="bg-white rounded-xl shadow-md p-6 flex flex-col h-full border border-slate-200 hover:border-cyan-400 hover:shadow-xl transition-all duration-300">

      {/* Bagian Profil Atas */}
      <div className="flex items-center w-full mb-4">
        {profileImageUrl ? (
          <img
            src={profileImageUrl}
            alt={name}
            className="w-20 h-20 rounded-full object-cover border-2 border-slate-200"
          />
        ) : (
          <div className="w-20 h-20 rounded-full bg-cyan-200 text-cyan-700 flex items-center justify-center text-3xl font-bold">
            {getInitials(name)}
          </div>
        )}
        <div className="ml-4 text-left">
          <h3 className="text-xl font-bold text-slate-900">{name}</h3>
          <p className="text-cyan-600 font-medium">{headline}</p>
        </div>
      </div>

      {/* Detail Info */}
      <div className="w-full text-left text-sm text-slate-600 space-y-2 py-4 border-t border-b border-slate-100">
        <p className="flex items-center"><MapPinIcon className="h-4 w-4 mr-2 text-slate-400" />{expertLocation || 'Location not specified'}</p>
        <p className="flex items-center"><AcademicCapIcon className="h-4 w-4 mr-2 text-slate-400" />{experienceYears || 0} years exp.</p>
        {hourlyRate && (
          <p className="flex items-center"><BriefcaseIcon className="h-4 w-4 mr-2 text-slate-400" />IDR {hourlyRate.toLocaleString()}/hour</p>
        )}
        <div className="flex items-center">
          <StarRatingDisplay rating={rating} reviewCount={reviewCount} />
        </div>
      </div>

      {/* Top Skills */}
      <div className="w-full text-left mt-4">
        <h4 className="text-xs font-semibold text-slate-500 uppercase mb-2">Top Skills:</h4>
        {skills.length > 0 ? (
          <div className="flex flex-wrap gap-2">
            {skills.slice(0, 3).map((skill: Skill) => (
              <span key={skill.id} className="bg-slate-100 text-slate-700 px-2 py-1 rounded-md text-xs font-medium">{skill.name}</span>
            ))}
            {skills.length > 3 && (
              <span className="bg-slate-100 text-slate-700 px-2 py-1 rounded-md text-xs font-medium">+{skills.length - 3} more</span>
            )}
          </div>
        ) : (
          <p className="text-sm text-slate-500">No skills listed.</p>
        )}
      </div>

      {/* Tombol Aksi */}
      <div className="w-full mt-auto pt-6">
        <Link to={`/experts/${id}`} state={{ from: location.pathname }} className="w-full">
          <Button variant="primary" className="w-full">View Profile</Button>
        </Link>
      </div>
    </div>
  );
};

export default ExpertCard;