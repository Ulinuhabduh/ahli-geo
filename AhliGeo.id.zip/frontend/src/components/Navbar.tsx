// frontend/src/components/Navbar.tsx (LENGKAP DAN DIPERBARUI)

import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import Button from './Button';
// Impor ikon yang diperlukan
import { GlobeAltIcon, Squares2X2Icon, ChatBubbleOvalLeftEllipsisIcon, Cog6ToothIcon, Bars3Icon, XMarkIcon } from './icons/HeroIcons';

const APP_NAME = "AhliGeo";

const Navbar: React.FC = () => {
    const { user, logout } = useAuth();
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    
    // Fungsi kelas untuk NavLink di Desktop
    const getNavLinkClass = ({ isActive }: { isActive: boolean }) =>
        isActive ? "text-cyan-400 font-semibold border-b-2 border-cyan-400" : "hover:text-cyan-300 transition duration-150";

    // Fungsi kelas khusus untuk NavLink di Mobile
    const getMobileNavLinkClass = ({ isActive }: { isActive: boolean }) => {
        const baseClasses = "block rounded-md px-3 py-2 text-base font-medium";
        if (isActive) {
            return `${baseClasses} bg-slate-900 text-white`;
        }
        return `${baseClasses} text-slate-300 hover:bg-slate-700 hover:text-white`;
    };

    return (
        <nav className="bg-slate-800 text-white shadow-lg sticky top-0 z-50">
            <div className="container mx-auto px-4">
                <div className="flex items-center justify-between h-20">
                    {/* Logo (Tetap di kiri) */}
                    <Link to="/" className="flex items-center space-x-2 text-2xl font-bold text-cyan-400 hover:text-cyan-300">
                        <GlobeAltIcon className="h-8 w-8" />
                        <span>{APP_NAME}</span>
                    </Link>

                    {/* Navigasi & Info User untuk Desktop (Semua digabung di kanan) */}
                    <div className="hidden md:flex items-center space-x-6">
                        {/* Tautan Navigasi Utama */}
                        <NavLink to="/" className={getNavLinkClass}>Home</NavLink>
                        <NavLink to="/projects" className={getNavLinkClass}>Find Projects</NavLink>
                        <NavLink to="/experts" className={getNavLinkClass}>Find Experts</NavLink>
                        
                        {/* Tautan & Info Kondisional Berdasarkan Status Login */}
                        {user ? (
                            <>
                                {user.role !== 'admin' && (
                                    <NavLink to="/chat" className={getNavLinkClass}>
                                        <div className="flex items-center space-x-1.5">
                                            <ChatBubbleOvalLeftEllipsisIcon className="h-5 w-5" />
                                            <span>Chat</span>
                                        </div>
                                    </NavLink>
                                )}
                                <NavLink to={user.role === 'admin' ? '/admin/dashboard' : (user.role === 'expert' ? '/dashboard/expert' : '/dashboard/client')} className={getNavLinkClass}>
                                    Dashboard
                                </NavLink>
                                {user.role === 'expert' && (
                                    <NavLink to="/settings/payout" className={getNavLinkClass} title="Payout Settings">
                                        <Cog6ToothIcon className="h-6 w-6" />
                                    </NavLink>
                                )}
                                <span className="text-slate-300 text-sm font-medium whitespace-nowrap">Welcome back, {user.name}</span>
                                <Button onClick={logout} variant="secondary" size="sm">Logout</Button>
                            </>
                        ) : (
                            <div className="flex items-center space-x-2">
                                <Link to="/login"><Button variant="outline" size="sm">Login</Button></Link>
                                <Link to="/register"><Button variant="primary" size="sm">Register</Button></Link>
                            </div>
                        )}
                    </div>

                    {/* Tombol hamburger untuk Mobile */}
                    <div className="md:hidden flex items-center">
                        <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="p-2 rounded-md text-slate-300 hover:text-white hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white">
                            <span className="sr-only">Open main menu</span>
                            {isMobileMenuOpen ? (
                                <XMarkIcon className="block h-6 w-6" />
                            ) : (
                                <Bars3Icon className="block h-6 w-6" />
                            )}
                        </button> {/* <-- KESALAHAN ADA DI SINI, SEKARANG SUDAH DIPERBAIKI */}
                    </div>
                </div>
            </div>

            {/* Blok menu mobile */}
            {isMobileMenuOpen && (
                <div className="md:hidden animate-fade-in-down" id="mobile-menu">
                    <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                        <NavLink to="/" className={getMobileNavLinkClass} onClick={() => setIsMobileMenuOpen(false)}>Home</NavLink>
                        <NavLink to="/projects" className={getMobileNavLinkClass} onClick={() => setIsMobileMenuOpen(false)}>Find Projects</NavLink>
                        <NavLink to="/experts" className={getMobileNavLinkClass} onClick={() => setIsMobileMenuOpen(false)}>Find Experts</NavLink>
                        
                        {user ? (
                            <>
                                <hr className="border-slate-700 my-2" />
                                <div className="px-3 py-2 text-sm font-medium text-slate-400">Welcome, {user.name}</div>
                                <NavLink to={user.role === 'admin' ? '/admin/dashboard' : (user.role === 'expert' ? '/dashboard/expert' : '/my-projects')} className={getMobileNavLinkClass} onClick={() => setIsMobileMenuOpen(false)}>Dashboard</NavLink>
                                {user.role === 'expert' && <NavLink to="/settings/payout" className={getMobileNavLinkClass} onClick={() => setIsMobileMenuOpen(false)}>Payout Settings</NavLink>}
                                {user.role !== 'admin' && <NavLink to="/chat" className={getMobileNavLinkClass} onClick={() => setIsMobileMenuOpen(false)}>Chat</NavLink>}
                                <button onClick={() => { logout(); setIsMobileMenuOpen(false); }} className="w-full text-left block px-3 py-2 rounded-md text-base font-medium text-slate-300 hover:bg-slate-700 hover:text-white">Logout</button>
                            </>
                        ) : (
                            <>
                                <hr className="border-slate-700 my-2" />
                                <NavLink to="/login" className={getMobileNavLinkClass} onClick={() => setIsMobileMenuOpen(false)}>Login</NavLink>
                                <NavLink to="/register" className={getMobileNavLinkClass} onClick={() => setIsMobileMenuOpen(false)}>Register</NavLink>
                            </>
                        )}
                    </div>
                </div>
            )}
        </nav>
    );
};

export default Navbar;