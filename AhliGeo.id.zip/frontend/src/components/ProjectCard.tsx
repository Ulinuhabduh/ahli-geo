// src/components/ProjectCard.tsx

import React from 'react';
import { Link } from 'react-router-dom';
import { Project, ProjectStatus } from '../../types';
import { UserCircleIcon, MapPinIcon, CalendarDaysIcon, CurrencyDollarIcon, DocumentTextIcon, StarIcon } from './icons/HeroIcons';

const StarRatingDisplay: React.FC<{
  rating: number | string | null | undefined;
  reviewCount?: number; // Pastikan ini ada
}> = ({ rating, reviewCount }) => {
  const numericRating = rating ? parseFloat(String(rating)) : 0;

  if (isNaN(numericRating) || numericRating <= 0) {

    if (reviewCount === undefined || reviewCount === 0) {
      return <p className="text-xs text-slate-500">No rating yet</p>;
    }
    // Jika ada review tapi rating 0 (aneh, tapi mungkin), tampilkan jumlah review saja
    return <p className="text-xs text-slate-500">({reviewCount} reviews)</p>;
  }

  return (
    <div className="flex items-center gap-1"> {/* Mengurangi gap agar lebih rapat */}
      <StarIcon className="h-4 w-4 text-yellow-400" />
      <span className="text-sm font-semibold text-slate-700">{numericRating.toFixed(2)}</span>
      {/* Tampilkan jumlah review jika ada dan lebih dari 0 */}
      {typeof reviewCount === 'number' && reviewCount > 0 && (
        <span className="text-xs text-slate-500 ml-0.5">({reviewCount} reviews)</span>
      )}
    </div>
  );
};

const StatusBadge: React.FC<{ status: ProjectStatus }> = ({ status }) => {
  let colorClasses = '';
  switch (status) {
    case ProjectStatus.OPEN:
      colorClasses = 'bg-green-100 text-green-800 border-green-300';
      break;
    case ProjectStatus.AWAITING_PAYMENT:
      colorClasses = 'bg-yellow-100 text-yellow-800 border-yellow-300';
      break;
    case ProjectStatus.IN_PROGRESS:
      colorClasses = 'bg-blue-100 text-blue-800 border-blue-300';
      break;
    case ProjectStatus.DELIVERED:
      colorClasses = 'bg-purple-100 text-purple-800 border-purple-300';
      break;
    case ProjectStatus.COMPLETED:
    case ProjectStatus.CLOSED:
      colorClasses = 'bg-slate-100 text-slate-800 border-slate-300';
      break;
    default:
      colorClasses = 'bg-gray-100 text-gray-800 border-gray-300';
  }

  return (
    <span
      className={`text-xs font-semibold px-2.5 py-0.5 rounded-full border ${colorClasses}`}
    >
      {status}
    </span>
  );
};

const ProjectCard: React.FC<{ project: Project }> = ({ project }) => {
  // Helper untuk memotong teks
  const truncateText = (text: string, length: number) => {
    return text.length > length ? text.substring(0, length) + '...' : text;
  };

  return (
    <div className="bg-white rounded-lg shadow-md border border-slate-200 flex flex-col h-full overflow-hidden transition-all duration-300 hover:shadow-xl hover:border-cyan-300">
      <div className="p-6 flex-grow">

        {/* Header Kartu: Judul dan Status */}
        <div className="flex justify-between items-start gap-4 mb-2">
          <h2 className="text-xl font-bold text-slate-800 hover:text-cyan-600">
            <Link to={`/projects/${project.id}`}>
              {project.title}
            </Link>
          </h2>
          {/* TAMPILKAN BADGE DI SINI */}
          <div className="flex-shrink-0 mt-1">
            <StatusBadge status={project.status} />
          </div>
        </div>

        {/* {Info Client Name dan rating} */}
        <div className="flex items-center gap-2 text-sm text-slate-500 mb-4">
          <UserCircleIcon className="h-4 w-4 flex-shrink-0" />
          <div className="flex flex-col sm:flex-row sm:items-center sm:gap-2 flex-wrap">
            <span className="font-semibold text-slate-700">{project.clientName}</span>

            {project.companyName && (
              <span className="text-slate-500">({project.companyName})</span>
            )}

            <StarRatingDisplay
              rating={project.clientAverageRating}
              reviewCount={project.clientReviewCount} // Kirim prop baru
            />
          </div>
        </div>

        <p className="text-sm text-slate-600 mb-4 line-clamp-3 min-h-[60px]">
          {truncateText(project.description, 150)}
        </p>

        {/* Info Detail Proyek */}
        <div className="space-y-2 text-sm text-slate-600 border-t pt-4">
          <div className="flex items-center"><CurrencyDollarIcon className="h-4 w-4 mr-2 text-slate-400" /><span>Budget: {project.budgetMin ? `${project.currency} ${project.budgetMin.toLocaleString()} - ${project.budgetMax?.toLocaleString()}` : 'Not Specified'}</span></div>
          <div className="flex items-center"><MapPinIcon className="h-4 w-4 mr-2 text-slate-400" /><span>Location: {project.locationType}</span></div>
          <div className="flex items-center"><CalendarDaysIcon className="h-4 w-4 mr-2 text-slate-400" /><span>Posted: {new Date(project.postedDate).toLocaleDateString('en-GB')}</span></div>
          <div className="flex items-center"><DocumentTextIcon className="h-4 w-4 mr-2 text-slate-400" /><span>Proposals: {project.proposalsCount || 0}</span></div>
        </div>

        {/* Skills & Software */}
        <div className="mt-4">
          {project.requiredSkills?.length > 0 && (
            <div className="mb-2">
              <h4 className="text-xs font-semibold uppercase text-slate-400 mb-1">Required Skills</h4>
              <div className="flex flex-wrap gap-1.5">
                {project.requiredSkills.slice(0, 3).map(skill => <span key={skill.id} className="bg-cyan-100 text-cyan-800 text-xs font-medium px-2 py-0.5 rounded-full">{skill.name}</span>)}
                {project.requiredSkills.length > 3 && <span className="text-xs text-slate-500 py-0.5">+ {project.requiredSkills.length - 3} more</span>}
              </div>
            </div>
          )}
          {project.requiredSoftware?.length > 0 && (
            <div>
              <h4 className="text-xs font-semibold uppercase text-slate-400 mb-1">Required Software</h4>
              <div className="flex flex-wrap gap-1.5">
                {project.requiredSoftware.slice(0, 3).map(sw => <span key={sw.id} className="bg-indigo-100 text-indigo-800 text-xs font-medium px-2 py-0.5 rounded-full">{sw.name}</span>)}
                {project.requiredSoftware.length > 3 && <span className="text-xs text-slate-500 py-0.5">+ {project.requiredSoftware.length - 3} more</span>}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="bg-slate-50/75 px-6 py-4 border-t border-slate-200">
        <Link to={`/projects/${project.id}`}>
          <button className="w-full text-center bg-white border border-cyan-600 text-cyan-700 font-semibold py-2 px-4 rounded-lg hover:bg-cyan-50 transition-colors">
            View Details
          </button>
        </Link>
      </div>
    </div>
  );
};

export default ProjectCard;