// src/components/ApplyProposalModal.tsx

import React, { useState } from 'react';
import { Project } from '../../types';
import { submitProposal } from '../services/apiService';
import Button from './Button';
import Spinner from './Spinner';

interface Props {
    project: Project;
    onClose: () => void;
    // Prop baru untuk memberitahu induk bahwa submit berhasil
    onSubmissionSuccess: () => void;
}

const ApplyProposalModal: React.FC<Props> = ({ project, onClose, onSubmissionSuccess }) => {
    const [coverLetter, setCoverLetter] = useState('');
    const [proposedRate, setProposedRate] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!coverLetter.trim()) {
            setError('Cover letter cannot be empty.');
            return;
        }

        setIsSubmitting(true);
        setError('');

        try {
            await submitProposal({
                projectId: project.id,
                coverLetter,
                proposedRate: proposedRate ? parseFloat(proposedRate) : undefined
            });

            // Beritahu komponen induk bahwa prosesnya berhasil
            onSubmissionSuccess();

        } catch (err: any) {
            setError(err.message || 'Failed to submit proposal.');
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-lg animate-fade-in-up">
                <h2 className="text-2xl font-bold mb-1">Apply for: {project.title}</h2>
                <p className="text-sm text-slate-500 mb-6">Your proposal will be sent to the client.</p>

                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label htmlFor="coverLetter" className="block text-sm font-medium text-slate-700 mb-1">Cover Letter*</label>
                        <textarea
                            id="coverLetter"
                            value={coverLetter}
                            onChange={(e) => setCoverLetter(e.target.value)}
                            placeholder="Introduce yourself and explain why you are a good fit for this project..."
                            className="w-full h-32 p-2 border border-slate-300 rounded-md shadow-sm focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                            required
                        />
                    </div>

                    <div>
                        <label htmlFor="proposedRate" className="block text-sm font-medium text-slate-700 mb-1">
                            Your Bid Amount (Optional, in {project.currency || 'IDR'})
                        </label>
                        <div className="relative">
                            <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500">{project.currency || 'IDR'}</span>
                            <input
                                id="proposedRate"
                                type="number"
                                value={proposedRate}
                                onChange={(e) => setProposedRate(e.target.value)}
                                placeholder="e.g., 5000000"
                                min="0"
                                className="w-full pl-12 pr-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                            />
                        </div>
                    </div>

                    {error && <p className="text-red-500 text-sm mt-2">{error}</p>}

                    <div className="flex justify-end gap-4 pt-4">
                        <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>Cancel</Button>
                        <Button type="submit" variant="primary" disabled={isSubmitting}>
                            {isSubmitting ? <Spinner size="sm" /> : 'Submit Proposal'}
                        </Button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default ApplyProposalModal;