// frontend/src/components/MultiSelectCombobox.tsx

import React, { useState, useRef, useEffect } from 'react';
import { XCircleIcon, ChevronUpDownIcon, PlusCircleIcon } from './icons/HeroIcons';
import { createNewSkill, createNewSoftware } from '../services/apiService';
import toast from 'react-hot-toast';
import { Skill as SkillType } from '../../types';
import Spinner from './Spinner';

interface MultiSelectComboboxProps {
    options: SkillType[];
    setOptions: React.Dispatch<React.SetStateAction<SkillType[]>>; // Untuk update daftar global
    selected: SkillType[];
    onChange: (selected: SkillType[]) => void;
    placeholder?: string;
    type: 'skill' | 'software';
}

export const MultiSelectCombobox: React.FC<MultiSelectComboboxProps> = ({
    options,
    setOptions,
    selected,
    onChange,
    placeholder = "Select options...",
    type
}) => {
    const [query, setQuery] = useState('');
    const [isOpen, setIsOpen] = useState(false);
    const [isCreating, setIsCreating] = useState(false);
    const inputRef = useRef<HTMLInputElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const filteredOptions = query === ''
        ? options.filter(option => !selected.some(s => s.id === option.id))
        : options.filter(option =>
            !selected.some(s => s.id === option.id) &&
            option.name.toLowerCase().includes(query.toLowerCase())
        );

    const isExactMatch = options.some(option => option.name.toLowerCase() === query.trim().toLowerCase());

    const handleSelect = (option: SkillType) => {
        onChange([...selected, option]);
        setQuery('');
        setIsOpen(false);
    };

    const handleDeselect = (option: SkillType) => {
        onChange(selected.filter(s => s.id !== option.id));
    };

    const handleCreate = async () => {
        if (!query.trim() || isCreating) return;

        setIsCreating(true);
        const createApi = type === 'skill' ? createNewSkill : createNewSoftware;
        
        try {
            const newOption = await createApi({ name: query.trim() });
            toast.success(`'${newOption.name}' added successfully!`);
            
            setOptions(prev => [...prev, newOption]);
            handleSelect(newOption);
            
        } catch (error: any) {
            toast.error(error.message || `Failed to add '${query}'`);
        } finally {
            setIsCreating(false);
        }
    };

    return (
        <div ref={containerRef} className="relative">
            <div 
                className="w-full flex flex-wrap gap-2 p-2 border border-slate-300 rounded-md bg-white cursor-text focus-within:ring-2 focus-within:ring-cyan-500 focus-within:border-cyan-500"
                onClick={() => { setIsOpen(true); inputRef.current?.focus(); }}
            >
                {selected.map(item => (
                    <span key={item.id} className="flex items-center gap-1.5 bg-cyan-100 text-cyan-800 text-sm font-medium px-2 py-1 rounded-full animate-fade-in">
                        {item.name}
                        <button type="button" onClick={(e) => { e.stopPropagation(); handleDeselect(item); }} className="rounded-full focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-cyan-600">
                            <XCircleIcon className="h-4 w-4 text-cyan-600 hover:text-cyan-800" />
                        </button>
                    </span>
                ))}
                
                <div className="relative flex-grow min-w-[100px]">
                    <input
                        ref={inputRef}
                        type="text"
                        value={query}
                        onChange={(e) => { setQuery(e.target.value); if (!isOpen) setIsOpen(true); }}
                        placeholder={selected.length > 0 ? '' : placeholder}
                        className="w-full bg-transparent focus:outline-none text-sm p-1"
                        onFocus={() => setIsOpen(true)}
                        onKeyDown={(e) => { if(e.key === 'Escape') setIsOpen(false); }}
                    />
                </div>
            </div>

            {isOpen && (
                <ul className="absolute z-10 mt-1 max-h-60 w-full overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm">
                    {filteredOptions.map(option => (
                        <li key={option.id} className="relative cursor-pointer select-none py-2 px-4 text-slate-700 hover:bg-cyan-100 hover:text-cyan-900" onClick={() => handleSelect(option)}>
                            {option.name}
                        </li>
                    ))}
                    
                    {query.trim() && !isExactMatch && (
                        <li className="relative cursor-pointer select-none py-2 pl-3 pr-9 text-slate-900 hover:bg-cyan-100" onClick={handleCreate}>
                            <span className="flex items-center">
                                <PlusCircleIcon className="h-5 w-5 mr-2 text-cyan-600" />
                                {isCreating ? 'Creating...' : `Create "${query.trim()}"`}
                            </span>
                        </li>
                    )}
                    
                    {filteredOptions.length === 0 && !query.trim() && (
                        <div className="relative cursor-default select-none py-2 px-4 text-slate-500">
                          No options left
                        </div>
                    )}
                </ul>
            )}
        </div>
    );
};