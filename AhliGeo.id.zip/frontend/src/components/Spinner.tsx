
import React from 'react';

interface SpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  color?: string; // Tailwind color class e.g. text-blue-500
}

const Spinner: React.FC<SpinnerProps> = ({ size = 'md', color = 'text-cyan-600' }) => {
  let sizeClasses = '';
  switch (size) {
    case 'sm':
      sizeClasses = 'h-6 w-6';
      break;
    case 'md':
      sizeClasses = 'h-12 w-12';
      break;
    case 'lg':
      sizeClasses = 'h-16 w-16';
      break;
  }

  return (
    <div className={`flex justify-center items-center`}>
      <div 
        className={`animate-spin rounded-full ${sizeClasses} border-t-2 border-b-2 border-transparent ${color.replace('text-', 'border-')}`}
        style={{ borderTopColor: 'currentColor', borderBottomColor: 'currentColor' }} // Ensure current color is used for spinner parts
      ></div>
    </div>
  );
};

export default Spinner;
