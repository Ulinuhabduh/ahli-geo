// frontend/src/components/LeaveReviewModal.tsx

import React, { useState } from 'react';
import { createReview } from '../services/apiService';
import Button from './Button';
import Spinner from './Spinner';
import { StarIcon } from './icons/HeroIcons';

interface Props {
    projectId: string;
    onClose: () => void;
    onSuccess: () => void;
}

// =======================================================
// === SUB-KOMPONEN BARU UNTUK BINTANG (LEBIH TERISOLASI) ===
// =======================================================
const StarRatingInput: React.FC<{
    rating: number;
    setRating: (rating: number) => void;
}> = ({ rating, setRating }) => {
    const [hoverRating, setHoverRating] = useState(0);

    return (
        <div className="flex space-x-1">
            {[1, 2, 3, 4, 5].map((starIndex) => {
                // Tentukan warna berdasarkan state hover atau state rating yang sudah dipilih
                const isFilled = (hoverRating || rating) >= starIndex;
                const colorClass = isFilled ? 'text-yellow-400' : 'text-slate-300';

                return (
                    <button
                        type="button" // PENTING: agar tidak men-submit form
                        key={starIndex}
                        className={`transition-colors duration-150 transform hover:scale-110`}
                        onClick={() => setRating(starIndex)}
                        onMouseEnter={() => setHoverRating(starIndex)}
                        onMouseLeave={() => setHoverRating(0)}
                        aria-label={`Rate ${starIndex} star`}
                    >
                        <StarIcon className={`h-8 w-8 ${colorClass}`} />
                    </button>
                );
            })}
        </div>
    );
};


// =======================================================
// === KOMPONEN UTAMA MODAL ===
// =======================================================
const LeaveReviewModal: React.FC<Props> = ({ projectId, onClose, onSuccess }) => {
    const [rating, setRating] = useState(0);
    const [comment, setComment] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (rating === 0) {
            setError('Please select a star rating.');
            return;
        }
        setIsSubmitting(true);
        setError('');
        try {
            await createReview({ projectId, rating, comment });
            onSuccess();
        } catch (err: any) {
            setError(err.message || 'Failed to submit review.');
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-lg">
                <h2 className="text-2xl font-bold mb-4">Leave a Review</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">Your Rating*</label>
                        {/* Menggunakan sub-komponen StarRatingInput */}
                        <StarRatingInput rating={rating} setRating={setRating} />
                    </div>
                    <div>
                        <label htmlFor="comment" className="block text-sm font-medium text-slate-700 mb-1">Comment (Optional)</label>
                        <textarea
                            id="comment"
                            rows={4}
                            value={comment}
                            onChange={(e) => setComment(e.target.value)}
                            className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500"
                            placeholder="Share your experience working on this project..."
                        />
                    </div>
                    {error && <p className="text-red-500 text-sm">{error}</p>}
                    <div className="flex justify-end gap-4 pt-4">
                        <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
                        <Button type="submit" variant="primary" disabled={isSubmitting}>
                            {isSubmitting ? <Spinner size="sm" /> : 'Submit Review'}
                        </Button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default LeaveReviewModal;