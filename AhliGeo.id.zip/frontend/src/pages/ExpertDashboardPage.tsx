// src/pages/ExpertDashboardPage.tsx

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import Button from '../components/Button';
import { fetchProjects, fetchMyNotifications, getMyChatSessions } from '../services/apiService';
import ProjectCard from '../components/ProjectCard';
import Spinner from '../components/Spinner';
import { Project, ProjectStatus, Notification, ChatSession } from '../../types';
import {
  Squares2X2Icon, BriefcaseIcon, UserCircleIcon, ClipboardDocumentListIcon,
  BellAlertIcon, ChatBubbleLeftEllipsisIcon
} from '../components/icons/HeroIcons';

const ExpertDashboardPage: React.FC = () => {
  const { user } = useAuth();

  // State untuk data dinamis
  const [recommendedProjects, setRecommendedProjects] = useState<Project[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [chatSessions, setChatSessions] = useState<ChatSession[]>([]);

  // State untuk loading
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Hanya jalankan jika user sudah ter-load
    if (!user) {
      setIsLoading(false);
      return;
    }

    const loadDashboardData = async () => {
      setIsLoading(true);
      setError(null);
      try {
        // Ambil data proyek dan notifikasi secara bersamaan
        const [projectsData, notificationsData, sessionsData] = await Promise.all([
          fetchProjects({ status: ProjectStatus.OPEN, limit: 3 }),
          fetchMyNotifications(),
          getMyChatSessions()
        ]);

        setRecommendedProjects(projectsData || []);
        setNotifications(notificationsData || []);
        setChatSessions(sessionsData || []);

      } catch (err: any) {
        console.error("Failed to load expert dashboard data", err);
        setError("Could not load all dashboard data. Please try again.");
      } finally {
        setIsLoading(false);
      }
    };

    loadDashboardData();
  }, [user]); // Jalankan effect ini saat user berubah

  // Tampilkan spinner utama saat user atau data awal sedang dimuat
  if (isLoading) {
    return <div className="p-12 text-center"><Spinner size="lg" /></div>;
  }

  if (!user) {
    return <p className="p-12 text-center text-red-500">User not found. Please log in again.</p>;
  }

  if (error) {
    return <p className="p-12 text-center text-red-500">{error}</p>
  }

  const latestSession = chatSessions.length > 0 ? chatSessions[0] : null;

  // Komponen QuickLink tidak perlu diubah, sudah bagus
  const QuickLink: React.FC<{ to: string, icon: React.ReactNode, label: string, description: string }> =
    ({ to, icon, label, description }) => (
      <Link to={to} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-slate-200 flex flex-col items-center text-center">
        <div className="text-cyan-600 mb-3">{icon}</div>
        <h3 className="text-lg font-semibold text-slate-800 mb-1">{label}</h3>
        <p className="text-sm text-slate-500">{description}</p>
      </Link>
    );

  // Filter notifikasi undangan
  const projectInvitations = notifications.filter(n => n.type === 'PROJECT_INVITATION');

  return (
    <div className="space-y-10 container mx-auto py-12 px-4">
      <header className="bg-slate-800 text-white p-8 rounded-lg shadow-lg">
        <div className="flex items-center space-x-4">
          <Squares2X2Icon className="h-12 w-12 text-cyan-400" />
          <div>
            <h1 className="text-3xl font-bold">Expert Dashboard</h1>
            <p className="text-slate-300">Welcome back, {user.name}! Find your next project and manage your profile.</p>
          </div>
        </div>
      </header>

      {/* Quick Actions */}
      <section>
        <h2 className="text-2xl font-semibold text-slate-800 mb-6">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <QuickLink to="/projects" icon={<BriefcaseIcon className="h-10 w-10" />} label="Find New Projects" description="Browse and apply for the latest geoscience projects." />
          <QuickLink to={`/experts/${user.id}`} icon={<UserCircleIcon className="h-10 w-10" />} label="View My Profile" description="See how your public profile looks to clients." />
          <QuickLink to="/my-applications" icon={<ClipboardDocumentListIcon className="h-10 w-10" />} label="My Applications" description="Track the status of your project proposals." />
        </div>
      </section>

      {/* Summary / Recent Activity */}
      <section>
        <h2 className="text-2xl font-semibold text-slate-800 mb-6">Recent Activity & Summaries</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Kartu Project Invitations yang Dinamis */}
          <div className="bg-white p-6 rounded-lg shadow border">
            <h3 className="text-xl font-semibold text-slate-700 mb-3 flex items-center">
              <BellAlertIcon className="h-6 w-6 mr-2 text-yellow-500" />
              Project Invitations
            </h3>
            {projectInvitations.length > 0 ? (
              <ul className="space-y-3">
                {projectInvitations.slice(0, 3).map(notif => (
                  <li key={notif.id} className="text-sm text-slate-600 border-b border-slate-100 pb-2 last:border-b-0">
                    <p>{notif.message}</p>
                    <Link to={`/projects/${notif.relatedProjectId}`} className="text-xs text-cyan-600 hover:underline mt-1 inline-block">View project details</Link>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-slate-500">You have no new project invitations.</p>
            )}
          </div>
          {/* Kartu Recent Messages (masih statis, perlu logika chat) */}
          <div className="bg-white p-6 rounded-lg shadow border">
            <h3 className="text-xl font-semibold text-slate-700 mb-3 flex items-center">
              <ChatBubbleLeftEllipsisIcon className="h-6 w-6 mr-2 text-blue-500" />
              Recent Messages
            </h3>
            {latestSession ? (
              // Cek apakah pesan terakhir BUKAN dari diri sendiri
              latestSession.lastMessageSenderId !== user.id ? (
                <div>
                  <p className="text-sm text-slate-600">
                    New message from <span className="font-semibold">{latestSession.recipientName}</span>
                  </p>
                  <p className="text-sm text-slate-500 italic truncate mt-1">
                    "{latestSession.lastMessage}"
                  </p>
                  <Link to={`/chat/${latestSession.sessionId}`} className="text-sm text-cyan-600 hover:underline mt-3 inline-block">
                    View conversation
                  </Link>
                </div>
              ) : (
                // Jika pesan terakhir dari diri sendiri
                <div>
                  <p className="text-sm text-slate-600">
                    You sent the last message to <span className="font-semibold">{latestSession.recipientName}</span>
                  </p>
                  <p className="text-sm text-slate-500 italic truncate mt-1">
                    You: "{latestSession.lastMessage}"
                  </p>
                  <Link to={`/chat/${latestSession.sessionId}`} className="text-sm text-cyan-600 hover:underline mt-3 inline-block">
                    Continue conversation
                  </Link>
                </div>
              )
            ) : (
              <p className="text-slate-500 text-sm">You have no new messages.</p>
            )}
          </div>
        </div>
      </section>

      {/* Recommended Projects */}
      <section>
        <h2 className="text-2xl font-semibold text-slate-800 mb-6">Recommended Projects For You</h2>
        {recommendedProjects.length > 0 ? (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recommendedProjects.map(project => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
            <div className="text-center mt-8">
              <Link to="/projects"><Button variant="secondary">Browse All Projects</Button></Link>
            </div>
          </>
        ) : (
          <p className="text-center text-slate-500 py-6 bg-white rounded-lg shadow border">No recommended projects at the moment. <Link to="/projects" className="text-cyan-600 hover:underline">Browse all projects.</Link></p>
        )}
      </section>
    </div>
  );
};

export default ExpertDashboardPage;