// src/pages/ClientDashboardPage.tsx

import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom'; // 1. Impor useLocation
import { useAuth } from '../contexts/AuthContext';
import { fetchProjects, fetchMyNotifications, getMyChatSessions } from '../services/apiService';
import { Project, Notification, ChatSession } from '../../types';
import Spinner from '../components/Spinner';
import Button from '../components/Button';
import {
  PlusCircleIcon,
  ListBulletIcon,
  MagnifyingGlassIcon,
  BellAlertIcon,
  ChatBubbleLeftEllipsisIcon
} from '../components/icons/HeroIcons';

const ClientDashboardPage: React.FC = () => {
  const { user } = useAuth();
  const location = useLocation(); // 2. Panggil useLocation di level halaman
  const [recentProjects, setRecentProjects] = useState<Project[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [chatSessions, setChatSessions] = useState<ChatSession[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setIsLoading(false);
      return;
    }
    const loadDashboardData = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const [projectsData, notificationsData, sessionsData] = await Promise.all([
          fetchProjects({ clientId: user.id, limit: 3 }),
          fetchMyNotifications(),
          getMyChatSessions()
        ]);
        setRecentProjects(projectsData || []);
        setNotifications(notificationsData || []);
        setChatSessions(sessionsData || []);
      } catch (err: any) {
        console.error("Failed to load client dashboard data", err);
        setError(err.message || "Could not load dashboard data.");
      } finally {
        setIsLoading(false);
      }
    };
    loadDashboardData();
  }, [user]);

  if (isLoading) return <div className="p-12 text-center"><Spinner size="lg" /></div>;
  if (!user) return <div className="p-12 text-center">Please log in to view your dashboard.</div>;
  if (error) return <p className="p-12 text-center text-red-500">{error}</p>;

  const latestSession = chatSessions.length > 0 ? chatSessions[0] : null;

  const newProposalNotifications = notifications.filter(n => n.type === 'NEW_PROPOSAL' && !n.isRead);

  const QuickLink: React.FC<{ to: string, icon: React.ReactNode, label: string, description: string }> = ({ to, icon, label, description }) => (
    <Link to={to} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-slate-200 flex flex-col items-center text-center">
      <div className="text-cyan-600 mb-3">{icon}</div>
      <h3 className="font-semibold text-lg text-slate-800">{label}</h3>
      <p className="text-sm text-slate-500 mt-1">{description}</p>
    </Link>
  );

  return (
    <div className="space-y-10 container mx-auto py-12 px-4">
      <header className="bg-slate-800 text-white p-8 rounded-lg shadow-lg">
        <h1 className="text-3xl font-bold">Client Dashboard</h1>
        <p className="text-slate-300">Welcome back, {user.name}! Manage your projects and find experts.</p>
      </header>
      <section>
        <h2 className="text-2xl font-semibold text-slate-800 mb-6">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <QuickLink to="/post-project" icon={<PlusCircleIcon className="h-10 w-10" />} label="Post New Project" description="Define your project needs and attract top talent." />
          <QuickLink to="/my-projects" icon={<ListBulletIcon className="h-10 w-10" />} label="View My Projects" description="Track progress and manage your active projects." />
          <QuickLink to="/experts" icon={<MagnifyingGlassIcon className="h-10 w-10" />} label="Find Experts" description="Browse profiles of verified geoscience professionals." />
        </div>
      </section>
      <section>
        <h2 className="text-2xl font-semibold text-slate-800 mb-6">Recent Activity & Summaries</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg shadow border">
            <h3 className="text-xl font-semibold text-slate-700 mb-3 flex items-center"><BellAlertIcon className="h-6 w-6 mr-2 text-yellow-500" /> Notifications</h3>
            {newProposalNotifications.length > 0 ? (
              <div className="text-sm text-slate-600 space-y-2">
                <p>You have <span className="font-bold text-red-600">{newProposalNotifications.length}</span> new proposal(s).</p>
                <ul className="list-disc list-inside space-y-1">
                  {newProposalNotifications.slice(0, 2).map(notif => (
                    <li key={notif.id}>
                      <Link to={`/my-projects/proposals/${notif.relatedProjectId}`} className="text-cyan-600 hover:underline">
                        New proposal for "{notif.projectTitle}"
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ) : (<p className="text-sm text-slate-500">No new notifications.</p>)}
            <Link to="/notifications" className="text-sm text-cyan-600 hover:underline mt-4 inline-block">View all notifications</Link>
          </div>
          <div className="bg-white p-6 rounded-lg shadow border">
            <h3 className="text-xl font-semibold text-slate-700 mb-3 flex items-center">
              <ChatBubbleLeftEllipsisIcon className="h-6 w-6 mr-2 text-blue-500" />
              Recent Messages
            </h3>
            {latestSession ? (
              // Cek apakah pesan terakhir BUKAN dari diri sendiri
              latestSession.lastMessageSenderId !== user.id ? (
                <div>
                  <p className="text-sm text-slate-600">
                    New message from <span className="font-semibold">{latestSession.recipientName}</span>
                  </p>
                  <p className="text-sm text-slate-500 italic truncate mt-1">
                    "{latestSession.lastMessage}"
                  </p>
                  <Link to={`/chat/${latestSession.sessionId}`} className="text-sm text-cyan-600 hover:underline mt-3 inline-block">
                    View conversation
                  </Link>
                </div>
              ) : (
                // Jika pesan terakhir dari diri sendiri
                <div>
                  <p className="text-sm text-slate-600">
                    You sent the last message to <span className="font-semibold">{latestSession.recipientName}</span>
                  </p>
                  <p className="text-sm text-slate-500 italic truncate mt-1">
                    You: "{latestSession.lastMessage}"
                  </p>
                  <Link to={`/chat/${latestSession.sessionId}`} className="text-sm text-cyan-600 hover:underline mt-3 inline-block">
                    Continue conversation
                  </Link>
                </div>
              )
            ) : (
              <p className="text-slate-500 text-sm">You have no new messages.</p>
            )}
          </div>
        </div>
      </section>
      <section>
        <h2 className="text-2xl font-semibold text-slate-800 mb-6">Your Recent Projects</h2>
        {recentProjects.length > 0 ? (
          <div className="space-y-4">
            {recentProjects.map(p => (
              <div key={p.id} className="bg-white p-4 rounded-lg shadow border flex justify-between items-center">
                <div>
                  <Link to={`/projects/${p.id}`} className="font-semibold text-cyan-700 hover:underline">{p.title}</Link>
                  <p className="text-sm text-slate-500">Status: {p.status}</p>
                </div>
                {/* ===== PERUBAHAN DI SINI ===== */}
                <Link
                  to={`/my-projects/proposals/${p.id}`}
                  state={{ from: location.pathname }} // 3. Kirim path saat ini sebagai state
                >
                  <Button size="sm">View Proposals ({p.proposalsCount})</Button>
                </Link>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-slate-500 bg-white p-6 rounded-lg shadow border text-center">You have no active projects yet.</p>
        )}
      </section>
    </div>
  );
};

export default ClientDashboardPage;