// frontend/src/pages/HowItWorksPage.tsx

import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../components/Button';
import {
    UserCircleIcon, BriefcaseIcon, DocumentPlusIcon, MagnifyingGlassIcon,
    ChatBubbleLeftRightIcon, CreditCardIcon, CheckCircleIcon, StarIcon, PencilSquareIcon, UsersIcon
} from '../components/icons/HeroIcons'; // Pastikan semua ikon ini ada

const APP_NAME = "AhliGeo";

const StepCard: React.FC<{
    number: number;
    title: string;
    description: string;
    icon: React.ReactNode;
    colorClass: string; // e.g., 'text-cyan-600 bg-cyan-100'
}> = ({ number, title, description, icon, colorClass }) => (
    <div className="flex">
        <div className="flex-shrink-0 mr-6">
            <div className={`flex items-center justify-center h-12 w-12 rounded-full ${colorClass.split(' ')[1]} text-xl font-bold ${colorClass.split(' ')[0]}`}>
                {number}
            </div>
        </div>
        <div>
            <h3 className="text-xl font-semibold text-slate-800 mb-2 flex items-center">
                {React.cloneElement(icon as React.ReactElement, { className: `h-6 w-6 mr-2 ${colorClass.split(' ')[0]}` })}
                {title}
            </h3>
            <p className="text-slate-600 leading-relaxed">
                {description}
            </p>
        </div>
    </div>
);

const HowItWorksPage: React.FC = () => {
    return (
        <div className="py-12 md:py-20 bg-slate-50">
            <div className="container mx-auto px-4">
                <header className="text-center mb-16">
                    <MagnifyingGlassIcon className="h-16 w-16 text-cyan-500 mx-auto mb-6" />
                    <h1 className="text-4xl md:text-5xl font-extrabold text-slate-800 mb-4">
                        How <span className="text-cyan-600">{APP_NAME}</span> Works
                    </h1>
                    <p className="text-lg text-slate-600 max-w-2xl mx-auto">
                        Connecting geoscience projects with expert talent is simple and secure.
                        Follow these easy steps to get started.
                    </p>
                </header>

                {/* Seksi Untuk Clients */}
                <section className="mb-20">
                    <div className="text-center mb-12">
                        <UsersIcon className="h-12 w-12 text-cyan-600 mx-auto mb-4" />
                        <h2 className="text-3xl font-bold text-slate-800">For Clients</h2>
                        <p className="text-md text-slate-500 mt-2">Find the perfect geoscience expert for your project needs.</p>
                    </div>
                    <div className="max-w-3xl mx-auto space-y-10">
                        <StepCard
                            number={1}
                            title="Post Your Project"
                            description="Clearly describe your project requirements, scope, budget, and desired skills. The more detail, the better the proposals you'll receive."
                            icon={<DocumentPlusIcon />}
                            colorClass="text-cyan-600 bg-cyan-100"
                        />
                        <StepCard
                            number={2}
                            title="Receive & Review Proposals"
                            description="Qualified and verified geoscience experts will submit their proposals. Compare their experience, approach, and bid."
                            icon={<ChatBubbleLeftRightIcon />}
                            colorClass="text-cyan-600 bg-cyan-100"
                        />
                        <StepCard
                            number={3}
                            title="Hire & Fund Securely"
                            description="Select the best expert for your project. Fund the project through our secure escrow system to start the collaboration."
                            icon={<CreditCardIcon />}
                            colorClass="text-cyan-600 bg-cyan-100"
                        />
                        <StepCard
                            number={4}
                            title="Collaborate & Complete"
                            description="Work with your chosen expert, monitor progress, and approve deliverables. Mark the project as complete once satisfied."
                            icon={<CheckCircleIcon />}
                            colorClass="text-cyan-600 bg-cyan-100"
                        />
                        <StepCard
                            number={5}
                            title="Leave a Review"
                            description="Share your experience by leaving a review for the expert. This helps build a trusted community."
                            icon={<StarIcon />}
                            colorClass="text-cyan-600 bg-cyan-100"
                        />
                    </div>
                    <div className="text-center mt-12">
                        <Link to="/post-project">
                            <Button variant="primary" size="lg">Post a Project Now</Button>
                        </Link>
                    </div>
                </section>

                {/* Seksi Untuk Experts */}
                <section>
                    <div className="text-center mb-12">
                        <UserCircleIcon className="h-12 w-12 text-teal-600 mx-auto mb-4" />
                        <h2 className="text-3xl font-bold text-slate-800">For Experts</h2>
                        <p className="text-md text-slate-500 mt-2">Showcase your skills and find exciting geoscience projects.</p>
                    </div>
                    <div className="max-w-3xl mx-auto space-y-10">
                        <StepCard
                            number={1}
                            title="Create Your Profile"
                            description="Build a compelling profile highlighting your expertise, experience, skills, and software proficiency. Get verified to increase trust."
                            icon={<PencilSquareIcon />}
                            colorClass="text-teal-600 bg-teal-100"
                        />
                        <StepCard
                            number={2}
                            title="Find Relevant Projects"
                            description="Browse a wide range of geoscience projects posted by clients from various industries. Filter by your specialization."
                            icon={<BriefcaseIcon />}
                            colorClass="text-teal-600 bg-teal-100"
                        />
                        <StepCard
                            number={3}
                            title="Submit Winning Proposals"
                            description="Craft tailored proposals that clearly address the client's needs and showcase why you're the best fit for the project."
                            icon={<DocumentPlusIcon />}
                            colorClass="text-teal-600 bg-teal-100"
                        />
                        <StepCard
                            number={4}
                            title="Deliver Quality Work"
                            description="Once hired, collaborate effectively with the client, deliver high-quality work, and submit your deliverables on time."
                            icon={<CheckCircleIcon />}
                            colorClass="text-teal-600 bg-teal-100"
                        />
                        <StepCard
                            number={5}
                            title="Get Paid & Reviewed"
                            description="Receive secure payments upon project completion and build your reputation through client reviews."
                            icon={<StarIcon />}
                            colorClass="text-teal-600 bg-teal-100"
                        />
                    </div>
                    <div className="text-center mt-12">
                        <Link to="/register">
                            <Button variant="primary" size="lg" className="bg-teal-600 hover:bg-teal-700">Join as an Expert</Button>
                        </Link>
                    </div>
                </section>
            </div>
        </div>
    );
};

export default HowItWorksPage;