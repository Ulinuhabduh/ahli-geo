// src/pages/MyApplicationsPage.tsx

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { fetchMyApplications } from '../services/apiService';
import { Proposal, ProjectStatus } from '../../types'; // Gunakan ProjectStatus untuk badge
import Spinner from '../components/Spinner';
import { DocumentTextIcon } from '../components/icons/HeroIcons';

// Komponen Badge Status yang bisa digunakan kembali
const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
    const statusStyles: { [key: string]: string } = {
        Pending: 'bg-yellow-100 text-yellow-800',
        Accepted: 'bg-green-100 text-green-800',
        Rejected: 'bg-red-100 text-red-800',
        Withdrawn: 'bg-gray-100 text-gray-800',
    };
    return (
        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusStyles[status] || 'bg-gray-100'}`}>
            {status}
        </span>
    );
};

const MyApplicationsPage: React.FC = () => {
    const [applications, setApplications] = useState<Proposal[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        setIsLoading(true);
        fetchMyApplications()
            .then(data => {
                setApplications(data);
            })
            .catch((err) => {
                console.error("Failed to load applications:", err);
                setError('Could not load your applications. Please try again.');
            })
            .finally(() => {
                setIsLoading(false);
            });
    }, []);

    if (isLoading) return <div className="text-center p-12"><Spinner size="lg" /></div>;
    if (error) return <div className="text-center p-12 text-red-500">{error}</div>;

    return (
        <div className="max-w-5xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
            <header className="mb-8">
                <h1 className="text-3xl font-bold text-slate-900">My Applications</h1>
                <p className="mt-1 text-slate-600">Track the status of all your submitted proposals.</p>
            </header>

            <div className="bg-white shadow-sm border rounded-lg overflow-hidden">
                {applications.length === 0 ? (
                    <div className="text-center p-16">
                        <DocumentTextIcon className="mx-auto h-12 w-12 text-slate-400" />
                        <h3 className="mt-2 text-lg font-medium text-slate-900">No Applications Found</h3>
                        <p className="mt-1 text-sm text-slate-500">You haven't applied to any projects yet.</p>
                        <div className="mt-6">
                            <Link to="/projects" className="text-cyan-600 hover:text-cyan-800 font-semibold">
                                Find Projects to Apply For →
                            </Link>
                        </div>
                    </div>
                ) : (
                    <ul className="divide-y divide-slate-200">
                        {applications.map(app => (
                            <li key={app.id} className="p-4 sm:p-6 hover:bg-slate-50 transition-colors">
                                <div className="flex flex-col sm:flex-row items-start justify-between gap-4">
                                    <div className="flex-grow">
                                        <Link to={`/projects/${app.projectId}`} className="text-lg font-semibold text-cyan-700 hover:underline">
                                            {app.projectTitle}
                                        </Link>
                                        <p className="text-sm text-slate-500 mt-1">
                                            Client: {app.clientName}
                                        </p>
                                    </div>
                                    <div className="flex-shrink-0">
                                        <StatusBadge status={app.status} />
                                    </div>
                                </div>
                                <p className="text-sm text-slate-500 mt-2">
                                    Applied on: {new Date(app.submittedDate).toLocaleDateString('en-GB')}
                                </p>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
        </div>
    );
};

export default MyApplicationsPage;