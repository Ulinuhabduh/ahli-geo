// frontend/src/pages/PaymentPage.tsx

import React, { useEffect, useState, useRef } from 'react';
import { useLocation, useNavigate, useParams, Link } from 'react-router-dom';
import Spinner from '../components/Spinner';
import Button from '../components/Button';
// Impor semua ikon yang dibutuhkan
import { ArrowLeftIcon, ClockIcon, ShieldCheckIcon, ExclamationTriangleIcon } from '../components/icons/HeroIcons';

// Deklarasikan 'snap' pada objek window agar TypeScript tidak error
declare global {
    interface Window {
        snap: any;
    }
}

const PaymentPage: React.FC = () => {
    const { paymentId } = useParams<{ paymentId: string }>();
    const location = useLocation();
    const navigate = useNavigate();

    // State untuk mengelola tampilan UI halaman
    type PaymentStatus = 'loading' | 'paying' | 'success' | 'error' | 'closed';
    const [status, setStatus] = useState<PaymentStatus>('loading');
    const [errorMessage, setErrorMessage] = useState('');

    // Ambil data yang dikirim dari halaman sebelumnya
    const transactionToken = location.state?.transactionToken;
    // Path kembali default jika tidak ada history
    const fromPath = location.state?.from || '/my-projects';

    // Gunakan ref untuk mencegah useEffect berjalan dua kali di React 18 Strict Mode
    const effectRan = useRef(false);

    useEffect(() => {
        // Validasi awal: pastikan kita punya token
        if (!transactionToken) {
            setErrorMessage('Payment token not found. Please try again from the proposals page.');
            setStatus('error');
            return;
        }

        // Mencegah eksekusi ganda
        if (effectRan.current === true) {
            return;
        }
        effectRan.current = true;

        // 1. Buat elemen script untuk memuat Snap.js dari Midtrans
        const script = document.createElement('script');
        script.src = "https://app.sandbox.midtrans.com/snap/snap.js"; // Gunakan URL produksi untuk live
        script.setAttribute('data-client-key', import.meta.env.VITE_MIDTRANS_CLIENT_KEY); // Ambil dari .env frontend
        script.async = true;

        // 2. Definisikan apa yang terjadi setelah script berhasil dimuat
        script.onload = () => {
            setStatus('paying'); // Tampilkan spinner "Initializing..."

            // 3. Panggil window.snap.pay untuk memunculkan popup pembayaran
            window.snap.pay(transactionToken, {
                onSuccess: (result: any) => {
                    console.log('Payment Success:', result);
                    setStatus('success'); // Ubah UI ke tampilan sukses
                    // Arahkan pengguna kembali secara otomatis setelah 3 detik
                    setTimeout(() => navigate('/my-projects'), 3000);
                },
                onPending: (result: any) => {
                    console.log('Payment Pending:', result);
                    setErrorMessage('Your payment is pending. We will update the project status once payment is confirmed.');
                    setStatus('error');
                },
                onError: (result: any) => {
                    console.error('Payment Error:', result);
                    setErrorMessage('Payment failed. Please try again or use another payment method.');
                    setStatus('error');
                },
                // Handler saat pengguna menutup popup secara manual
                onClose: () => {
                    console.log('Customer closed the popup without finishing the payment');
                    // Hanya ubah status jika pembayaran belum berhasil
                    // (Menggunakan status saat ini, bukan nilai state yang mungkin basi)
                    setStatus(currentStatus => currentStatus !== 'success' ? 'closed' : 'success');
                }
            });
        };

        // 4. Tambahkan script ke body dokumen
        document.body.appendChild(script);

        // 5. Fungsi cleanup untuk menghapus script saat komponen dilepas dari DOM
        return () => {
            const existingScript = document.querySelector(`script[src*="midtrans"]`);
            if (existingScript) {
                document.body.removeChild(existingScript);
            }
            // Reset ref agar bisa berjalan lagi jika komponen di-remount
            effectRan.current = false;
        };
    }, [transactionToken, navigate]);

    // Helper function untuk merender konten UI berdasarkan state 'status'
    const renderContent = () => {
        switch (status) {
            case 'loading':
                return <Spinner size="lg" />;
            case 'paying':
                return (
                    <div className="text-center">
                        <Spinner size="lg" />
                        <p className="mt-4 text-slate-600">Initializing secure payment...</p>
                        <p className="text-sm text-slate-500">Please do not close this window.</p>
                    </div>
                );
            case 'success':
                return (
                    <div className="max-w-md text-center">
                        <ShieldCheckIcon className="mx-auto h-16 w-16 text-green-500" />
                        <h1 className="mt-4 text-3xl font-bold text-green-600">Payment Successful!</h1>
                        <p className="mt-2 text-slate-700">
                            Thank you! We will notify you once the project is ready. Redirecting you shortly...
                        </p>
                    </div>
                );
            case 'closed':
                return (
                    <div className="max-w-md text-center">
                        <ClockIcon className="mx-auto h-16 w-16 text-yellow-500" />
                        <h1 className="mt-4 text-3xl font-bold text-slate-800">Payment Incomplete</h1>
                        <p className="mt-2 text-slate-700">
                            You closed the payment window. The project has not been started.
                        </p>
                        <Link to={fromPath}>
                            <Button variant="outline" className="mt-6 inline-flex items-center">
                                <ArrowLeftIcon className="h-4 w-4 mr-2" /> Back to Previous Page
                            </Button>
                        </Link>
                    </div>
                );
            case 'error':
            default:
                return (
                    <div className="max-w-md text-center">
                        <ExclamationTriangleIcon className="mx-auto h-16 w-16 text-red-500" />
                        <h1 className="mt-4 text-3xl font-bold text-red-600">Payment Issue</h1>
                        <p className="mt-2 text-slate-700">{errorMessage}</p>
                        <Link to={fromPath}>
                            <Button variant="outline" className="mt-6 inline-flex items-center">
                                <ArrowLeftIcon className="h-4 w-4 mr-2" /> Back to Previous Page
                            </Button>
                        </Link>
                    </div>
                );
        }
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-[60vh] py-12 px-4">
            {renderContent()}
        </div>
    );
};

export default PaymentPage;