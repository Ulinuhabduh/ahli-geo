// src/pages/ExpertsPage.tsx

import React, { useState, useEffect, useCallback } from 'react';
import { fetchExperts, fetchAllSkills, fetchAllSoftware } from '../services/apiService';
import ExpertCard from '../components/ExpertCard'; // Impor komponen kartu
import { Expert, Skill } from '../../types';
import Spinner from '../components/Spinner';
import { MagnifyingGlassIcon } from '../components/icons/HeroIcons';

const ExpertsPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [selectedSoftware, setSelectedSoftware] = useState<string[]>([]);
  const [minExperience, setMinExperience] = useState<string>('');
  const [showVerifiedOnly, setShowVerifiedOnly] = useState<boolean>(false);

  const [allSkills, setAllSkills] = useState<Skill[]>([]);
  const [allSoftware, setAllSoftware] = useState<Skill[]>([]);

  const [displayedExperts, setDisplayedExperts] = useState<Expert[]>([]);
  const [isLoadingExperts, setIsLoadingExperts] = useState(true);
  const [isLoadingFilters, setIsLoadingFilters] = useState(true);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [filterOptionsError, setFilterOptionsError] = useState<string | null>(null);

  useEffect(() => {
    const loadFilterOptions = async () => {
      setIsLoadingFilters(true);
      setFilterOptionsError(null);
      try {
        const [skillsData, softwareData] = await Promise.all([
          fetchAllSkills(),
          fetchAllSoftware()
        ]);
        setAllSkills(skillsData || []);
        setAllSoftware(softwareData || []);
      } catch (err: any) {
        setFilterOptionsError(err.message || 'Failed to load filter options.');
      } finally {
        setIsLoadingFilters(false);
      }
    };
    loadFilterOptions();
  }, []);

  const loadExperts = useCallback(async () => {
    setIsLoadingExperts(true);
    setFetchError(null);
    try {
      const expertsData = await fetchExperts({
        searchTerm,
        selectedSkills,
        selectedSoftware,
        minExperience: minExperience ? parseInt(minExperience, 10) : undefined,
        showVerifiedOnly,
      });
      const validExperts = (expertsData || []).filter(expert => expert && expert.id);
      setDisplayedExperts(validExperts);
    } catch (err: any) {
      setFetchError(err.message || 'Failed to fetch experts.');
      setDisplayedExperts([]);
    } finally {
      setIsLoadingExperts(false);
    }
  }, [searchTerm, selectedSkills, selectedSoftware, minExperience, showVerifiedOnly]);

  useEffect(() => {
    // Debounce a little to avoid spamming API on filter changes
    const handler = setTimeout(() => {
      loadExperts();
    }, 300);
    return () => clearTimeout(handler);
  }, [loadExperts]);

  const handleSkillChange = (skillId: string) => setSelectedSkills(prev => prev.includes(skillId) ? prev.filter(s => s !== skillId) : [...prev, skillId]);
  const handleSoftwareChange = (softwareId: string) => setSelectedSoftware(prev => prev.includes(softwareId) ? prev.filter(s => s !== softwareId) : [...prev, softwareId]);

  const FilterCheckbox: React.FC<{ item: Skill, checked: boolean, onChange: (id: string) => void, disabled?: boolean }> = ({ item, checked, onChange, disabled = false }) => (
    <label className={`flex items-center space-x-2 text-sm p-1 rounded ${disabled ? 'text-slate-400 cursor-not-allowed' : 'text-slate-700 hover:bg-slate-50 cursor-pointer'}`}>
      <input type="checkbox" checked={checked} onChange={() => onChange(item.id)} disabled={disabled} className="form-checkbox h-4 w-4 text-cyan-600 rounded" />
      <span>{item.name}</span>
    </label>
  );

  return (
    <div className="container mx-auto">
      <header className="mb-10 text-center"><h1 className="text-4xl font-bold text-slate-800">Find Geoscience Experts</h1><p className="text-lg text-slate-600 mt-2">Connect with top-tier talent in the Indonesian geoscience field.</p></header>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <aside className="md:col-span-1 bg-white p-6 rounded-xl shadow-lg h-fit">
          <h2 className="text-xl font-semibold text-slate-700 mb-6 border-b pb-2">Filter Experts</h2>
          {isLoadingFilters && <div className="py-4"><Spinner size="sm" /><p className="text-xs text-slate-500 text-center mt-1">Loading filters...</p></div>}
          {filterOptionsError && <p className="text-xs text-red-500 mb-2 p-2">{filterOptionsError}</p>}
          {!isLoadingFilters && !filterOptionsError && (
            <>
              <div className="mb-6"><label htmlFor="searchExpert" className="block text-sm font-medium text-slate-700 mb-1">Search Experts</label><div className="relative"><input type="text" id="searchExpert" placeholder="Name, headline..." className="w-full pl-10 pr-3 py-2 border rounded-md" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} disabled={isLoadingExperts} /><MagnifyingGlassIcon className="h-5 w-5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" /></div></div>
              <div className="mb-6"><h3 className="text-md font-semibold text-slate-700 mb-2">Skills</h3><div className="space-y-1 max-h-40 overflow-y-auto pr-2">{allSkills.map(skill => <FilterCheckbox key={skill.id} item={skill} checked={selectedSkills.includes(skill.id)} onChange={handleSkillChange} disabled={isLoadingExperts} />)}</div></div>
              <div className="mb-6"><h3 className="text-md font-semibold text-slate-700 mb-2">Software Proficiency</h3><div className="space-y-1 max-h-40 overflow-y-auto pr-2">{allSoftware.map(sw => <FilterCheckbox key={sw.id} item={sw} checked={selectedSoftware.includes(sw.id)} onChange={handleSoftwareChange} disabled={isLoadingExperts} />)}</div></div>
              <div className="mb-6"><label htmlFor="minExperience" className="block text-sm font-medium text-slate-700 mb-1">Minimum Experience</label><input type="number" id="minExperience" placeholder="e.g., 5" className="w-full p-2 border rounded-md" value={minExperience} onChange={(e) => setMinExperience(e.target.value)} min="0" disabled={isLoadingExperts} /></div>
              <div className="mb-6"><label className={`flex items-center space-x-2 text-sm p-1 rounded ${isLoadingExperts ? 'text-slate-400 cursor-not-allowed' : 'text-slate-700'}`}><input type="checkbox" checked={showVerifiedOnly} onChange={(e) => setShowVerifiedOnly(e.target.checked)} disabled={isLoadingExperts} className="form-checkbox h-4 w-4 text-cyan-600 rounded" /><span>Show Verified Experts Only</span></label></div>
            </>
          )}
        </aside>
        <main className="md:col-span-3">
          {isLoadingExperts ? (
            <div className="flex justify-center items-center h-96"><Spinner size="lg" /></div>
          ) : fetchError ? (
            <div className="text-center py-12 text-red-600">{fetchError}</div>
          ) : displayedExperts.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {displayedExperts.map(expert => (
                <ExpertCard key={expert.id} expert={expert} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12"><p>No experts match your current filters.</p></div>
          )}
        </main>
      </div>
    </div>
  );
};

export default ExpertsPage;