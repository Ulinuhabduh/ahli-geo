import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import Button from '../components/Button';
import { useAuth } from '../contexts/AuthContext';
import { Project, Proposal, User } from '../../types';
import { fetchProjectById, submitProposal as apiSubmitProposal } from '../services/apiService';
import { ArrowLeftIcon, DocumentTextIcon, CheckCircleIcon } from '../components/icons/HeroIcons';
import Spinner from '../components/Spinner';

const SubmitProposalPage: React.FC = () => {
  const { projectId } = useParams<{ projectId: string }>();
  const { user } = useAuth() as { user: User | null };
  const navigate = useNavigate();

  const [project, setProject] = useState<Project | null>(null);
  const [coverLetter, setCoverLetter] = useState('');
  const [bidAmount, setBidAmount] = useState('');
  const [estimatedDeliveryTime, setEstimatedDeliveryTime] = useState('');

  const [error, setError] = useState('');
  const [isLoadingProject, setIsLoadingProject] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!projectId) {
      setError('Project ID is missing.');
      setIsLoadingProject(false);
      return;
    }
    const loadProject = async () => {
      setIsLoadingProject(true);
      try {
        const foundProject = await fetchProjectById(projectId);
        if (foundProject) {
          setProject(foundProject);
        } else {
          setError('Project not found.');
        }
      } catch (err) {
        setError('Failed to load project details.');
        console.error(err);
      } finally {
        setIsLoadingProject(false);
      }
    };
    loadProject();
  }, [projectId]);

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!user || user.role !== 'expert') {
      setError('You must be logged in as an expert to submit a proposal.');
      return;
    }
    if (!project) {
      setError('Project details could not be loaded.');
      return;
    }
    if (!coverLetter.trim()) {
      setError('Cover letter is required.');
      return;
    }

    const numBidAmount = bidAmount ? parseFloat(bidAmount) : undefined;
    if (bidAmount && (isNaN(numBidAmount) || numBidAmount < 0)) {
      setError("Bid amount must be a positive number if provided.");
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      const proposalData = {
        projectId: project.id,
        expertId: user.id, // Will be set by apiService if it takes expertUser
        // expertName: user.name, // Will be set by apiService
        coverLetter: coverLetter.trim(),
        bidAmount: numBidAmount,
        currency: project.currency,
        estimatedDeliveryTime: estimatedDeliveryTime.trim() || undefined,
      };
      const newProposal = await apiSubmitProposal(proposalData, user);

      alert(`Proposal for "${project.title}" submitted successfully!`);
      navigate(`/projects/${project.id}`);
    } catch (err: any) {
      setError(err.message || 'Failed to submit proposal.');
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoadingProject) {
    return <div className="flex justify-center items-center h-screen"><Spinner size="lg" /></div>;
  }

  if ((!project && !isLoadingProject) || error && !project) {
    return (
      <div className="text-center py-20">
        <h1 className="text-3xl font-bold text-slate-700 mb-4">{error || 'Project Not Found'}</h1>
        <p className="text-slate-500 mb-8">The project you are trying to apply to could not be found.</p>
        <Link to="/projects">
          <Button variant="primary" leftIcon={<ArrowLeftIcon className="h-5 w-5" />}>Back to Projects</Button>
        </Link>
      </div>
    );
  }

  if (!project) return null;

  return (
    <div className="min-h-full flex flex-col items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl w-full space-y-8 bg-white p-10 rounded-xl shadow-2xl">
        <div className="text-center">
          <DocumentTextIcon className="mx-auto h-12 w-12 text-cyan-600" />
          <h2 className="mt-4 text-center text-3xl font-extrabold text-slate-900">
            Apply to Project
          </h2>
          <p className="mt-2 text-center text-sm text-slate-600">
            You are applying for: <strong className="text-cyan-700">{project.title}</strong>
          </p>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          {error && !isSubmitting && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
              <span className="block sm:inline">{error}</span>
            </div>
          )}

          <div>
            <label htmlFor="coverLetter" className="block text-sm font-medium text-slate-700">Cover Letter / Proposal Message*</label>
            <textarea id="coverLetter" name="coverLetter" rows={6} required value={coverLetter} onChange={e => setCoverLetter(e.target.value)}
              className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
              placeholder="Explain why you are a good fit for this project. Highlight relevant experience and skills." />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="bidAmount" className="block text-sm font-medium text-slate-700">Your Bid Amount ({project.currency || 'IDR'}, Optional)</label>
              <input id="bidAmount" name="bidAmount" type="number" value={bidAmount} onChange={e => setBidAmount(e.target.value)} min="0"
                className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                placeholder="e.g., 45000000" />
            </div>
            <div>
              <label htmlFor="estimatedDeliveryTime" className="block text-sm font-medium text-slate-700">Estimated Delivery Time (Optional)</label>
              <input id="estimatedDeliveryTime" name="estimatedDeliveryTime" type="text" value={estimatedDeliveryTime} onChange={e => setEstimatedDeliveryTime(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                placeholder="e.g., 3 weeks, 1 month" />
            </div>
          </div>

          <div className="bg-slate-50 p-4 rounded-md border border-slate-200 text-sm text-slate-600">
            <p>Project Budget Range:
              <strong className="text-slate-800 ml-1">
                {project.budgetMin ? `${project.currency} ${project.budgetMin.toLocaleString()}` : 'Not specified'}
                {project.budgetMin && project.budgetMax ? ' - ' : ''}
                {project.budgetMax ? `${project.currency} ${project.budgetMax.toLocaleString()}` : ''}
              </strong>
            </p>
            <p className="mt-1">Ensure your proposal is competitive and clearly outlines your value.</p>
          </div>


          <div className="mt-8">
            <Button
              type="submit"
              variant="primary"
              className="w-full"
              isLoading={isSubmitting}
              leftIcon={<CheckCircleIcon className="h-5 w-5" />}
            >
              Submit Proposal
            </Button>
          </div>
          <div className="text-center mt-4">
            <Link to={`/projects/${project.id}`} className="text-sm font-medium text-cyan-600 hover:text-cyan-500">
              <ArrowLeftIcon className="h-4 w-4 inline mr-1" /> Cancel and return to project
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SubmitProposalPage;
