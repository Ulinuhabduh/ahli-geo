
// import React, { useState, useEffect } from 'react';
// import { Link } from 'react-router-dom';
// import Button from '../components/Button';
// // import { APP_NAME } from '../constants'; // Removed
// import { fetchProjects, fetchExperts } from '../services/apiService';
// import ProjectCard from '../components/ProjectCard';
// import ExpertCard from '../components/ExpertCard';
// import Spinner from '../components/Spinner';
// import { Project, Expert } from '../../types';
// import { MagnifyingGlassIcon, UserGroupIcon, BriefcaseIcon, LightBulbIcon, ShieldCheckIcon, RocketLaunchIcon } from '../components/icons/HeroIcons';

// const APP_NAME = "AhliGeo"; // Hardcoded

// const HomePage: React.FC = () => {
//   const [featuredProjects, setFeaturedProjects] = useState<Project[]>([]);
//   const [featuredExperts, setFeaturedExperts] = useState<Expert[]>([]);
//   const [isLoadingProjects, setIsLoadingProjects] = useState(true);
//   const [isLoadingExperts, setIsLoadingExperts] = useState(true);
//   const [projectsError, setProjectsError] = useState<string | null>(null);
//   const [expertsError, setExpertsError] = useState<string | null>(null);

//   useEffect(() => {
//     const loadFeaturedData = async () => {
//       // Fetch Featured Projects
//       setIsLoadingProjects(true);
//       setProjectsError(null);
//       try {
//         const projects = await fetchProjects({ limit: 2 });
//         setFeaturedProjects(projects || []);
//       } catch (error: any) {
//         console.error("Failed to fetch featured projects (HomePage):", error.message);
//         setProjectsError(error.message || "Could not load featured projects.");
//         setFeaturedProjects([]);
//       } finally {
//         setIsLoadingProjects(false);
//       }

//       // Fetch Featured Experts
//       setIsLoadingExperts(true);
//       setExpertsError(null);
//       try {
//         const experts = await fetchExperts({ limit: 2 });
//         setFeaturedExperts(experts || []);
//       } catch (error: any) {
//         console.error("Failed to fetch featured experts (HomePage):", error.message);
//         setExpertsError(error.message || "Could not load featured experts.");
//         setFeaturedExperts([]);
//       } finally {
//         setIsLoadingExperts(false);
//       }
//     };

//     loadFeaturedData();
//   }, []);

//   const StatCard: React.FC<{ icon: React.ReactNode; value: string; label: string }> = ({ icon, value, label }) => (
//     <div className="bg-white p-6 rounded-lg shadow-md flex items-center space-x-4">
//       <div className="text-cyan-500">{icon}</div>
//       <div>
//         <p className="text-3xl font-bold text-slate-800">{value}</p>
//         <p className="text-slate-600">{label}</p>
//       </div>
//     </div>
//   );

//   const FeatureItem: React.FC<{ icon: React.ReactNode, title: string, description: string }> = ({ icon, title, description }) => (
//     <div className="flex flex-col items-center text-center p-4">
//       <div className="bg-cyan-100 text-cyan-600 p-4 rounded-full mb-4">
//         {icon}
//       </div>
//       <h3 className="text-xl font-semibold text-slate-800 mb-2">{title}</h3>
//       <p className="text-slate-600 leading-relaxed">{description}</p>
//     </div>
//   );


//   return (
//     <div className="space-y-16">
//       {/* Hero Section */}
//       <section className="bg-gradient-to-r from-slate-800 to-slate-700 text-white py-20 px-6 rounded-xl shadow-2xl">
//         <div className="container mx-auto text-center">
//           <MagnifyingGlassIcon className="h-20 w-20 text-cyan-400 mx-auto mb-6" />
//           <h1 className="text-5xl font-extrabold mb-4 leading-tight">
//             Welcome to <span className="text-cyan-400">{APP_NAME}</span>
//           </h1>
//           <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
//             Connecting Indonesia's Industries with Verified Geoscience Experts. <br /> Find specialized talent or your next challenging project.
//           </p>
//           <div className="space-x-4">
//             <Link to="/projects">
//               <Button variant="primary" size="lg" leftIcon={<BriefcaseIcon className="h-5 w-5" />}>
//                 Find Projects
//               </Button>
//             </Link>
//             <Link to="/experts">
//               <Button variant="outline" size="lg" className="bg-transparent hover:bg-cyan-500 hover:text-white text-white border-white" leftIcon={<UserGroupIcon className="h-5 w-5" />}>
//                 Find Experts
//               </Button>
//             </Link>
//           </div>
//         </div>
//       </section>

//       {/* Stats Section - Placeholder */}
//       <section className="py-12">
//         <div className="container mx-auto">
//           <h2 className="text-3xl font-bold text-center text-slate-800 mb-10">Platform Highlights</h2>
//           <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
//             <StatCard icon={<BriefcaseIcon className="h-10 w-10" />} value="100+" label="Active Projects" />
//             <StatCard icon={<UserGroupIcon className="h-10 w-10" />} value="500+" label="Verified Experts" />
//             <StatCard icon={<RocketLaunchIcon className="h-10 w-10" />} value="95%" label="Project Success Rate" />
//           </div>
//         </div>
//       </section>

//       {/* Why Ahli Geo Section */}
//       <section className="py-12 bg-white rounded-xl shadow-lg">
//         <div className="container mx-auto px-6">
//           <h2 className="text-3xl font-bold text-center text-slate-800 mb-12">
//             Why Choose <span className="text-cyan-600">{APP_NAME}</span>?
//           </h2>
//           <div className="grid md:grid-cols-3 gap-8">
//             <FeatureItem
//               icon={<LightBulbIcon className="h-10 w-10" />}
//               title="Niche Focus"
//               description="Dedicated solely to the geoscience industry, ensuring relevant opportunities and expertise."
//             />
//             <FeatureItem
//               icon={<ShieldCheckIcon className="h-10 w-10" />}
//               title="Verified Talent"
//               description="Rigorous verification process for experts, guaranteeing quality and reliability for clients."
//             />
//             <FeatureItem
//               icon={<RocketLaunchIcon className="h-10 w-10" />}
//               title="Efficient Matching"
//               description="Advanced search and filtering tools to quickly connect the right talent with the right projects."
//             />
//           </div>
//         </div>
//       </section>

//       {/* Featured Projects Section */}
//       <section className="py-12">
//         <div className="container mx-auto">
//           <h2 className="text-3xl font-bold text-center text-slate-800 mb-10">Featured Projects</h2>
//           {isLoadingProjects ? (
//             <div className="flex justify-center items-center h-60"> <Spinner /> </div>
//           ) : projectsError ? (
//             <p className="text-center text-red-500">{projectsError}</p>
//           ) : featuredProjects.length > 0 ? (
//             <div className="grid md:grid-cols-2 gap-8">
//               {featuredProjects.map(project => (
//                 <ProjectCard key={project.id} project={project} />
//               ))}
//             </div>
//           ) : (
//             <p className="text-center text-slate-500">No featured projects available at the moment.</p>
//           )}
//           {!isLoadingProjects && !projectsError && (
//             <div className="text-center mt-10">
//               <Link to="/projects">
//                 <Button variant="secondary" size="lg">View All Projects</Button>
//               </Link>
//             </div>
//           )}
//         </div>
//       </section>

//       {/* Featured Experts Section */}
//       <section className="py-12 bg-slate-50 rounded-xl">
//         <div className="container mx-auto">
//           <h2 className="text-3xl font-bold text-center text-slate-800 mb-10">Featured Experts</h2>
//           {isLoadingExperts ? (
//             <div className="flex justify-center items-center h-60"> <Spinner /> </div>
//           ) : expertsError ? (
//             <p className="text-center text-red-500">{expertsError}</p>
//           ) : featuredExperts.length > 0 ? (
//             <div className="grid md:grid-cols-2 gap-8">
//               {featuredExperts.map(expert => (
//                 <ExpertCard key={expert.id} expert={expert} />
//               ))}
//             </div>
//           ) : (
//             <p className="text-center text-slate-500">No featured experts available at the moment.</p>
//           )}
//           {!isLoadingExperts && !expertsError && (
//             <div className="text-center mt-10">
//               <Link to="/experts">
//                 <Button variant="secondary" size="lg">View All Experts</Button>
//               </Link>
//             </div>
//           )}
//         </div>
//       </section>

//       {/* How It Works Section */}
//       <section className="py-16 bg-white rounded-xl shadow-lg">
//         <div className="container mx-auto px-6 text-center">
//           <h2 className="text-3xl font-bold text-slate-800 mb-12">Simple Steps to Get Started</h2>
//           <div className="grid md:grid-cols-2 gap-10">
//             <div className="p-6 rounded-lg border border-cyan-200 bg-cyan-50">
//               <h3 className="text-2xl font-semibold text-cyan-700 mb-4">For Clients</h3>
//               <ol className="list-decimal list-inside text-left space-y-2 text-slate-700">
//                 <li><strong>Post a Project:</strong> Describe your geoscience needs in detail.</li>
//                 <li><strong>Receive Proposals:</strong> Review applications from qualified experts.</li>
//                 <li><strong>Hire & Collaborate:</strong> Select the best fit and start your project.</li>
//                 <li><strong>Secure Payments:</strong> Escrow system ensures peace of mind.</li>
//               </ol>
//             </div>
//             <div className="p-6 rounded-lg border border-teal-200 bg-teal-50">
//               <h3 className="text-2xl font-semibold text-teal-700 mb-4">For Experts</h3>
//               <ol className="list-decimal list-inside text-left space-y-2 text-slate-700">
//                 <li><strong>Create Profile:</strong> Showcase your skills and experience. Get verified.</li>
//                 <li><strong>Find Projects:</strong> Browse relevant opportunities matching your expertise.</li>
//                 <li><strong>Submit Proposals:</strong> Apply to projects that interest you.</li>
//                 <li><strong>Get Paid Securely:</strong> Timely payments upon project completion.</li>
//               </ol>
//             </div>
//           </div>
//         </div>
//       </section>

//     </div>
//   );
// };

// export default HomePage;

// frontend/src/pages/HomePage.tsx

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Button from '../components/Button';
import { fetchProjects, fetchExperts } from '../services/apiService';
import ProjectCard from '../components/ProjectCard';
import ExpertCard from '../components/ExpertCard';
import Spinner from '../components/Spinner';
import { Project, Expert } from '../../types';
import {
  MagnifyingGlassIcon, UserGroupIcon, BriefcaseIcon, LightBulbIcon,
  ShieldCheckIcon, RocketLaunchIcon, CheckCircleIcon, UsersIcon // Tambah ikon baru
} from '../components/icons/HeroIcons';

const APP_NAME = "AhliGeo";

const HomePage: React.FC = () => {
  const [featuredProjects, setFeaturedProjects] = useState<Project[]>([]);
  const [featuredExperts, setFeaturedExperts] = useState<Expert[]>([]);
  const [isLoadingProjects, setIsLoadingProjects] = useState(true);
  const [isLoadingExperts, setIsLoadingExperts] = useState(true);
  const [projectsError, setProjectsError] = useState<string | null>(null);
  const [expertsError, setExpertsError] = useState<string | null>(null);

  useEffect(() => {
    const loadFeaturedData = async () => {
      // Fetch Featured Projects
      setIsLoadingProjects(true);
      setProjectsError(null);
      try {
        const projects = await fetchProjects({ limit: 2, status: 'Open' }); // Ambil proyek Open
        setFeaturedProjects(projects || []);
      } catch (error: any) {
        console.error("Failed to fetch featured projects (HomePage):", error.message);
        setProjectsError(error.message || "Could not load featured projects.");
        setFeaturedProjects([]);
      } finally {
        setIsLoadingProjects(false);
      }

      // Fetch Featured Experts
      setIsLoadingExperts(true);
      setExpertsError(null);
      try {
        const experts = await fetchExperts({ limit: 2 });
        setFeaturedExperts(experts || []);
      } catch (error: any) {
        console.error("Failed to fetch featured experts (HomePage):", error.message);
        setExpertsError(error.message || "Could not load featured experts.");
        setFeaturedExperts([]);
      } finally {
        setIsLoadingExperts(false);
      }
    };
    loadFeaturedData();
  }, []);

  const StatCard: React.FC<{ icon: React.ReactNode; value: string; label: string }> = ({ icon, value, label }) => (
    <div className="bg-white p-6 rounded-lg shadow-md flex items-center space-x-4">
      <div className="text-cyan-500">{icon}</div>
      <div>
        <p className="text-3xl font-bold text-slate-800">{value}</p>
        <p className="text-slate-600">{label}</p>
      </div>
    </div>
  );

  const FeatureItem: React.FC<{ icon: React.ReactNode, title: string, description: string }> = ({ icon, title, description }) => (
    <div className="flex flex-col items-center text-center p-4">
      <div className="bg-cyan-100 text-cyan-600 p-4 rounded-full mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold text-slate-800 mb-2">{title}</h3>
      <p className="text-slate-600 leading-relaxed">{description}</p>
    </div>
  );

  // Komponen baru untuk item benefit
  const BenefitItem: React.FC<{ text: string }> = ({ text }) => (
    <li className="flex items-start">
      <CheckCircleIcon className="h-6 w-6 text-green-500 mr-3 flex-shrink-0 mt-1" />
      <span className="text-slate-700">{text}</span>
    </li>
  );

  return (
    <div className="space-y-16 md:space-y-20"> {/* Menambah sedikit jarak antar seksi */}
      {/* Hero Section - Penyempurnaan Teks */}
      <section className="bg-gradient-to-r from-slate-800 to-slate-700 text-white py-20 md:py-24 px-6 rounded-xl shadow-2xl">
        <div className="container mx-auto text-center">
          <MagnifyingGlassIcon className="h-16 w-16 md:h-20 md:w-20 text-cyan-400 mx-auto mb-6" />
          <h1 className="text-4xl md:text-5xl font-extrabold mb-4 leading-tight">
            Unlock Geoscience Potential with <span className="text-cyan-400">{APP_NAME}</span>
          </h1>
          <p className="text-lg md:text-xl text-slate-300 mb-10 max-w-3xl mx-auto">
            The premier marketplace connecting Indonesia's dynamic industries with top-tier, verified geoscience experts.
            Find specialized talent for your critical projects or discover your next challenging assignment.
          </p>
          <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
            <Link to="/post-project">
              <Button variant="primary" size="lg" className="w-full sm:w-auto" leftIcon={<BriefcaseIcon className="h-5 w-5" />}>
                Post a Project (Clients)
              </Button>
            </Link>
            <Link to="/projects">
              <Button variant="outline" size="lg" className="w-full sm:w-auto bg-transparent hover:bg-cyan-500 hover:text-white text-white border-white" leftIcon={<UserGroupIcon className="h-5 w-5" />}>
                Find Work (Experts)
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* === SEKSI BARU: BENEFITS FOR YOU === */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-slate-800 mb-12">
            Grow with <span className="text-cyan-600">{APP_NAME}</span>
          </h2>
          <div className="grid md:grid-cols-2 gap-10 lg:gap-16">
            {/* Benefits for Clients */}
            <div className="bg-white p-8 rounded-xl shadow-lg border border-slate-200">
              <div className="flex items-center mb-6">
                <BriefcaseIcon className="h-10 w-10 text-cyan-600 mr-4" />
                <h3 className="text-2xl font-semibold text-slate-800">For Clients</h3>
              </div>
              <p className="text-slate-600 mb-6">Access a curated pool of geoscience professionals ready to tackle your most complex challenges.</p>
              <ul className="space-y-3">
                <BenefitItem text="Find specialized talent quickly and efficiently." />
                <BenefitItem text="Ensure project success with verified experts." />
                <BenefitItem text="Manage projects and payments securely in one place." />
                <BenefitItem text="Gain new perspectives and innovative solutions." />
              </ul>
              <Link to="/post-project" className="mt-8 inline-block">
                <Button variant="primary">Get Started & Post Your Project</Button>
              </Link>
            </div>

            {/* Benefits for Experts */}
            <div className="bg-white p-8 rounded-xl shadow-lg border border-slate-200">
              <div className="flex items-center mb-6">
                <UsersIcon className="h-10 w-10 text-teal-600 mr-4" />
                <h3 className="text-2xl font-semibold text-slate-800">For Experts</h3>
              </div>
              <p className="text-slate-600 mb-6">Discover exciting projects that match your skills and build your professional reputation in the geoscience industry.</p>
              <ul className="space-y-3">
                <BenefitItem text="Access a wide range of geoscience projects." />
                <BenefitItem text="Showcase your expertise to leading companies." />
                <BenefitItem text="Enjoy secure and timely payments." />
                <BenefitItem text="Build your portfolio and professional network." />
              </ul>
              <Link to="/register" className="mt-8 inline-block">
                <Button variant="primary" className="bg-teal-600 hover:bg-teal-700">Join as an Expert & Find Work</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section - Dibuat lebih menarik */}
      <section className="py-16">
        <div className="container mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-slate-800 mb-12">Platform at a Glance</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <StatCard icon={<BriefcaseIcon />} value="120+" label="Active Projects" colorClass="text-blue-500" />
            <StatCard icon={<UserGroupIcon />} value="500+" label="Verified Geoscientists" colorClass="text-green-500" />
            <StatCard icon={<RocketLaunchIcon />} value="750+" label="Successful Connections" colorClass="text-purple-500" />
          </div>
        </div>
      </section>

      {/* Why Choose Ahli Geo Section - Desain lebih modern */}
      <section className="py-16 bg-slate-50 rounded-3xl">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-slate-800 mb-4">Why Choose <span className="text-cyan-600">{APP_NAME}</span>?</h2>
          <p className="text-center text-slate-600 mb-16 max-w-2xl mx-auto">We bridge the gap between complex geoscience challenges and the specialized expertise needed to solve them.</p>
          <div className="grid md:grid-cols-3 gap-8">
            <FeatureItem
              icon={<LightBulbIcon className="h-12 w-12" />}
              title="Niche Expertise"
              description="Dedicated to the geoscience sector, ensuring highly relevant projects and talent."
            />
            <FeatureItem
              icon={<ShieldCheckIcon className="h-12 w-12" />}
              title="Verified Professionals"
              description="Our experts undergo a rigorous verification process for guaranteed quality and reliability."
            />
            <FeatureItem
              icon={<MagnifyingGlassIcon className="h-12 w-12" />}
              title="Precision Matching"
              description="Smart tools to quickly connect clients with the ideal geoscientist for their specific needs."
            />
          </div>
        </div>
      </section>

      {/* Featured Projects Section */}
      <section className="py-16">
        <div className="container mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-slate-800 mb-12">Latest Opportunities</h2>
          {isLoadingProjects ? (
            <div className="flex justify-center items-center h-60"> <Spinner /> </div>
          ) : projectsError ? ( // Kondisi untuk error
            <p className="text-center text-red-500">{projectsError}</p>
          ) : featuredProjects.length > 0 ? ( // Kondisi jika ada proyek
            <div className="grid md:grid-cols-1 lg:grid-cols-2 gap-8">
              {featuredProjects.map(project => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
          ) : ( // Kondisi jika tidak ada proyek (setelah loading selesai dan tidak ada error)
            <p className="text-center text-slate-500 py-10">No featured projects available at the moment.</p>
          )}

          {!isLoadingProjects && !projectsError && featuredProjects.length > 0 && ( // Tampilkan tombol hanya jika ada proyek
            <div className="text-center mt-10">
              <Link to="/projects">
                <Button variant="secondary" size="lg">View All Projects</Button>
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* Featured Experts Section */}
      <section className="py-16 px-16 bg-slate-800 text-white rounded-t-3xl">
        <div className="container mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Meet Our Top Experts</h2>
          {isLoadingExperts ? (
            <div className="flex justify-center items-center h-60"> <Spinner /> </div>
          ) : expertsError ? (
            <p className="text-center text-red-400">{expertsError}</p>
          ) : featuredExperts.length > 0 ? (
            <div className="grid md:grid-cols-1 lg:grid-cols-2 gap-8">
              {featuredExperts.map(expert => (
                <ExpertCard key={expert.id} expert={expert} />
              ))}
            </div>
          ) : (
            <p className="text-center text-slate-300 py-10">No featured experts available at the moment.</p>
          )}
          {/* ===================================================== */}
          {!isLoadingExperts && !expertsError && featuredExperts.length > 0 && (
            <div className="text-center mt-10">
              <Link to="/experts">
                <Button variant="outline" size="lg" className="text-white border-cyan-400 hover:bg-cyan-500 hover:text-slate-900">View All Experts</Button>
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* How It Works Section - Lebih visual */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-800 mb-16">Getting Started is Easy</h2>
          <div className="grid md:grid-cols-2 gap-x-12 gap-y-10">
            <div className="text-left p-8 rounded-xl shadow-lg border border-slate-200 hover:border-cyan-500 transition-colors">
              <div className="flex items-center mb-4">
                <div className="bg-cyan-500 text-white rounded-full h-10 w-10 flex items-center justify-center text-xl font-bold mr-4">1</div>
                <h3 className="text-2xl font-semibold text-cyan-700">For Clients</h3>
              </div>
              <ol className="space-y-3 text-slate-700">
                <li><strong>Define Your Needs:</strong> Clearly outline your project scope and requirements.</li>
                <li><strong>Discover Talent:</strong> Browse expert profiles or receive tailored proposals.</li>
                <li><strong>Collaborate Securely:</strong> Hire with confidence and manage your project seamlessly.</li>
              </ol>
            </div>
            <div className="text-left p-8 rounded-xl shadow-lg border border-slate-200 hover:border-teal-500 transition-colors">
              <div className="flex items-center mb-4">
                <div className="bg-teal-500 text-white rounded-full h-10 w-10 flex items-center justify-center text-xl font-bold mr-4">2</div>
                <h3 className="text-2xl font-semibold text-teal-700">For Experts</h3>
              </div>
              <ol className="space-y-3 text-slate-700">
                <li><strong>Showcase Your Expertise:</strong> Build a compelling profile that highlights your skills.</li>
                <li><strong>Find Opportunities:</strong> Explore projects that match your specialization.</li>
                <li><strong>Deliver Excellence:</strong> Apply your knowledge and get paid securely.</li>
              </ol>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;