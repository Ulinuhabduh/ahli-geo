import React, { useState, useEffect } from 'react';
import { fetchProjects, fetchAllSkills, fetchAllSoftware } from '../services/apiService';
import ProjectCard from '../components/ProjectCard';
import { Project, Skill } from '../../types';
import Spinner from '../components/Spinner';
import { MagnifyingGlassIcon } from '../components/icons/HeroIcons';

const ProjectsPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [selectedSoftware, setSelectedSoftware] = useState<string[]>([]);
  const [locationType, setLocationType] = useState<string>('');

  const [allSkills, setAllSkills] = useState<Skill[]>([]);
  const [allSoftware, setAllSoftware] = useState<Skill[]>([]);

  const [displayedProjects, setDisplayedProjects] = useState<Project[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [filtersLoaded, setFiltersLoaded] = useState(false);

  useEffect(() => {
    const loadInitialData = async () => {
      try {
        const [skillsData, softwareData] = await Promise.all([
          fetchAllSkills(),
          fetchAllSoftware()
        ]);
        setAllSkills(skillsData);
        setAllSoftware(softwareData);
      } catch (err) {
        setError('Failed to load filter options.');
        console.error(err);
      } finally {
        setFiltersLoaded(true); // <-- Tandai bahwa filter sudah selesai dimuat
      }
    };
    loadInitialData();
  }, []);

  useEffect(() => {
    // JANGAN JALANKAN useEffect ini jika filter belum selesai dimuat
    if (!filtersLoaded) {
      return;
    }

    const loadProjects = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const projects = await fetchProjects({
          searchTerm,
          selectedSkills,
          selectedSoftware,
          locationType,
        });
        setDisplayedProjects(projects);
      } catch (err: any) { // <-- Beri tipe 'any' atau 'Error' pada err
        setError(err.message || 'Failed to fetch projects.');
        console.error(err);
        setDisplayedProjects([]);
      } finally {
        setIsLoading(false);
      }
    };

    // Gunakan debounce untuk mencegah pemanggilan API yang terlalu sering saat user mengetik
    const debounceLoad = setTimeout(() => {
      loadProjects();
    }, 300); // Tunggu 300ms setelah user berhenti mengetik/mengklik

    return () => clearTimeout(debounceLoad); // Cleanup timeout

  }, [searchTerm, selectedSkills, selectedSoftware, locationType, filtersLoaded]); // <-- Tambahkan filtersLoaded ke dependency array

  const handleSkillChange = (skillId: string) => {
    setSelectedSkills(prev =>
      prev.includes(skillId) ? prev.filter(s => s !== skillId) : [...prev, skillId]
    );
  };

  const handleSoftwareChange = (softwareId: string) => {
    setSelectedSoftware(prev =>
      prev.includes(softwareId) ? prev.filter(s => s !== softwareId) : [...prev, softwareId]
    );
  };

  const FilterCheckbox: React.FC<{ item: Skill, checked: boolean, onChange: (id: string) => void }> = ({ item, checked, onChange }) => (
    <label key={item.id} className="flex items-center space-x-2 text-sm text-slate-700 hover:bg-slate-50 p-1 rounded">
      <input
        type="checkbox"
        checked={checked}
        onChange={() => onChange(item.id)}
        className="form-checkbox h-4 w-4 text-cyan-600 border-slate-300 rounded focus:ring-cyan-500"
      />
      <span>{item.name}</span>
    </label>
  );

  return (
    <div className="container mx-auto">
      <header className="mb-10 text-center">
        <h1 className="text-4xl font-bold text-slate-800">Find Geoscience Projects</h1>
        <p className="text-lg text-slate-600 mt-2">Discover exciting opportunities in the Indonesian geoscience sector.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Filters Sidebar */}
        <aside className="md:col-span-1 bg-white p-6 rounded-xl shadow-lg h-fit">
          <h2 className="text-xl font-semibold text-slate-700 mb-6 border-b pb-2">Filter Projects</h2>

          <div className="mb-6">
            <label htmlFor="search" className="block text-sm font-medium text-slate-700 mb-1">Search Keywords</label>
            <div className="relative">
              <input
                type="text"
                id="search"
                placeholder="Project title, client..."
                className="w-full pl-10 pr-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <MagnifyingGlassIcon className="h-5 w-5 text-slate-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-md font-semibold text-slate-700 mb-2">Skills</h3>
            {allSkills.length === 0 && <p className="text-xs text-slate-400">Loading skills...</p>}
            <div className="space-y-1 max-h-48 overflow-y-auto pr-2">
              {allSkills.map(skill => (
                <FilterCheckbox key={skill.id} item={skill} checked={selectedSkills.includes(skill.id)} onChange={handleSkillChange} />
              ))}
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-md font-semibold text-slate-700 mb-2">Software</h3>
            {allSoftware.length === 0 && <p className="text-xs text-slate-400">Loading software...</p>}
            <div className="space-y-1 max-h-48 overflow-y-auto pr-2">
              {allSoftware.map(softwareItem => (
                <FilterCheckbox key={softwareItem.id} item={softwareItem} checked={selectedSoftware.includes(softwareItem.id)} onChange={handleSoftwareChange} />
              ))}
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-md font-semibold text-slate-700 mb-2">Location Type</h3>
            <select
              value={locationType}
              onChange={(e) => setLocationType(e.target.value)}
              className="w-full p-2 border border-slate-300 rounded-md shadow-sm focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
            >
              <option value="">All</option>
              <option value="Remote">Remote</option>
              <option value="On-Site">On-Site</option>
              <option value="Hybrid">Hybrid</option>
            </select>
          </div>
        </aside>

        {/* Projects List */}
        <main className="md:col-span-3">
          {isLoading ? (
            <div className="flex justify-center items-center h-96">
              <Spinner size="lg" />
            </div>
          ) : error ? (
            <div className="text-center py-12 text-red-500">
              <p>{error}</p>
            </div>
          ) : displayedProjects.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {displayedProjects.map(project => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <MagnifyingGlassIcon className="h-16 w-16 text-slate-400 mx-auto mb-4" />
              <p className="text-xl text-slate-600">No projects match your current filters.</p>
              <p className="text-sm text-slate-500 mt-1">Try adjusting your search criteria.</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default ProjectsPage;
