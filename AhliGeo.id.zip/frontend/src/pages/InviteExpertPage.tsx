// src/pages/InviteExpertPage.tsx
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { fetchProjects, sendInvitation } from '../services/apiService';
import { Project, ProjectStatus } from '../../types';
import Button from '../components/Button';
import Spinner from '../components/Spinner';

const InviteExpertPage: React.FC = () => {
    const { expertId } = useParams<{ expertId: string }>();
    const { user } = useAuth();
    const navigate = useNavigate();

    const [openProjects, setOpenProjects] = useState<Project[]>([]);
    const [selectedProjectId, setSelectedProjectId] = useState<string>('');
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        if (user) {
            fetchProjects({ clientId: user.id, status: ProjectStatus.OPEN })
                .then(projects => {
                    setOpenProjects(projects);
                    if (projects.length > 0) {
                        setSelectedProjectId(projects[0].id);
                    }
                })
                .catch(() => setError('Failed to load your open projects.'))
                .finally(() => setIsLoading(false));
        }
    }, [user]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!selectedProjectId || !expertId) {
            setError('Please select a project.');
            return;
        }
        setIsLoading(true);
        try {
            await sendInvitation(expertId, selectedProjectId);
            alert('Invitation sent successfully!');
            navigate(`/experts/${expertId}`);
        } catch (err: any) {
            setError(err.message || 'Failed to send invitation.');
        } finally {
            setIsLoading(false);
        }
    };

    if (isLoading) return <Spinner />;

    return (
        <div className="max-w-lg mx-auto">
            <h1 className="text-2xl font-bold">Invite Expert to a Project</h1>
            {error && <p className="text-red-500">{error}</p>}
            {openProjects.length === 0 ? (
                <p>You have no open projects to send an invitation for.</p>
            ) : (
                <form onSubmit={handleSubmit} className="space-y-4 mt-6">
                    <select
                        value={selectedProjectId}
                        onChange={e => setSelectedProjectId(e.target.value)}
                        className="w-full p-2 border rounded"
                    >
                        {openProjects.map(p => (
                            <option key={p.id} value={p.id}>{p.title}</option>
                        ))}
                    </select>
                    <Button type="submit" isLoading={isLoading}>Send Invitation</Button>
                </form>
            )}
        </div>
    );
};

export default InviteExpertPage;