// frontend/src/pages/AboutPage.tsx

import React from 'react';
import { GlobeAltIcon, UsersIcon, LightBulbIcon } from '../components/icons/HeroIcons'; // Sesuaikan ikon

const APP_NAME = "AhliGeo";

const AboutPage: React.FC = () => {
    return (
        <div className="py-12 md:py-20 bg-slate-50">
            <div className="container mx-auto px-4 max-w-4xl">
                <header className="text-center mb-16">
                    <GlobeAltIcon className="h-16 w-16 text-cyan-500 mx-auto mb-6" />
                    <h1 className="text-4xl md:text-5xl font-extrabold text-slate-800 mb-4">
                        About <span className="text-cyan-600">{APP_NAME}</span>
                    </h1>
                    <p className="text-lg text-slate-600">
                        Connecting Indonesia's Geoscience Potential with Global Opportunities.
                    </p>
                </header>

                <div className="bg-white p-8 md:p-12 rounded-xl shadow-xl space-y-8">
                    <section>
                        <h2 className="text-2xl font-semibold text-slate-800 mb-4 flex items-center">
                            <LightBulbIcon className="h-7 w-7 text-cyan-600 mr-3" />
                            Our Mission
                        </h2>
                        <p className="text-slate-700 leading-relaxed">
                            At {APP_NAME}, our mission is to empower the geoscience community in Indonesia by creating a seamless and trusted platform for professionals and industries to connect, collaborate, and thrive. We aim to unlock the vast potential of Indonesian geoscience talent and facilitate groundbreaking projects that contribute to sustainable development.
                        </p>
                        {/* Tambahkan lebih banyak paragraf di sini */}
                    </section>

                    <section>
                        <h2 className="text-2xl font-semibold text-slate-800 mb-4 flex items-center">
                            <UsersIcon className="h-7 w-7 text-cyan-600 mr-3" />
                            Our Vision
                        </h2>
                        <p className="text-slate-700 leading-relaxed">
                            We envision {APP_NAME} as the leading digital hub for geoscience in Indonesia and Southeast Asia, fostering a vibrant ecosystem where innovation flourishes, expertise is readily accessible, and every project finds its perfect match of skills and opportunity.
                        </p>
                        {/* Tambahkan lebih banyak paragraf di sini */}
                    </section>

                    <section>
                        <h2 className="text-2xl font-semibold text-slate-800 mb-4">The Team</h2>
                        <p className="text-slate-700 leading-relaxed">
                            {APP_NAME} was founded by a passionate group of geoscientists and technology enthusiasts dedicated to advancing the industry. We believe in the power of collaboration and the importance of specialized knowledge.
                        </p>
                        {/* Anda bisa menambahkan detail tim di sini jika mau */}
                    </section>
                </div>
            </div>
        </div>
    );
};

export default AboutPage;