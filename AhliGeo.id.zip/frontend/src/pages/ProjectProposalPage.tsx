// src/pages/ProjectProposalsPage.tsx

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link, useLocation } from 'react-router-dom';
import { createPaymentForProposal, fetchProjectById, fetchProposalsForProject } from '../services/apiService';
import { Project, Proposal } from '../../types';
import Spinner from '../components/Spinner';
import Button from '../components/Button';
import { UserGroupIcon, ArrowLeftIcon } from '../components/icons/HeroIcons';
import { useAuth } from '../contexts/AuthContext';
import ConfirmationModal from '../components/ConfirmationModal'; // Impor komponen modal baru

const ProjectProposalsPage: React.FC = () => {
    const { projectId } = useParams<{ projectId: string }>();
    const navigate = useNavigate();
    const { user } = useAuth();
    const location = useLocation();

    // State untuk data dari API
    const [project, setProject] = useState<Project | null>(null);
    const [proposals, setProposals] = useState<Proposal[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');

    // State untuk mengontrol modal konfirmasi
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedProposal, setSelectedProposal] = useState<Proposal | null>(null);

    // Menentukan path untuk tombol kembali berdasarkan history navigasi
    const backPath = location.state?.from || `/projects/${projectId}`;
    const getBackButtonText = () => {
        const fromPath = location.state?.from;
        if (fromPath) {
            if (fromPath.includes('/dashboard')) return 'Back to Dashboard';
            if (fromPath.includes('/my-projects')) return 'Back to My Projects';
        }
        return 'Back to Project Details';
    };
    const backButtonText = getBackButtonText();

    // useEffect untuk mengambil data proyek dan proposal saat komponen dimuat
    useEffect(() => {
        if (!projectId) {
            navigate('/my-projects');
            return;
        }
        const loadData = async () => {
            setIsLoading(true);
            setError('');
            try {
                // Ambil data proyek dan proposal secara paralel untuk efisiensi
                const [projectData, proposalsData] = await Promise.all([
                    fetchProjectById(projectId),
                    fetchProposalsForProject(projectId)
                ]);

                // Validasi: pastikan proyek ada dan pengguna berwenang
                if (!projectData || projectData.clientId !== user?.id) {
                    setError("Project not found or you are not authorized to view its proposals.");
                    setIsLoading(false);
                    return;
                }
                setProject(projectData);
                setProposals(proposalsData);
            } catch (err: any) {
                setError(err.message || 'Failed to load data.');
            } finally {
                setIsLoading(false);
            }
        };
        if (user) loadData();
    }, [projectId, user, navigate]);

    // Fungsi ini dipanggil saat tombol "Accept & Start Project" diklik.
    // Tugasnya hanya menyimpan proposal yang dipilih dan membuka modal.
    const handleAcceptClick = (proposal: Proposal) => {
        setSelectedProposal(proposal);
        setIsModalOpen(true);
    };

    // Fungsi ini dieksekusi HANYA JIKA pengguna menekan tombol konfirmasi di dalam modal.
    // Tugasnya adalah memanggil API untuk memulai proses pembayaran.
    const executeAcceptProposal = async () => {
        if (!selectedProposal) return; // Pengaman jika proposal tidak terpilih

        try {
            // Panggil API untuk membuat transaksi pembayaran
            const { paymentId, transactionToken } = await createPaymentForProposal(selectedProposal.id);
            // Arahkan ke halaman pembayaran dengan membawa token
            navigate(`/payment/${paymentId}`, {
                state: { transactionToken, from: location.pathname } // Kirim path asal untuk tombol kembali
            });
        } catch (error: any) {
            // Tampilkan error jika gagal memulai pembayaran
            alert(`Failed to initiate payment: ${error.message}`);
        }
    };

    if (isLoading) return <div className="text-center p-12"><Spinner size="lg" /></div>;
    if (error) return <div className="text-center p-12 text-red-500">{error}</div>;

    return (
        // Gunakan React Fragment (<>) agar bisa merender modal di level root
        <>
            <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
                <Link
                    to={backPath}
                    className="inline-flex items-center text-sm font-medium text-cyan-600 hover:text-cyan-800 mb-6 transition-colors"
                >
                    <ArrowLeftIcon className="h-4 w-4 mr-2" />
                    {backButtonText}
                </Link>

                <div className="space-y-8 bg-white p-8 sm:p-10 rounded-xl shadow-lg border">
                    <div className="text-center border-b border-slate-200 pb-6">
                        <UserGroupIcon className="mx-auto h-12 w-12 text-indigo-600" />
                        <h1 className="mt-4 text-center text-3xl font-extrabold text-slate-900">Received Proposals</h1>
                        <p className="mt-2 text-center text-sm text-slate-500">
                            For project: <span className="font-semibold">{project?.title}</span>
                        </p>
                    </div>
                    {proposals.length === 0 ? (
                        <p className="text-center text-slate-500 py-8">No proposals have been submitted for this project yet.</p>
                    ) : (
                        <div className="space-y-6">
                            {proposals.map(p => (
                                <div key={p.id} className="p-6 border border-slate-200 rounded-lg shadow-sm transition-all hover:border-cyan-300 hover:shadow-md">
                                    <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                                        <div>
                                            <Link
                                                to={`/experts/${p.expertId}`}
                                                state={{ from: location.pathname }}
                                                className="text-lg font-bold text-slate-800 hover:text-cyan-600"
                                            >
                                                {p.expertName}
                                            </Link>
                                            <p className="text-sm text-slate-500">{p.expertHeadline}</p>
                                        </div>
                                        {p.proposedRate ? (
                                            <div className="text-left sm:text-right flex-shrink-0 bg-green-50 p-3 rounded-md border border-green-200">
                                                <p className="text-sm text-green-700">Proposed Bid</p>
                                                <p className="font-bold text-xl text-green-600">
                                                    {project?.currency || 'IDR'} {Number(p.proposedRate).toLocaleString()}
                                                </p>
                                            </div>
                                        ) : (
                                            <div className="text-left sm:text-right flex-shrink-0 bg-slate-50 p-3 rounded-md border">
                                                <p className="text-sm text-slate-500">No bid specified</p>
                                            </div>
                                        )}
                                    </div>
                                    <div className="my-4 pt-4 border-t border-slate-200">
                                        <h4 className="text-sm font-semibold text-slate-600 mb-2">Cover Letter:</h4>
                                        <p className="text-slate-700 whitespace-pre-wrap text-sm leading-relaxed bg-slate-50 p-4 rounded-md">
                                            {p.coverLetter}
                                        </p>
                                    </div>
                                    <div className="flex justify-end items-center mt-4">
                                        {project?.status === 'Open' && p.status === 'Pending' && (
                                            <Button onClick={() => handleAcceptClick(p)} variant="primary">
                                                Accept & Start Project
                                            </Button>
                                        )}
                                        {p.status !== 'Pending' && (
                                            <span className={`text-sm font-semibold px-3 py-1.5 rounded-full ${p.status === 'Accepted' ? 'bg-green-100 text-green-800 ring-1 ring-inset ring-green-200' : 'bg-red-100 text-red-800 ring-1 ring-inset ring-red-200'}`}>
                                                Status: {p.status}
                                            </span>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>

            {/* Komponen Modal Konfirmasi dirender di sini */}
            <ConfirmationModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onConfirm={executeAcceptProposal}
                title="Confirm Hiring Process"
                confirmText="Yes, Proceed to Payment"
                cancelText="No, Go Back"
            >
                Are you sure you want to hire <span className="font-bold">{selectedProposal?.expertName}</span> and start the payment process?
            </ConfirmationModal>
        </>
    );
};

export default ProjectProposalsPage;