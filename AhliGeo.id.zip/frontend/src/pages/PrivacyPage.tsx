// frontend/src/pages/PrivacyPage.tsx

import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldCheckIcon } from '../components/icons/HeroIcons';

const APP_NAME = "AhliGeo";

const PrivacyPage: React.FC = () => {
    return (
        <div className="py-12 md:py-20 bg-slate-100">
            <div className="container mx-auto px-4 max-w-3xl">
                <header className="text-center mb-12 md:mb-16">
                    <div className="inline-block p-4 bg-cyan-100 rounded-full mb-6">
                        <ShieldCheckIcon className="h-12 w-12 md:h-16 md:w-16 text-cyan-600" />
                    </div>
                    <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900">
                        Privacy Policy
                    </h1>
                    <p className="text-slate-600 mt-3 text-lg">
                        Last Updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                    </p>
                </header>

                <div className="max-w-3xl mx-auto bg-white p-8 md:p-12 rounded-xl shadow-2xl border border-slate-200">
                    <article
                        className="
              prose prose-slate 
              lg:prose-lg 
              max-w-none 
              prose-headings:font-semibold prose-headings:text-slate-900 prose-headings:mb-3 prose-headings:mt-8
              prose-p:text-slate-700 prose-p:leading-relaxed prose-p:mb-5
              prose-ul:list-disc prose-ul:pl-5 prose-ul:space-y-2 prose-ul:text-slate-700
              prose-ol:list-decimal prose-ol:pl-5 prose-ol:space-y-2 prose-ol:text-slate-700
              prose-a:text-cyan-600 prose-a:font-medium hover:prose-a:text-cyan-700 hover:prose-a:underline
              prose-strong:font-semibold prose-strong:text-slate-800
            "
                    >
                        <h2>1. Introduction</h2>
                        <p>Welcome to {APP_NAME} ("we," "our," or "us"). We are committed to protecting your personal information and your right to privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website and use our services (collectively, the "Service"). Please read this privacy policy carefully. If you do not agree with the terms of this privacy policy, please do not access the service.</p>

                        <h2>2. Information We Collect</h2>
                        <p>We may collect information about you in a variety of ways. The information we may collect via the Service includes:</p>
                        <h3>Personal Data</h3>
                        <p>Personally identifiable information, such as your name, shipping address, email address, and telephone number, and demographic information, such as your age, gender, hometown, and interests, that you voluntarily give to us when you register with the Service or when you choose to participate in various activities related to the Service, such as online chat and message boards.</p>
                        <h3>Derivative Data</h3>
                        <p>Information our servers automatically collect when you access the Service, such as your IP address, your browser type, your operating system, your access times, and the pages you have viewed directly before and after accessing the Service.</p>
                        {/* ... Tambahkan jenis data lain yang Anda kumpulkan ... */}

                        <h2>3. How We Use Your Information</h2>
                        <p>Having accurate information about you permits us to provide you with a smooth, efficient, and customized experience. Specifically, we may use information collected about you via the Service to:</p>
                        <ul>
                            <li>Create and manage your account.</li>
                            <li>Facilitate project postings and proposal submissions.</li>
                            <li>Enable user-to-user communications.</li>
                            <li>Process payments and refunds.</li>
                            <li>Email you regarding your account or order.</li>
                            <li>Monitor and analyze usage and trends to improve your experience with the Service.</li>
                            <li>Notify you of updates to the Service.</li>
                            {/* ... Tambahkan lebih banyak poin ... */}
                        </ul>

                        <h2>4. Disclosure of Your Information</h2>
                        <p>We may share information we have collected about you in certain situations. Your information may be disclosed as follows:</p>
                        <h3>By Law or to Protect Rights</h3>
                        <p>If we believe the release of information about you is necessary to respond to legal process, to investigate or remedy potential violations of our policies, or to protect the rights, property, and safety of others, we may share your information as permitted or required by any applicable law, rule, or regulation.</p>
                        <h3>Third-Party Service Providers</h3>
                        <p>We may share your information with third parties that perform services for us or on our behalf, including payment processing (e.g., Midtrans), data analysis, email delivery, hosting services, customer service, and marketing assistance.</p>
                        {/* ... Tambahkan lebih banyak kondisi pembagian informasi ... */}

                        <h2>5. Security of Your Information</h2>
                        <p>We use administrative, technical, and physical security measures to help protect your personal information. While we have taken reasonable steps to secure the personal information you provide to us, please be aware that despite our efforts, no security measures are perfect or impenetrable, and no method of data transmission can be guaranteed against any interception or other type of misuse.</p>

                        <h2>6. Policy for Children</h2>
                        <p>We do not knowingly solicit information from or market to children under the age of 13 (or a higher age as required by applicable law). If we learn that we have collected personal information from a child under such age without verification of parental consent, we will delete that information as quickly as possible.</p>

                        <h2>7. Your Privacy Rights</h2>
                        <p>Depending on your location, you may have certain rights regarding your personal information, such as the right to access, correct, or delete your personal data. To make such a request, please use the contact information provided below.</p>

                        <h2>8. Updates To This Policy</h2>
                        <p>We may update this privacy policy from time to time. The updated version will be indicated by an updated "Last Updated" date and the updated version will be effective as soon as it is accessible. We encourage you to review this privacy policy frequently to be informed of how we are protecting your information.</p>

                        <h2>9. Contact Us</h2>
                        <p>If you have questions or comments about this policy, or if you would like to exercise one of your privacy rights, you may <Link to="/contact">contact us</Link> at <a href="mailto:privacy@ahligeo.com" className="text-cyan-600 hover:underline">privacy@ahligeo.com</a>.</p>
                    </article>
                </div>
            </div>
        </div>
    );
};

export default PrivacyPage;