// src/pages/ChatPage.tsx

import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getMyChatSessions, getMessages, sendMessage } from '../services/apiService';
import { ChatSession, ChatMessage, User } from '../../types';
import { useAuth } from '../contexts/AuthContext';
import Spinner from '../components/Spinner';
import Button from '../components/Button';
import { PaperAirplaneIcon } from '../components/icons/HeroIcons';

// ===================================
// Komponen Chat Sidebar (Inbox)
// ===================================
const ChatSidebar: React.FC<{
  sessions: ChatSession[];
  activeSessionId: string | null;
  onSelectSession: (sessionId: string) => void;
  isLoading: boolean;
}> = ({ sessions, activeSessionId, onSelectSession, isLoading }) => (
  <aside className="w-full md:w-1/3 border-r border-slate-200 flex flex-col bg-slate-50">
    <div className="p-4 border-b border-slate-200">
      <h2 className="text-xl font-bold text-slate-800">Messages</h2>
    </div>
    {isLoading ? (
      <div className="flex-grow flex items-center justify-center">
        <Spinner />
      </div>
    ) : (
      <ul className="overflow-y-auto flex-grow">
        {sessions.length === 0 ? (
          <li className="p-4 text-center text-sm text-slate-500">No conversations yet.</li>
        ) : (
          sessions.map(session => (
            <li
              key={session.sessionId}
              onClick={() => onSelectSession(session.sessionId)}
              className={`flex items-center space-x-3 p-4 cursor-pointer border-l-4 ${activeSessionId === session.sessionId ? 'bg-white border-cyan-500' : 'border-transparent hover:bg-slate-100'}`}
            >
              <img
                src={session.recipientProfileImageUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(session.recipientName)}`}
                alt={session.recipientName}
                className="h-12 w-12 rounded-full object-cover"
              />
              <div className="flex-1 overflow-hidden">
                <p className="font-semibold text-slate-800">{session.recipientName}</p>
                <p className="text-sm text-slate-500 truncate">{session.lastMessage || 'No messages yet'}</p>
              </div>
            </li>
          ))
        )}
      </ul>
    )}
  </aside>
);

// ===================================
// Komponen Jendela Chat
// ===================================
const ChatWindow: React.FC<{
  sessionId: string;
  currentUser: User;
  recipientName?: string;
}> = ({ sessionId, currentUser, recipientName }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const messagesEndRef = useRef<null | HTMLDivElement>(null);
  const chatContainerRef = useRef<null | HTMLDivElement>(null); // Ref untuk kontainer chat

  // useEffect untuk fetch data pesan
  useEffect(() => {
    setIsLoading(true);
    getMessages(sessionId)
      .then(setMessages)
      .catch(console.error)
      .finally(() => setIsLoading(false));
  }, [sessionId]);

  // Sebagai gantinya, buat fungsi scroll yang bisa dipanggil manual
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // useEffect ini sekarang HANYA untuk scroll ke paling bawah
  // saat pertama kali pesan selesai dimuat. Ini yang kita inginkan.
  useEffect(() => {
    if (!isLoading) {
      if (chatContainerRef.current) {
        chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
      }
    }
  }, [isLoading, messages]); // Dipicu saat loading selesai


  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    const textToSend = newMessage;
    setNewMessage('');

    // Optimistic UI update: tambahkan pesan baru ke state sebelum API call selesai
    const tempMessage: ChatMessage = {
      id: `temp-${Date.now()}`,
      senderId: currentUser.id,
      messageText: textToSend,
      createdAt: new Date().toISOString(),
      // properti lain jika ada
    };
    setMessages(prev => [...prev, tempMessage]);

    // Scroll ke bawah SETELAH pesan baru ditambahkan ke UI
    // Menggunakan setTimeout untuk memastikan DOM sudah update
    setTimeout(scrollToBottom, 0);

    try {
      const sentMessage = await sendMessage(sessionId, textToSend);
      // Ganti pesan sementara dengan pesan asli dari server
      setMessages(prev => prev.map(msg => msg.id === tempMessage.id ? sentMessage : msg));
    } catch (error) {
      console.error("Failed to send message", error);
      // Jika gagal, kembalikan input dan hapus pesan sementara
      setNewMessage(textToSend);
      setMessages(prev => prev.filter(msg => msg.id !== tempMessage.id));
      alert('Failed to send message.');
    }
  };

  if (isLoading) return <div className="flex-1 flex items-center justify-center"><Spinner /></div>;

  return (
    <div className="flex-1 flex flex-col bg-white">
      <header className="p-4 border-b border-slate-200">
        <h3 className="font-bold text-lg">{recipientName || 'Conversation'}</h3>
      </header>
      {/* Tambahkan ref ke kontainer chat */}
      <div ref={chatContainerRef} className="flex-grow p-6 overflow-y-auto bg-slate-50">
        <div className="space-y-4">
          {messages.map(msg => (
            <div key={msg.id} className={`flex items-end gap-2 ${msg.senderId === currentUser.id ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-2xl ${msg.senderId === currentUser.id ? 'bg-cyan-500 text-white rounded-br-none' : 'bg-slate-200 text-slate-800 rounded-bl-none'}`}>
                <p>{msg.messageText}</p>
              </div>
            </div>
          ))}
        </div>
        <div ref={messagesEndRef} />
      </div>
      <div className="p-4 bg-white border-t border-slate-200">
        <form onSubmit={handleSendMessage} className="flex items-center space-x-3">
          <input
            type="text" value={newMessage} onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type a message..." autoComplete="off"
            className="flex-1 p-2 border border-slate-300 rounded-lg focus:ring-cyan-500 focus:border-cyan-500"
          />
          <Button type="submit" variant="primary" className="!p-3 rounded-full flex-shrink-0">
            <PaperAirplaneIcon className="h-5 w-5" />
          </Button>
        </form>
      </div>
    </div>
  );
};

// ===================================
// Komponen Halaman Utama Chat
// ===================================
const ChatPage: React.FC = () => {
  const { sessionId: activeSessionIdFromUrl } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [isLoadingSessions, setIsLoadingSessions] = useState(true);

  useEffect(() => {
    setIsLoadingSessions(true);
    getMyChatSessions()
      .then(fetchedSessions => {
        setSessions(fetchedSessions);
        // Jika URL tidak punya sessionId, dan ada sesi, arahkan ke yang pertama
        if (!activeSessionIdFromUrl && fetchedSessions.length > 0) {
          navigate(`/chat/${fetchedSessions[0].sessionId}`, { replace: true });
        }
      })
      .catch(console.error)
      .finally(() => setIsLoadingSessions(false));
  }, [activeSessionIdFromUrl, navigate]);

  if (!user) {
    return <div className="flex h-full items-center justify-center"><Spinner size="lg" /></div>;
  }

  const activeSession = sessions.find(s => s.sessionId === activeSessionIdFromUrl);

  return (
    <div className="flex h-[calc(100vh-200px)] border bg-white rounded-lg shadow-lg overflow-hidden">
      <ChatSidebar
        sessions={sessions}
        activeSessionId={activeSessionIdFromUrl || null}
        onSelectSession={(sessionId) => navigate(`/chat/${sessionId}`)}
        isLoading={isLoadingSessions}
      />
      {activeSessionIdFromUrl ? (
        <ChatWindow
          sessionId={activeSessionIdFromUrl}
          currentUser={user}
          recipientName={activeSession?.recipientName}
        />
      ) : (
        <div className="hidden md:flex flex-1 items-center justify-center text-slate-500">
          <p>Select a conversation from the list to start chatting.</p>
        </div>
      )}
    </div>
  );
};

export default ChatPage;