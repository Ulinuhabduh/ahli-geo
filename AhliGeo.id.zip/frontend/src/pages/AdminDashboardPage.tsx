// frontend/src/pages/AdminDashboardPage.tsx

import React from 'react';
import { Link } from 'react-router-dom';
import { UserGroupIcon, FolderIcon, Cog6ToothIcon } from '../components/icons/HeroIcons';

const AdminDashboardPage: React.FC = () => {
    const adminLinks = [
        {
            name: 'Manage Users',
            description: 'View, edit, and delete user accounts.',
            path: '/admin/users',
            icon: <UserGroupIcon className="h-8 w-8 text-cyan-600" />,
            bgColor: 'bg-cyan-50',
        },
        {
            name: 'Manage Projects',
            description: 'View, edit, and manage all projects on the platform.',
            path: '/admin/projects', // Kita akan buat halaman ini nanti
            icon: <FolderIcon className="h-8 w-8 text-indigo-600" />,
            bgColor: 'bg-indigo-50',
        },
        {
            name: 'Settings',
            description: 'Configure platform-wide settings and parameters.',
            path: '/admin/settings', // Kita akan buat halaman ini nanti
            icon: <Cog6ToothIcon className="h-8 w-8 text-slate-600" />,
            bgColor: 'bg-slate-50',
        },
    ];

    return (
        <div className="container mx-auto px-4 py-8">
            <h1 className="text-3xl font-bold text-slate-800 mb-2">Admin Dashboard</h1>
            <p className="text-slate-600 mb-8">Welcome, Admin. Select an option below to manage the platform.</p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {adminLinks.map((link) => (
                    <Link
                        key={link.name}
                        to={link.path}
                        className={`block p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 ${link.bgColor}`}
                    >
                        <div className="flex items-center mb-3">
                            {link.icon}
                            <h2 className="ml-4 text-xl font-bold text-slate-900">{link.name}</h2>
                        </div>
                        <p className="text-slate-700">{link.description}</p>
                    </Link>
                ))}
            </div>
        </div>
    );
};

export default AdminDashboardPage;