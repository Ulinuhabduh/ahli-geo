import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import Button from '../components/Button';
import { useAuth } from '../contexts/AuthContext';
import { Expert, ProjectLocation, User } from '../../types';
import { fetchExpertById, postProject as apiPostProject } from '../services/apiService';
import { ArrowLeftIcon, BriefcaseIcon, CheckCircleIcon } from '../components/icons/HeroIcons';
import Spinner from '../components/Spinner';

const HireExpertPage: React.FC = () => {
  const { expertId } = useParams<{ expertId: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [expert, setExpert] = useState<Expert | null>(null);
  const [projectTitle, setProjectTitle] = useState('');
  const [projectDescription, setProjectDescription] = useState('');
  const [budgetMin, setBudgetMin] = useState('');
  const [budgetMax, setBudgetMax] = useState('');
  const [currency, setCurrency] = useState('IDR');

  const [error, setError] = useState('');
  const [isLoadingExpert, setIsLoadingExpert] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!expertId) {
      setError('Expert ID is missing.');
      setIsLoadingExpert(false);
      return;
    }
    const loadExpert = async () => {
      setIsLoadingExpert(true);
      try {
        const foundExpert = await fetchExpertById(expertId);
        if (foundExpert) {
          setExpert(foundExpert);
        } else {
          setError('Expert not found.');
        }
      } catch (err) {
        setError('Failed to load expert details.');
        console.error(err);
      } finally {
        setIsLoadingExpert(false);
      }
    };
    loadExpert();
  }, [expertId]);

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!user || user.role !== 'client') {
      setError('You must be logged in as a client to hire an expert.');
      return;
    }
    if (!expert) {
      setError('Expert details could not be loaded.');
      return;
    }
    if (!projectTitle.trim() || !projectDescription.trim()) {
      setError('Project Title and Description are required.');
      return;
    }

    const numBudgetMin = budgetMin ? parseFloat(budgetMin) : undefined;
    const numBudgetMax = budgetMax ? parseFloat(budgetMax) : undefined;

    if (numBudgetMin && isNaN(numBudgetMin) || (numBudgetMax && isNaN(numBudgetMax))) {
      setError("Budget values must be numbers.");
      return;
    }
    if (numBudgetMin && numBudgetMax && numBudgetMin > numBudgetMax) {
      setError("Minimum budget cannot be greater than maximum budget.");
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      const projectData = {
        title: projectTitle,
        description: projectDescription,
        clientId: user.id,
        clientName: user.companyName || user.name,
        assignedExpertId: expert.id,
        isDirectHire: true,
        budgetMin: numBudgetMin,
        budgetMax: numBudgetMax,
        currency: currency,
        requiredSkills: [],
        requiredSoftware: [],
        locationType: ProjectLocation.REMOTE,
      };
      const newProject = await apiPostProject(projectData, user as User);

      alert(`Project proposal "${newProject.title}" sent to ${expert.name}!`);
      navigate(`/projects/${newProject.id}`);
    } catch (err: any) {
      setError(err.message || 'Failed to send project proposal.');
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoadingExpert) {
    return <div className="flex justify-center items-center h-screen"><Spinner size="lg" /></div>;
  }

  if ((!expert && !isLoadingExpert) || error && !expert) {
    return (
      <div className="text-center py-20">
        <h1 className="text-3xl font-bold text-slate-700 mb-4">{error || 'Expert Not Found'}</h1>
        <p className="text-slate-500 mb-8">{error ? error : 'The expert you are trying to hire could not be found.'}</p>
        <Link to="/experts">
          <Button variant="primary" leftIcon={<ArrowLeftIcon className="h-5 w-5" />}>Back to Experts</Button>
        </Link>
      </div>
    );
  }

  if (!expert) return null;

  return (
    <div className="min-h-full flex flex-col items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl w-full space-y-8 bg-white p-10 rounded-xl shadow-2xl">
        <div className="text-center">
          <BriefcaseIcon className="mx-auto h-12 w-12 text-cyan-600" />
          <h2 className="mt-4 text-center text-3xl font-extrabold text-slate-900">
            Propose Project to {expert.name}
          </h2>
          <p className="mt-2 text-center text-sm text-slate-600">
            Outline your project requirements to engage <span className="font-semibold">{expert.name.split(' ')[0]}</span> directly.
          </p>
          <div className="mt-4 text-sm text-slate-500">
            Expert Headline: <span className="italic">{expert.headline}</span>
          </div>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          {error && !isSubmitting && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
              <span className="block sm:inline">{error}</span>
            </div>
          )}

          <div>
            <label htmlFor="projectTitle" className="block text-sm font-medium text-slate-700">Project Title*</label>
            <input id="projectTitle" name="projectTitle" type="text" required value={projectTitle} onChange={e => setProjectTitle(e.target.value)}
              className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
              placeholder="e.g., Urgent Seismic Data Review" />
          </div>

          <div>
            <label htmlFor="projectDescription" className="block text-sm font-medium text-slate-700">Project Description*</label>
            <textarea id="projectDescription" name="projectDescription" rows={5} required value={projectDescription} onChange={e => setProjectDescription(e.target.value)}
              className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
              placeholder="Describe the project scope, deliverables, and any specific requirements." />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label htmlFor="budgetMin" className="block text-sm font-medium text-slate-700">Min Budget (Optional)</label>
              <input id="budgetMin" name="budgetMin" type="number" value={budgetMin} onChange={e => setBudgetMin(e.target.value)} min="0"
                className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                placeholder="e.g., 10000000" />
            </div>
            <div>
              <label htmlFor="budgetMax" className="block text-sm font-medium text-slate-700">Max Budget (Optional)</label>
              <input id="budgetMax" name="budgetMax" type="number" value={budgetMax} onChange={e => setBudgetMax(e.target.value)} min="0"
                className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                placeholder="e.g., 20000000" />
            </div>
            <div>
              <label htmlFor="currency" className="block text-sm font-medium text-slate-700">Currency</label>
              <select id="currency" name="currency" value={currency} onChange={e => setCurrency(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-slate-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm">
                <option value="IDR">IDR</option>
                <option value="USD">USD</option>
              </select>
            </div>
          </div>


          <div className="mt-8">
            <Button
              type="submit"
              variant="primary"
              className="w-full"
              isLoading={isSubmitting}
              leftIcon={<CheckCircleIcon className="h-5 w-5" />}
            >
              Send Project Proposal
            </Button>
          </div>
          <div className="text-center mt-4">
            <Link to={`/experts/${expertId}`} className="text-sm font-medium text-cyan-600 hover:text-cyan-500">
              <ArrowLeftIcon className="h-4 w-4 inline mr-1" /> Cancel and return to profile
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
};

export default HireExpertPage;