// frontend/src/pages/AdminManageUsersPage.tsx

import React, { useState, useEffect, useMemo } from 'react';
import { User } from '../../types';
import { adminGetAllUsers, adminDeleteUser, adminRestoreUser } from '../services/apiService';
import Spinner from '../components/Spinner';
import ConfirmationModal from '../components/ConfirmationModal';
import { CheckCircleIcon, XCircleIcon, PencilIcon, TrashIcon, ArrowUturnLeftIcon } from '../components/icons/HeroIcons';
import toast from 'react-hot-toast'; // Import toast

type UserRoleTab = 'admin' | 'expert' | 'client';

const AdminManageUsersPage: React.FC = () => {
    const [allUsers, setAllUsers] = useState<User[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [activeTab, setActiveTab] = useState<UserRoleTab>('expert');
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [userToDelete, setUserToDelete] = useState<User | null>(null);

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                setLoading(true);
                const data = await adminGetAllUsers();
                setAllUsers(data);
            } catch (err: any) {
                console.error(err);
                toast.error(err.message || 'Failed to fetch users.');
            } finally {
                setLoading(false);
            }
        };
        fetchUsers();
    }, []);

    const filteredUsers = useMemo(() => {
        return allUsers.filter(user => user.role === activeTab);
    }, [allUsers, activeTab]);

    const openDeleteModal = (user: User) => {
        setUserToDelete(user);
        setIsDeleteModalOpen(true);
    };

    const closeDeleteModal = () => {
        setUserToDelete(null);
        setIsDeleteModalOpen(false);
    };

    const handleDeleteConfirm = async () => {
        if (!userToDelete) return;

        const promise = adminDeleteUser(userToDelete.id);

        toast.promise(promise, {
            loading: `Deactivating ${userToDelete.name}...`,
            success: (deactivatedUser) => {
                setAllUsers(prevUsers =>
                    prevUsers.map(u =>
                        u.id === userToDelete.id
                            ? { ...u, deletedAt: deactivatedUser.deletedAt || new Date().toISOString() }
                            : u
                    )
                );
                return `User ${userToDelete.name} has been deactivated.`;
            },
            error: (err) => `Error: ${err.message || 'Failed to deactivate user.'}`,
        });

        closeDeleteModal();
    };

    const handleRestoreUser = (user: User) => {
        const promise = adminRestoreUser(user.id);

        toast.promise(promise, {
            loading: `Restoring ${user.name}...`,
            success: (restoredUser) => {
                setAllUsers(prevUsers =>
                    prevUsers.map(u =>
                        u.id === user.id ? restoredUser : u
                    )
                );
                return `User ${user.name} has been restored.`;
            },
            error: (err) => `Error: ${err.message || 'Failed to restore user.'}`,
        });
    };

    const handleEditUser = (userId: string) => {
        toast('Edit feature coming soon!', { icon: '🚧' });
    };

    const getTabClass = (tabName: UserRoleTab) => {
        return `px-4 py-2 text-sm font-medium rounded-md cursor-pointer transition-colors duration-200 ${activeTab === tabName
            ? 'bg-cyan-600 text-white shadow'
            : 'text-slate-600 hover:bg-slate-200'
            }`;
    };

    if (loading) return <div className="flex justify-center items-center h-64"><Spinner /></div>;

    return (
        <>
            <div className="container mx-auto px-4 py-8">
                <h1 className="text-3xl font-bold text-slate-800 mb-6">Manage Users</h1>

                <div className="mb-6 flex space-x-2 p-1 bg-slate-100 rounded-lg">
                    <div onClick={() => setActiveTab('expert')} className={getTabClass('expert')}>Experts</div>
                    <div onClick={() => setActiveTab('client')} className={getTabClass('client')}>Clients</div>
                    <div onClick={() => setActiveTab('admin')} className={getTabClass('admin')}>Admins</div>
                </div>

                <div className="bg-white shadow-md rounded-lg overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200">
                        <thead className="bg-slate-50">
                            <tr>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Name</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Email</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Profile Setup</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-slate-200">
                            {filteredUsers.length > 0 ? filteredUsers.map((user) => (
                                <tr key={user.id} className={`transition-colors duration-300 ${user.deletedAt ? 'bg-slate-100 text-slate-500' : 'hover:bg-slate-50'}`}>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <div className={`text-sm font-medium ${user.deletedAt ? '' : 'text-slate-900'}`}>{user.name}</div>
                                        {user.deletedAt && <span className="text-xs text-red-600 font-semibold">(Deactivated)</span>}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm">{user.email}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                                        {user.profileSetupCompleted ? <CheckCircleIcon className="h-6 w-6 text-green-500" /> : <XCircleIcon className="h-6 w-6 text-red-500" />}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        {!user.deletedAt ? (
                                            <>
                                                <button onClick={() => handleEditUser(user.id)} className="text-indigo-600 hover:text-indigo-900 mr-4" aria-label={`Edit ${user.name}`}>
                                                    <PencilIcon className="h-5 w-5" />
                                                </button>
                                                <button onClick={() => openDeleteModal(user)} className="text-red-600 hover:text-red-900" aria-label={`Delete ${user.name}`}>
                                                    <TrashIcon className="h-5 w-5" />
                                                </button>
                                            </>
                                        ) : (
                                            <button onClick={() => handleRestoreUser(user)} className="flex items-center text-green-600 hover:text-green-900" aria-label={`Restore ${user.name}`}>
                                                <ArrowUturnLeftIcon className="h-5 w-5 mr-1" />
                                                <span>Restore</span>
                                            </button>
                                        )}
                                    </td>
                                </tr>
                            )) : (
                                <tr>
                                    <td colSpan={4} className="px-6 py-4 text-center text-slate-500">
                                        No users found in this category.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <ConfirmationModal
                isOpen={isDeleteModalOpen}
                onClose={closeDeleteModal}
                onConfirm={handleDeleteConfirm}
                title="Deactivate User"
            >
                <p className="text-sm text-slate-600">
                    Are you sure you want to deactivate the user <span className="font-semibold">{userToDelete?.name}</span>?
                    They will no longer be able to log in.
                </p>
            </ConfirmationModal>
        </>
    );
};

export default AdminManageUsersPage;