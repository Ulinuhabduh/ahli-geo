// frontend/src/pages/PostProjectPage.tsx

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../components/Button';
import { useAuth } from '../contexts/AuthContext';
import { Skill as SkillType, ProjectLocation, User } from '../../types';
import { postProject as apiPostProject, fetchAllSkills, fetchAllSoftware } from '../services/apiService';
import { DocumentPlusIcon, CheckCircleIcon } from '../components/icons/HeroIcons';
import Spinner from '../components/Spinner';
// --- PERUBAHAN 1: Impor komponen MultiSelectCombobox ---
import { MultiSelectCombobox } from '../components/MultiSelectCombobox';
import toast from 'react-hot-toast'; // Impor toast untuk feedback, jika diperlukan

const PostProjectPage: React.FC = () => {
  const { user } = useAuth() as { user: User | null };
  const navigate = useNavigate();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [budgetMin, setBudgetMin] = useState('');
  const [budgetMax, setBudgetMax] = useState('');
  const [currency, setCurrency] = useState('IDR');
  // --- PERUBAHAN 2: Ubah tipe state untuk menyimpan objek lengkap ---
  const [selectedSkills, setSelectedSkills] = useState<SkillType[]>([]);
  const [selectedSoftware, setSelectedSoftware] = useState<SkillType[]>([]);
  const [locationType, setLocationType] = useState<ProjectLocation>(ProjectLocation.REMOTE);
  const [specificLocation, setSpecificLocation] = useState('');
  const [deadlineDate, setDeadlineDate] = useState('');

  const [availableSkills, setAvailableSkills] = useState<SkillType[]>([]);
  const [availableSoftware, setAvailableSoftware] = useState<SkillType[]>([]);

  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isFormLoading, setIsFormLoading] = useState(true);

  useEffect(() => {
    const loadFormOptions = async () => {
      setIsFormLoading(true);
      try {
        const [skillsData, softwareData] = await Promise.all([
          fetchAllSkills(),
          fetchAllSoftware()
        ]);
        setAvailableSkills(skillsData || []);
        setAvailableSoftware(softwareData || []);
      } catch (err) {
        console.error("Failed to load form options", err);
        setError("Could not load form options. Please try refreshing.");
        toast.error("Could not load form options. Please try refreshing.");
      } finally {
        setIsFormLoading(false);
      }
    };
    loadFormOptions();
  }, []);

  // --- PERUBAHAN 3: Hapus handleSkillToggle, handleSoftwareToggle, dan SkillCheckbox ---
  // Fungsi-fungsi ini tidak lagi diperlukan karena MultiSelectCombobox mengelola logikanya sendiri.

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setIsSubmitting(true);
    setError('');

    if (!title || !description) {
      setError('Project Title and Description are required.');
      setIsSubmitting(false);
      return;
    }
    if (!user) {
      setError('You must be logged in to post a project.');
      navigate('/login'); // Arahkan ke login jika tidak ada user
      setIsSubmitting(false);
      return;
    }

    const numBudgetMin = budgetMin ? parseFloat(budgetMin) : undefined;
    const numBudgetMax = budgetMax ? parseFloat(budgetMax) : undefined;

    if ((numBudgetMin && isNaN(numBudgetMin)) || (numBudgetMax && isNaN(numBudgetMax))) {
      setError("Budget values must be numbers.");
      setIsSubmitting(false);
      return;
    }
    if (numBudgetMin && numBudgetMax && numBudgetMin > numBudgetMax) {
      setError("Minimum budget cannot be greater than maximum budget.");
      setIsSubmitting(false);
      return;
    }

    try {
      const projectData = {
        title,
        description,
        clientId: user.id,
        clientName: user.companyName || user.name,
        budgetMin: numBudgetMin,
        budgetMax: numBudgetMax,
        currency,
        // --- PERUBAHAN 5: Gunakan state langsung karena sudah berisi objek lengkap ---
        requiredSkills: selectedSkills,
        requiredSoftware: selectedSoftware,
        locationType,
        specificLocation: locationType === ProjectLocation.ON_SITE || locationType === ProjectLocation.HYBRID ? specificLocation : undefined,
        deadlineDate: deadlineDate || undefined,
      };

      await apiPostProject(projectData);
      toast.success("Project posted successfully!");
      navigate('/my-projects'); // Arahkan ke daftar proyek milik client

    } catch (err: any) {
      setError(err.message || 'Failed to post project.');
      console.error(err);
      toast.error(err.message || 'Failed to post project.');
    } finally {
      setIsSubmitting(false);
    }
  };


  if (isFormLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner size="lg" />
      </div>
    );
  }


  return (
    <div className="min-h-full bg-slate-50 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl w-full mx-auto space-y-8">
        <div className="bg-white p-8 md:p-10 rounded-xl shadow-lg">
          <div className="text-center mb-8">
            <DocumentPlusIcon className="mx-auto h-12 w-12 text-cyan-600" />
            <h2 className="mt-4 text-center text-3xl font-extrabold text-slate-900">
              Post a New Geoscience Project
            </h2>
            <p className="mt-2 text-center text-sm text-slate-600">
              Describe your project needs to attract qualified geoscience experts.
            </p>
          </div>
          <form className="space-y-6" onSubmit={handleSubmit}>
            {error && (
              <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <span className="block sm:inline">{error}</span>
              </div>
            )}

            <div>
              <label htmlFor="title" className="block text-sm font-medium text-slate-700">Project Title*</label>
              <input id="title" name="title" type="text" required value={title} onChange={e => setTitle(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                placeholder="e.g., Seismic Data Interpretation for Block Alpha" />
            </div>

            <div>
              <label htmlFor="description" className="block text-sm font-medium text-slate-700">Project Description*</label>
              <textarea id="description" name="description" rows={5} required value={description} onChange={e => setDescription(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                placeholder="Provide a detailed overview of the project, scope, objectives, and deliverables." />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label htmlFor="budgetMin" className="block text-sm font-medium text-slate-700">Min Budget (Optional)</label>
                <input id="budgetMin" name="budgetMin" type="number" value={budgetMin} onChange={e => setBudgetMin(e.target.value)} min="0"
                  className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                  placeholder="e.g., 50000000" />
              </div>
              <div>
                <label htmlFor="budgetMax" className="block text-sm font-medium text-slate-700">Max Budget (Optional)</label>
                <input id="budgetMax" name="budgetMax" type="number" value={budgetMax} onChange={e => setBudgetMax(e.target.value)} min="0"
                  className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                  placeholder="e.g., 100000000" />
              </div>
              <div>
                <label htmlFor="currency" className="block text-sm font-medium text-slate-700">Currency</label>
                <select id="currency" name="currency" value={currency} onChange={e => setCurrency(e.target.value)}
                  className="mt-1 block w-full px-3 py-2 border border-slate-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm">
                  <option value="IDR">IDR</option>
                  <option value="USD">USD</option>
                </select>
              </div>
            </div>

            {/* --- PERUBAHAN 4: Ganti grid checkbox dengan MultiSelectCombobox --- */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Required Skills</label>
                <MultiSelectCombobox 
                    options={availableSkills}
                    setOptions={setAvailableSkills}
                    selected={selectedSkills}
                    onChange={setSelectedSkills}
                    placeholder="Search or add required skills..."
                    type="skill"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Required Software</label>
                <MultiSelectCombobox 
                    options={availableSoftware}
                    setOptions={setAvailableSoftware}
                    selected={selectedSoftware}
                    onChange={setSelectedSoftware}
                    placeholder="Search or add required software..."
                    type="software"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="locationType" className="block text-sm font-medium text-slate-700">Location Type*</label>
                <select id="locationType" name="locationType" required value={locationType} onChange={e => setLocationType(e.target.value as ProjectLocation)}
                  className="mt-1 block w-full px-3 py-2 border border-slate-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm">
                  {Object.values(ProjectLocation).map(loc => <option key={loc} value={loc}>{loc}</option>)}
                </select>
              </div>
              {(locationType === ProjectLocation.ON_SITE || locationType === ProjectLocation.HYBRID) && (
                <div className="animate-fade-in">
                  <label htmlFor="specificLocation" className="block text-sm font-medium text-slate-700">Specific Location/City</label>
                  <input id="specificLocation" name="specificLocation" type="text" value={specificLocation} onChange={e => setSpecificLocation(e.target.value)}
                    className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                    placeholder="e.g., Jakarta, Remote option for Bandung" />
                </div>
              )}
            </div>

            <div>
              <label htmlFor="deadlineDate" className="block text-sm font-medium text-slate-700">Application Deadline (Optional)</label>
              <input id="deadlineDate" name="deadlineDate" type="date" value={deadlineDate} onChange={e => setDeadlineDate(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm" />
            </div>

            <div className="pt-4">
              <Button
                type="submit"
                variant="primary"
                className="w-full"
                isLoading={isSubmitting}
                leftIcon={<CheckCircleIcon className="h-5 w-5" />}
                disabled={isSubmitting || isFormLoading}
              >
                Post Project
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default PostProjectPage;