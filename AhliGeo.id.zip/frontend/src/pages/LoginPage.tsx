// // src/pages/LoginPage.tsx

// import React, { useState, useEffect } from 'react';
// import { Link, useNavigate, useLocation } from 'react-router-dom';
// import Button from '../components/Button';
// import { useAuth } from '../contexts/AuthContext';
// import { loginUser as apiLoginUser } from '../services/apiService'; // 1. Impor kembali apiLoginUser
// import { ArrowRightOnRectangleIcon } from '../components/icons/HeroIcons';

// const APP_NAME = "AhliGeo";

// const LoginPage: React.FC = () => {
//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');
//   const [error, setError] = useState('');
//   const [isLoading, setIsLoading] = useState(false);
//   const [successMessage, setSuccessMessage] = useState('');

//   const { login: contextLogin } = useAuth();
//   const navigate = useNavigate();
//   const location = useLocation();

//   useEffect(() => {
//     if (location.state?.message) {
//       setSuccessMessage(location.state.message);
//       const state = { ...location.state };
//       delete state.message;
//       window.history.replaceState(state, document.title);
//     }
//   }, [location]);

//   // ===== FUNGSI INI YANG DIPERBAIKI =====
//   const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
//     event.preventDefault();
//     setIsLoading(true);
//     setError('');
//     setSuccessMessage('');

//     try {
//       // 2. Panggil API service secara langsung untuk mendapatkan user dan token
//       const response = await apiLoginUser(email, password);

//       // 3. Pastikan respons dari API valid
//       if (response && response.user && response.token) {
//         const { user, token } = response;

//         // 4. Panggil fungsi login dari context untuk menyimpan state secara global
//         contextLogin(user, token);

//         const from = location.state?.from?.pathname;

//         // Tentukan path dashboard default berdasarkan peran pengguna
//         let dashboardPath: string;
//         switch (user.role) {
//           case 'admin':
//             dashboardPath = '/admin/dashboard';
//             break;
//           case 'expert':
//             dashboardPath = '/dashboard/expert';
//             break;
//           case 'client':
//           default:
//             dashboardPath = '/dashboard/client';
//             break;
//         }

//         // Tentukan tujuan akhir: gunakan 'from' jika ada, jika tidak gunakan dashboardPath
//         const redirectTo = (from && from !== '/') ? from : dashboardPath;

//         navigate(redirectTo, { replace: true });
//       } else {
//         throw new Error("Invalid response from login API.");
//       }

//     } catch (err: any) {
//       setError(err.message || 'Login failed. Please check your credentials.');
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   return (
//     <div className="min-h-full flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
//       <div className="max-w-md w-full space-y-8 bg-white p-10 rounded-xl shadow-2xl">
//         <div>
//           <h2 className="mt-6 text-center text-4xl font-extrabold text-slate-900">
//             Login to <span className="text-cyan-600">{APP_NAME}</span>
//           </h2>
//           <p className="mt-2 text-center text-sm text-slate-600">
//             Access your account to find projects or experts.
//           </p>
//         </div>

//         {successMessage && (
//           <div className="bg-green-100 border-l-4 border-green-500 text-green-700 p-4" role="alert">
//             <p>{successMessage}</p>
//           </div>
//         )}

//         {error && (
//           <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
//             <span>{error}</span>
//           </div>
//         )}

//         <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
//           <div className="rounded-md shadow-sm -space-y-px">
//             <div>
//               <label htmlFor="email-address" className="sr-only">Email address</label>
//               <input id="email-address" name="email" type="email" autoComplete="email" required className="appearance-none rounded-none relative block w-full px-3 py-3 border border-slate-300 placeholder-slate-500 text-slate-900 rounded-t-md focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 focus:z-10 sm:text-sm" placeholder="Email address" value={email} onChange={(e) => setEmail(e.target.value)} />
//             </div>
//             <div>
//               <label htmlFor="password-login" className="sr-only">Password</label>
//               <input id="password-login" name="password" type="password" autoComplete="current-password" required className="appearance-none rounded-none relative block w-full px-3 py-3 border border-slate-300 placeholder-slate-500 text-slate-900 rounded-b-md focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 focus:z-10 sm:text-sm" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
//             </div>
//           </div>
//           <div className="flex items-center justify-end">
//             <div className="text-sm"><a href="#" className="font-medium text-cyan-600 hover:text-cyan-500">Forgot your password?</a></div>
//           </div>
//           <div>
//             <Button type="submit" variant="primary" className="w-full" isLoading={isLoading} leftIcon={<ArrowRightOnRectangleIcon className="h-5 w-5" />} >
//               Sign in
//             </Button>
//           </div>
//         </form>
//         <p className="mt-6 text-center text-sm text-slate-600">
//           Don't have an account?{' '}<Link to="/register" className="font-medium text-cyan-600 hover:text-cyan-500">Register here</Link>
//         </p>
//       </div>
//     </div>
//   );
// };

// export default LoginPage;

// frontend/src/pages/LoginPage.tsx

import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import Button from '../components/Button';
import { useAuth } from '../contexts/AuthContext';
import { loginUser as apiLoginUser } from '../services/apiService';
import { ArrowRightOnRectangleIcon, EnvelopeIcon, LockClosedIcon, GlobeAltIcon } from '../components/icons/HeroIcons';
import InputWithIcon from '../components/InputWithIcon'; // <-- IMPOR BARU
import toast from 'react-hot-toast'; // <-- IMPOR TOAST

const APP_NAME = "AhliGeo";

const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const { login: contextLogin } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    // Menggunakan toast untuk pesan sukses dari halaman registrasi
    if (location.state?.message) {
      toast.success(location.state.message);
      // Bersihkan state agar pesan tidak muncul lagi saat navigasi
      const state = { ...location.state };
      delete state.message;
      window.history.replaceState(state, document.title);
    }
  }, [location]);

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setIsLoading(true);

    try {
      const response = await apiLoginUser(email, password);
      if (response && response.user && response.token) {
        const { user, token } = response;
        contextLogin(user, token);

        const from = location.state?.from?.pathname;
        let dashboardPath: string;
        switch (user.role) {
          case 'admin': dashboardPath = '/admin/dashboard'; break;
          case 'expert': dashboardPath = '/dashboard/expert'; break;
          default: dashboardPath = '/my-projects'; // Client dashboard
        }
        const redirectTo = (from && from !== '/') ? from : dashboardPath;
        navigate(redirectTo, { replace: true });
      } else {
        throw new Error("Invalid response from login API.");
      }
    } catch (err: any) {
      // Menggunakan toast untuk pesan error
      toast.error(err.message || 'Login failed. Please check your credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-150px)] flex bg-white">
      {/* Kolom Kiri - Branding (Hanya tampil di layar besar) */}
      <div className="hidden lg:flex w-1/2 bg-slate-900 flex-col items-center justify-center p-12 text-center text-cyan-400">
        <GlobeAltIcon className="h-32 w-32" />
        <h1 className="text-5xl font-bold mb-4">AhliGeo</h1>
        <p className="text-xl text-slate-300">Connecting Geoscience Talent with Opportunity.</p>
        {/* Anda bisa menambahkan ilustrasi atau gambar di sini */}
      </div>

      {/* Kolom Kanan - Form Login */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <div className="max-w-md w-full space-y-8">
          <div>
            <h2 className="text-center text-4xl font-extrabold text-slate-900">
              Welcome Back
            </h2>
            <p className="mt-2 text-center text-sm text-slate-600">
              Login to access your {APP_NAME} account.
            </p>
          </div>

          <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
            <div className="space-y-4">
              <InputWithIcon
                id="email-address"
                name="email"
                type="email"
                autoComplete="email"
                required
                placeholder="Email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                icon={<EnvelopeIcon className="h-5 w-5 text-slate-400" />}
              />
              <InputWithIcon
                id="password-login"
                name="password"
                type="password"
                autoComplete="current-password"
                required
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                icon={<LockClosedIcon className="h-5 w-5 text-slate-400" />}
              />
            </div>
            
            <div className="flex items-center justify-end">
              <div className="text-sm">
                <a href="#" onClick={() => toast.error('Feature not implemented yet!')} className="font-medium text-cyan-600 hover:text-cyan-500">
                  Forgot your password?
                </a>
              </div>
            </div>

            <div>
              <Button type="submit" variant="primary" className="w-full" isLoading={isLoading} leftIcon={<ArrowRightOnRectangleIcon className="h-5 w-5" />}>
                Sign in
              </Button>
            </div>
          </form>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-300" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="bg-white px-2 text-slate-500">Or continue with</span>
            </div>
          </div>

          <div>
            <div className="grid grid-cols-2 gap-3">
              <Button variant="secondary" onClick={() => toast('Google Login coming soon!')}>
                  <span className="text-xl mr-2">G</span> Google
              </Button>
              <Button variant="secondary" onClick={() => toast('LinkedIn Login coming soon!')}>
                  <span className="font-bold text-xl mr-2">in</span> LinkedIn
              </Button>
            </div>
          </div>

          <p className="mt-6 text-center text-sm text-slate-600">
            Don't have an account?{' '}
            <Link to="/register" className="font-medium text-cyan-600 hover:text-cyan-500">
              Register here
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;