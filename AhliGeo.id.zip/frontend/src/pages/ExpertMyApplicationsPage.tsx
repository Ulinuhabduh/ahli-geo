import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { fetchExpertApplications } from '../services/apiService';
import { Proposal, User } from '../../types';
import Button from '../components/Button';
import { ClipboardDocumentListIcon, BriefcaseIcon, CalendarDaysIcon, TagIcon, EyeIcon } from '../components/icons/HeroIcons';
import Spinner from '../components/Spinner';

interface EnrichedProposal extends Proposal {
  projectTitle?: string;
  projectClientName?: string;
}

const ExpertMyApplicationsPage: React.FC = () => {
  const { user } = useAuth() as { user: User | null };
  const [isLoading, setIsLoading] = useState(true);
  const [applications, setApplications] = useState<EnrichedProposal[]>([]);
  const [error, setError] = useState<string | null>(null);


  useEffect(() => {
    if (!user) {
      setIsLoading(false);
      return;
    }
    const loadApplications = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const fetchedApplications = await fetchExpertApplications(user.id);
        setApplications(fetchedApplications);
      } catch (err) {
        console.error("Failed to load applications", err);
        setError("Could not load your applications. Please try again.");
        setApplications([]);
      } finally {
        setIsLoading(false);
      }
    };
    loadApplications();
  }, [user]);

  const getStatusColor = (status: Proposal['status']) => {
    switch (status) {
      case 'Pending': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'Accepted': return 'bg-green-100 text-green-800 border-green-300';
      case 'Rejected': return 'bg-red-100 text-red-800 border-red-300';
      case 'Withdrawn': return 'bg-slate-100 text-slate-800 border-slate-300';
      default: return 'bg-slate-100 text-slate-800 border-slate-300';
    }
  };

  const formatDate = (dateString: string) => new Date(dateString).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-[calc(100vh-200px)]">
        <Spinner size="lg" />
        <p className="ml-4 text-slate-600">Loading your applications...</p>
      </div>
    );
  }

  if (!user && !isLoading) {
    return (
      <div className="text-center py-10">
        <p className="text-xl text-red-500">Access Denied.</p>
        <p className="text-slate-600">Please log in as an expert to view your applications.</p>
        <Link to="/login">
          <Button variant="primary" className="mt-4">Login</Button>
        </Link>
      </div>
    );
  }

  if (error) {
    return <div className="text-center py-10 text-red-500">{error}</div>;
  }


  return (
    <div className="container mx-auto space-y-8">
      <header className="flex flex-col md:flex-row justify-between items-center gap-4 p-6 bg-white shadow rounded-lg border">
        <div>
          <h1 className="text-3xl font-bold text-slate-800 flex items-center">
            <ClipboardDocumentListIcon className="h-8 w-8 mr-3 text-cyan-600" />
            My Applications
          </h1>
          <p className="text-slate-600 mt-1">Track the status of all your project proposals.</p>
        </div>
        <Link to="/projects">
          <Button variant="secondary" leftIcon={<BriefcaseIcon className="h-5 w-5" />}>
            Find More Projects
          </Button>
        </Link>
      </header>

      {applications.length > 0 ? (
        <div className="space-y-6">
          {applications.map((app: EnrichedProposal) => (
            <div key={app.id} className="bg-white p-6 rounded-lg shadow border hover:shadow-md transition-shadow">
              <div className="md:flex justify-between items-start">
                <div>
                  <Link to={`/projects/${app.projectId}`} className="hover:underline">
                    <h2 className="text-xl font-semibold text-cyan-700 mb-1">{app.projectTitle}</h2>
                  </Link>
                  <p className="text-sm text-slate-500 mb-2">Client: {app.projectClientName}</p>
                </div>
                <span className={`text-sm font-semibold px-3 py-1 rounded-full border ${getStatusColor(app.status)}`}>
                  {app.status}
                </span>
              </div>
              <div className="mt-4 border-t pt-4 space-y-2 text-sm text-slate-600">
                <p className="flex items-center">
                  <CalendarDaysIcon className="h-4 w-4 mr-2 text-slate-400" />
                  Submitted: {formatDate(app.submittedDate)}
                </p>
                {app.bidAmount && (
                  <p className="flex items-center">
                    <TagIcon className="h-4 w-4 mr-2 text-slate-400" />
                    Your Bid: {app.currency || 'IDR'} {app.bidAmount.toLocaleString()}
                  </p>
                )}
                {app.estimatedDeliveryTime && (
                  <p className="flex items-center">
                    <CalendarDaysIcon className="h-4 w-4 mr-2 text-slate-400" />
                    Est. Delivery: {app.estimatedDeliveryTime}
                  </p>
                )}
                <div className="mt-3">
                  <Link to={`/projects/${app.projectId}`}>
                    <Button variant="outline" size="sm" leftIcon={<EyeIcon className="h-4 w-4" />}>
                      View Project
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 bg-white rounded-lg shadow border">
          <ClipboardDocumentListIcon className="h-16 w-16 text-slate-300 mx-auto mb-4" />
          <p className="text-xl text-slate-600">You haven't submitted any applications yet.</p>
          <p className="text-sm text-slate-500 mt-1">Start by finding projects that match your expertise!</p>
          <Link to="/projects">
            <Button variant="primary" size="lg" className="mt-6" leftIcon={<BriefcaseIcon className="h-5 w-5" />}>
              Find Projects Now
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
};

export default ExpertMyApplicationsPage;
