// frontend/src/pages/ContactPage.tsx

import React, { useState } from 'react';
import Button from '../components/Button';
import { EnvelopeIcon, MapPinIcon, PhoneIcon } from '../components/icons/HeroIcons'; // Sesuaikan ikon

const APP_NAME = "AhliGeo";

const ContactPage: React.FC = () => {
    const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [submitStatus, setSubmitStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        setSubmitStatus(null);
        // Simulasi pengiriman form
        console.log("Contact form data:", formData);
        await new Promise(resolve => setTimeout(resolve, 1500)); // Delay untuk simulasi
        // Anda perlu mengganti ini dengan logika pengiriman email atau API ke backend
        setSubmitStatus({ type: 'success', message: 'Your message has been sent successfully! We will get back to you soon.' });
        setFormData({ name: '', email: '', subject: '', message: '' }); // Reset form
        setIsSubmitting(false);
    };

    return (
        <div className="py-12 md:py-20 bg-slate-50">
            <div className="container mx-auto px-4 max-w-4xl">
                <header className="text-center mb-16">
                    <EnvelopeIcon className="h-16 w-16 text-cyan-500 mx-auto mb-6" />
                    <h1 className="text-4xl md:text-5xl font-extrabold text-slate-800 mb-4">
                        Contact Us
                    </h1>
                    <p className="text-lg text-slate-600">
                        We'd love to hear from you! Whether you have a question, feedback, or a partnership inquiry, please get in touch.
                    </p>
                </header>

                <div className="grid md:grid-cols-2 gap-12">
                    {/* Informasi Kontak */}
                    <div className="bg-white p-8 rounded-xl shadow-lg space-y-6">
                        <h2 className="text-2xl font-semibold text-slate-800 mb-4">Get in Touch</h2>
                        <div className="flex items-start">
                            <MapPinIcon className="h-6 w-6 text-cyan-600 mr-3 mt-1 flex-shrink-0" />
                            <div>
                                <h3 className="font-semibold text-slate-700">Our Office</h3>
                                <p className="text-slate-600">123 Geoscience Avenue, Jakarta, Indonesia</p> {/* Ganti dengan alamat asli */}
                            </div>
                        </div>
                        <div className="flex items-start">
                            <EnvelopeIcon className="h-6 w-6 text-cyan-600 mr-3 mt-1 flex-shrink-0" />
                            <div>
                                <h3 className="font-semibold text-slate-700">Email Us</h3>
                                <a href="mailto:info@ahligeo.com" className="text-cyan-600 hover:underline">info@ahligeo.com</a> {/* Ganti dengan email asli */}
                            </div>
                        </div>
                        <div className="flex items-start">
                            <PhoneIcon className="h-6 w-6 text-cyan-600 mr-3 mt-1 flex-shrink-0" />
                            <div>
                                <h3 className="font-semibold text-slate-700">Call Us</h3>
                                <p className="text-slate-600">+62 21 1234 5678</p> {/* Ganti dengan nomor telepon asli */}
                            </div>
                        </div>
                    </div>

                    {/* Form Kontak */}
                    <div className="bg-white p-8 rounded-xl shadow-lg">
                        <h2 className="text-2xl font-semibold text-slate-800 mb-6">Send Us a Message</h2>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div>
                                <label htmlFor="name" className="block text-sm font-medium text-slate-700">Full Name</label>
                                <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-cyan-500 focus:border-cyan-500" />
                            </div>
                            <div>
                                <label htmlFor="email" className="block text-sm font-medium text-slate-700">Email Address</label>
                                <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-cyan-500 focus:border-cyan-500" />
                            </div>
                            <div>
                                <label htmlFor="subject" className="block text-sm font-medium text-slate-700">Subject</label>
                                <input type="text" name="subject" id="subject" value={formData.subject} onChange={handleChange} required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-cyan-500 focus:border-cyan-500" />
                            </div>
                            <div>
                                <label htmlFor="message" className="block text-sm font-medium text-slate-700">Message</label>
                                <textarea name="message" id="message" rows={4} value={formData.message} onChange={handleChange} required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-cyan-500 focus:border-cyan-500"></textarea>
                            </div>
                            {submitStatus && (
                                <p className={`text-sm p-3 rounded-md ${submitStatus.type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                    {submitStatus.message}
                                </p>
                            )}
                            <div>
                                <Button type="submit" variant="primary" className="w-full" disabled={isSubmitting}>
                                    {isSubmitting ? 'Sending...' : 'Send Message'}
                                </Button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ContactPage;