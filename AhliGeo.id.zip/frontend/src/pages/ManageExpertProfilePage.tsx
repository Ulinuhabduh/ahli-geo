// frontend/src/pages/ManageExpertProfilePage.tsx

import React, { useState, useEffect, useRef } from 'react'; // 1. Impor useRef
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Expert, Skill as SkillType, User } from '../../types';
// 2. Impor uploadProfileImage
import { 
    fetchExpertById, 
    updateUserProfile, 
    fetchAllSkills, 
    fetchAllSoftware,
    uploadProfileImage 
} from '../services/apiService';
import Button from '../components/Button';
import Spinner from '../components/Spinner';
import NotificationModal from '../components/NotificationModal';
// 3. Impor CameraIcon
import { UserCircleIcon, ArrowPathIcon, CameraIcon } from '../components/icons/HeroIcons';
import { MultiSelectCombobox } from '../components/MultiSelectCombobox';
import toast from 'react-hot-toast';

const ManageExpertProfilePage: React.FC = () => {
    const { user, updateUserAuthContext } = useAuth();
    const navigate = useNavigate();

    const [profileData, setProfileData] = useState<Partial<Expert>>({
        name: '', email: '', headline: '', bio: '', location: '',
        experienceYears: 0, hourlyRate: 0, profileImageUrl: '',
        skills: [], software: []
    });
    
    // --- PERUBAHAN 1: Tambahkan state dan ref untuk upload gambar ---
    const [profileImageFile, setProfileImageFile] = useState<File | null>(null);
    const [imagePreviewUrl, setImagePreviewUrl] = useState<string>('');
    const fileInputRef = useRef<HTMLInputElement>(null);
    // ---

    const [allSkills, setAllSkills] = useState<SkillType[]>([]);
    const [allSoftware, setAllSoftware] = useState<SkillType[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [notificationModal, setNotificationModal] = useState<{
        isOpen: boolean; variant: 'success' | 'error'; title: string; message: string;
    } | null>(null);

    useEffect(() => {
        // ... logika useEffect yang sudah ada tidak perlu diubah ...
        if (!user || user.role !== 'expert') {
            navigate('/');
            return;
        }
        const loadInitialData = async () => {
            setIsLoading(true);
            try {
                const [expertData, skillsData, softwareData] = await Promise.all([
                    fetchExpertById(user.id),
                    fetchAllSkills(),
                    fetchAllSoftware()
                ]);

                if (expertData) {
                    setProfileData({
                        name: expertData.name, email: expertData.email, headline: expertData.headline || '',
                        bio: expertData.bio || '', location: expertData.location || '',
                        experienceYears: expertData.experienceYears || 0, hourlyRate: expertData.hourlyRate || 0,
                        profileImageUrl: expertData.profileImageUrl || '', skills: expertData.skills || [],
                        software: expertData.software || [],
                    });
                } else { toast.error("Failed to load your profile data."); }
                setAllSkills(skillsData || []);
                setAllSoftware(softwareData || []);
            } catch (err: any) { toast.error(err.message || 'An error occurred while loading data.'); } 
            finally { setIsLoading(false); }
        };
        loadInitialData();
    }, [user, navigate]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        const val = type === 'number' ? parseFloat(value) || 0 : value;
        setProfileData(prev => ({ ...prev, [name]: val }));
    };
    
    // --- PERUBAHAN 2: Tambahkan handler untuk perubahan gambar ---
    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            if (file.size > 2 * 1024 * 1024) { // 2MB limit
                toast.error("File is too large. Maximum size is 2MB.");
                return;
            }
            setProfileImageFile(file);
            setImagePreviewUrl(URL.createObjectURL(file));
        }
    };
    // ---
    
    const handleSelectionChange = (selectedItems: SkillType[], itemType: 'skills' | 'software') => {
        setProfileData(prev => ({ ...prev, [itemType]: selectedItems, }));
    };

    // --- PERUBAHAN 3: Update handleSubmit dengan logika upload ---
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!user) return;
        setIsSubmitting(true);
        setNotificationModal(null);

        try {
            // Mulai dengan URL gambar yang ada
            let finalImageUrl = profileData.profileImageUrl || '';

            // Jika ada file gambar baru yang dipilih, unggah terlebih dahulu
            if (profileImageFile) {
                const formData = new FormData();
                formData.append('profileImage', profileImageFile);
                const uploadResponse = await uploadProfileImage(formData);
                finalImageUrl = uploadResponse.imageUrl; // Gunakan URL baru dari server
            }

            const payload = {
                name: profileData.name, headline: profileData.headline, bio: profileData.bio,
                location: profileData.location, experienceYears: profileData.experienceYears,
                hourlyRate: profileData.hourlyRate,
                profileImageUrl: finalImageUrl, // Kirim URL final ke payload
                skillIds: profileData.skills?.map(s => s.id) || [],
                softwareIds: profileData.software?.map(s => s.id) || [],
            };

            const updatedUserData: User = await updateUserProfile(user.id, payload);
            updateUserAuthContext(updatedUserData);
            
            setNotificationModal({ isOpen: true, variant: 'success', title: 'Profile Updated!', message: 'Your profile has been successfully updated.' });
        } catch (err: any) {
            setNotificationModal({ isOpen: true, variant: 'error', title: 'Update Failed', message: err.message || 'An error occurred while updating your profile.' });
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleModalClose = () => {
        const modalVariant = notificationModal?.variant;
        setNotificationModal(null);
        if (modalVariant === 'success') { navigate('/dashboard/expert'); }
    };

    if (isLoading) return <div className="flex justify-center items-center h-screen"><Spinner size="lg" /></div>;

    return (
        <div className="bg-slate-50 min-h-screen">
            <div className="container mx-auto py-12 px-4 max-w-4xl">
                <header className="text-center mb-10">
                    <UserCircleIcon className="h-16 w-16 text-cyan-500 mx-auto mb-4" />
                    <h1 className="text-4xl font-extrabold text-slate-800">Manage Your Profile</h1>
                    <p className="text-slate-600 mt-2">Keep your information up-to-date to attract the best projects.</p>
                </header>

                <form onSubmit={handleSubmit} className="bg-white p-8 rounded-xl shadow-xl border border-slate-200 space-y-8">
                    {/* ... Bagian Basic Information dan Expert Details lainnya ... */}
                     <section>
                        <h2 className="text-xl font-semibold text-slate-700 mb-4 border-b pb-2">Expert Details</h2>
                        
                        {/* --- PERUBAHAN 4: Ganti input URL dengan komponen upload --- */}
                        <div className="flex items-center space-x-6">
                            <div className="shrink-0">
                                <img
                                    className="h-24 w-24 object-cover rounded-full"
                                    src={imagePreviewUrl || profileData.profileImageUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(profileData.name || 'A G')}&background=random&size=200`}
                                    alt="Profile preview"
                                />
                            </div>
                            <label className="block">
                                <span className="sr-only">Choose profile photo</span>
                                <input type="file" ref={fileInputRef} onChange={handleImageChange} accept="image/png, image/jpeg, image/jpg" className="hidden"/>
                                <button 
                                    type="button" 
                                    onClick={() => fileInputRef.current?.click()}
                                    className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-md shadow-sm hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500"
                                >
                                    <CameraIcon className="h-5 w-5 inline-block mr-2" />
                                    Change Photo
                                </button>
                                <p className="text-xs text-slate-500 mt-1">PNG, JPG up to 2MB.</p>
                            </label>
                        </div>
                        {/* --- */}

                        <div className="mt-6">
                            <label htmlFor="headline" className="block text-sm font-medium text-slate-700">Headline</label>
                            <input type="text" name="headline" id="headline" value={profileData.headline || ''} onChange={handleChange} placeholder="e.g., Senior Exploration Geologist" required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-cyan-500 focus:border-cyan-500" />
                        </div>
                        <div className="mt-4">
                            <label htmlFor="bio" className="block text-sm font-medium text-slate-700">About Me (Bio)</label>
                            <textarea name="bio" id="bio" rows={5} value={profileData.bio || ''} onChange={handleChange} placeholder="Tell clients about your expertise, experience, and what makes you stand out." required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-cyan-500 focus:border-cyan-500" />
                        </div>
                        <div className="mt-4">
                            <label htmlFor="location" className="block text-sm font-medium text-slate-700">Location</label>
                            <input type="text" name="location" id="location" value={profileData.location || ''} onChange={handleChange} placeholder="e.g., Jakarta, Indonesia" required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-cyan-500 focus:border-cyan-500" />
                        </div>
                        <div className="grid md:grid-cols-2 gap-6 mt-4">
                            <div>
                                <label htmlFor="experienceYears" className="block text-sm font-medium text-slate-700">Years of Experience</label>
                                <input type="number" name="experienceYears" id="experienceYears" value={profileData.experienceYears || 0} onChange={handleChange} min="0" required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-cyan-500 focus:border-cyan-500" />
                            </div>
                            <div>
                                <label htmlFor="hourlyRate" className="block text-sm font-medium text-slate-700">Hourly Rate (IDR, Optional)</label>
                                <input type="number" name="hourlyRate" id="hourlyRate" value={profileData.hourlyRate || 0} onChange={handleChange} min="0" placeholder="e.g., 500000" className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-cyan-500 focus:border-cyan-500" />
                            </div>
                        </div>
                    </section>
                    
                    {/* ... Sisa form (Skills & Software, Tombol Submit) tidak berubah ... */}
                    <section>
                        <h2 className="text-xl font-semibold text-slate-700 mb-4 border-b pb-2">Skills & Software Proficiency</h2>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-slate-700 mb-1">Your Skills</label>
                                <MultiSelectCombobox
                                    options={allSkills} setOptions={setAllSkills} selected={profileData.skills || []}
                                    onChange={(newSelection) => handleSelectionChange(newSelection, 'skills')}
                                    placeholder="Search or add your skills..." type="skill"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-700 mb-1">Your Software Proficiencies</label>
                                <MultiSelectCombobox
                                    options={allSoftware} setOptions={setAllSoftware} selected={profileData.software || []}
                                    onChange={(newSelection) => handleSelectionChange(newSelection, 'software')}
                                    placeholder="Search or add software..." type="software"
                                />
                            </div>
                        </div>
                    </section>

                    <div className="pt-6 flex justify-end">
                        <Button type="submit" variant="primary" size="lg" isLoading={isSubmitting} disabled={isSubmitting} leftIcon={<ArrowPathIcon className="h-5 w-5" />}>
                            {isSubmitting ? 'Saving...' : 'Save Changes'}
                        </Button>
                    </div>
                </form>

                {notificationModal && (
                    <NotificationModal
                        isOpen={notificationModal.isOpen} onClose={handleModalClose} onAction={handleModalClose}
                        variant={notificationModal.variant} title={notificationModal.title} buttonText="OK"
                    >
                        {notificationModal.message}
                    </NotificationModal>
                )}
            </div>
        </div>
    );
};

export default ManageExpertProfilePage;