// src/pages/ExpertProfilePage.tsx

import React, { useEffect, useState, useMemo } from 'react';
import { useParams, Link, useNavigate, useLocation } from 'react-router-dom';
import { fetchExpertById, initiateChat, getReviewsForUser } from '../services/apiService';
import { Expert, Skill, Review as ReviewType } from '../../types';
import Button from '../components/Button';
import Spinner from '../components/Spinner';
import {
  MapPinIcon, BriefcaseIcon, AcademicCapIcon, StarIcon, CheckBadgeIcon,
  EnvelopeIcon, ArrowLeftIcon, ChatBubbleLeftEllipsisIcon, UserPlusIcon, CogIcon,
  ChatBubbleLeftRightIcon
} from '../components/icons/HeroIcons';
import { useAuth } from '../contexts/AuthContext';

// Sub-komponen kecil untuk menampilkan bintang rating
const StarRating: React.FC<{ rating: number; className?: string }> = ({ rating, className = 'h-5 w-5' }) => (
  <div className="flex items-center">
    {[...Array(5)].map((_, index) => (
      <StarIcon
        key={index}
        className={`${className} ${index < Math.round(rating) ? 'text-yellow-400' : 'text-slate-300'}`}
      />
    ))}
  </div>
);

const ExpertProfilePage: React.FC = () => {
  const { expertId } = useParams<{ expertId: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [expert, setExpert] = useState<Expert | null>(null);
  const [reviews, setReviews] = useState<ReviewType[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isChatting, setIsChatting] = useState(false);

  // Menentukan link kembali secara dinamis
  const getBackLinkDetails = () => {
    const fromPath = location.state?.from;
    if (fromPath) {
      const text = fromPath.includes('/proposals') ? 'Back to Proposals' : 'Back to All Experts';
      return { path: fromPath, text: text };
    }
    if (user && user.id === expertId) {
      return { path: '/dashboard/expert', text: 'Back to My Dashboard' };
    }
    return { path: '/experts', text: 'Back to All Experts' };
  };
  const { path: backPath, text: backButtonText } = getBackLinkDetails();

  // useEffect untuk mengambil data saat halaman dimuat
  useEffect(() => {
    if (!expertId) {
      setError("Expert ID is missing.");
      setIsLoading(false);
      return;
    }
    const loadData = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const [foundExpert, reviewsData] = await Promise.all([
          fetchExpertById(expertId),
          getReviewsForUser(expertId)
        ]);

        if (foundExpert) {
          setExpert(foundExpert);
          setReviews(reviewsData || []);
        } else {
          setError('Expert not found.');
        }
      } catch (err: any) {
        setError(err.message || 'Failed to load expert details.');
      } finally {
        setIsLoading(false);
      }
    };
    loadData();
  }, [expertId]);

  // Hitung rating rata-rata menggunakan useMemo agar tidak dihitung ulang setiap render
  const averageRating = useMemo(() => {
    if (reviews.length === 0) return 0;
    const totalRating = reviews.reduce((sum, review) => sum + review.rating, 0);
    return totalRating / reviews.length;
  }, [reviews]);


  const handleInitiateChat = async (recipientId: string) => {
    setIsChatting(true);
    try {
      const { sessionId } = await initiateChat(recipientId);
      navigate(`/chat/${sessionId}`);
    } catch (error) {
      console.error("Failed to initiate chat", error);
      alert("Could not start a chat session. Please try again.");
    } finally {
      setIsChatting(false);
    }
  };

  if (isLoading) {
    return <div className="flex justify-center items-center h-screen"><Spinner size="lg" /></div>;
  }
  if (error || !expert) {
    return (
      <div className="text-center py-20">
        <h1 className="text-3xl font-bold text-slate-700 mb-4">{error || 'Expert Profile Not Found'}</h1>
        <p className="text-slate-500 mb-8">The expert you are looking for does not exist or an error occurred.</p>
        <Link to="/experts"><Button variant="primary" leftIcon={<ArrowLeftIcon className="h-5 w-5" />}>Back to Experts List</Button></Link>
      </div>
    );
  }

  const { id: currentExpertId, name, headline, location: expertLocation, experienceYears, skills = [], software = [], profileImageUrl, bio, verified, hourlyRate } = expert;

  const SkillPill: React.FC<{ skill: Skill }> = ({ skill }) => (
    <span className="bg-cyan-100 text-cyan-800 px-3 py-1 rounded-full text-sm font-medium">{skill.name}</span>
  );
  const SoftwarePill: React.FC<{ softwareItem: Skill }> = ({ softwareItem }) => (
    <span className="bg-indigo-100 text-indigo-800 px-3 py-1 rounded-full text-sm font-medium">{softwareItem.name}</span>
  );

  return (
    <div className="bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="container mx-auto max-w-5xl">
        <div className="mb-6">
          <Link to={backPath} className="inline-flex items-center text-cyan-600 hover:text-cyan-800 transition-colors">
            <ArrowLeftIcon className="h-5 w-5 mr-2" />
            {backButtonText}
          </Link>
        </div>
        <div className="bg-white shadow-xl rounded-lg overflow-hidden">
          <div className="md:flex">
            <aside className="md:flex-shrink-0 p-8 flex flex-col items-center md:items-start md:w-1/3 bg-slate-50 border-r">
              <img className="h-48 w-48 rounded-full object-cover border-4 border-cyan-500 shadow-lg mx-auto md:mx-0" src={profileImageUrl} alt={name} />
              <h1 className="mt-6 text-3xl font-bold text-slate-800 text-center md:text-left">{name}</h1>
              {verified && (<span className="mt-1 inline-flex items-center bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-semibold mx-auto md:mx-0"><CheckBadgeIcon className="h-5 w-5 mr-1.5" /> Verified Expert</span>)}
              <p className="mt-2 text-cyan-600 text-lg font-medium text-center md:text-left">{headline}</p>
              <div className="mt-6 space-y-3 text-sm text-slate-600 text-center md:text-left w-full">
                <p className="flex items-center justify-center md:justify-start"><MapPinIcon className="h-5 w-5 mr-2 text-slate-400" />{expertLocation}</p>
                <p className="flex items-center justify-center md:justify-start"><AcademicCapIcon className="h-5 w-5 mr-2 text-slate-400" />{experienceYears} years of experience</p>
                {hourlyRate && (<p className="flex items-center justify-center md:justify-start"><BriefcaseIcon className="h-5 w-5 mr-2 text-slate-400" />IDR {hourlyRate.toLocaleString()}/hour</p>)}
                <div className="flex items-center justify-center md:justify-start">
                  <StarRating rating={averageRating} />
                  <span className="text-slate-700 font-semibold ml-2">{averageRating.toFixed(2)}</span>
                  <span className="text-slate-500 text-sm ml-1">({reviews.length} reviews)</span>
                </div>
              </div>
              <div className="w-full mt-8 space-y-3">
                {user && user.role === 'client' && user.id !== currentExpertId && (<Link to={`/experts/${currentExpertId}/invite`} className="w-full"><Button variant="primary" className="w-full" leftIcon={<UserPlusIcon className="h-5 w-5" />}>Invite to Project</Button></Link>)}
                {user && user.id !== currentExpertId && (<Button variant="secondary" className="w-full" leftIcon={<ChatBubbleLeftEllipsisIcon className="h-5 w-5" />} onClick={() => handleInitiateChat(currentExpertId)} disabled={isChatting}>{isChatting ? 'Starting...' : `Chat with ${name.split(' ')[0]}`}</Button>)}
                {user && user.id === currentExpertId && (<Link to="/profile/manage" className="w-full">
                  <Button variant="outline" className="w-full" leftIcon={<CogIcon className="h-5 w-5" />}>
                    Manage My Profile
                  </Button>
                </Link>)}
                {!user && (<Link to={`/login`} state={{ from: location }} className="w-full"><Button variant="primary" className="w-full" leftIcon={<EnvelopeIcon className="h-5 w-5" />}>Login to Contact</Button></Link>)}
              </div>
            </aside>
            <main className="p-8 md:w-2/3">
              <section className="mb-8"><h2 className="text-2xl font-semibold text-slate-700 mb-3 border-b pb-2">About Me</h2><p className="text-slate-600 leading-relaxed whitespace-pre-line">{bio || "No biography provided."}</p></section>
              <section className="mb-8"><h2 className="text-2xl font-semibold text-slate-700 mb-4 border-b pb-2">Skills</h2>{skills.length > 0 ? (<div className="flex flex-wrap gap-3">{skills.map(skill => <SkillPill key={skill.id} skill={skill} />)}</div>) : (<p className="text-slate-500">No skills listed.</p>)}</section>
              <section className="mb-8"><h2 className="text-2xl font-semibold text-slate-700 mb-4 border-b pb-2">Software Proficiency</h2>{software.length > 0 ? (<div className="flex flex-wrap gap-3">{software.map(sw => <SoftwarePill key={sw.id} softwareItem={sw} />)}</div>) : (<p className="text-slate-500">No software proficiency listed.</p>)}</section>

              <section className="mt-8">
                <h2 className="text-2xl font-semibold text-slate-700 mb-4 border-b pb-2 flex items-center">
                  <ChatBubbleLeftRightIcon className="h-6 w-6 mr-3 text-slate-400" />
                  Client Reviews ({reviews.length})
                </h2>
                <div className="space-y-6">
                  {reviews.length > 0 ? (
                    reviews.slice(0, 5).map(review => (
                      <div key={review.id} className="bg-slate-50 p-4 rounded-lg border">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-semibold text-slate-800">{review.reviewerName}</p>
                            <p className="text-xs text-slate-500">
                              {new Date(review.createdAt).toLocaleDateString('en-GB', { year: 'numeric', month: 'long' })}
                            </p>
                          </div>
                          <StarRating rating={review.rating} />
                        </div>
                        {review.projectTitle && (
                          <p className="text-sm text-slate-600 mt-2 italic">
                            for project: "{review.projectTitle}"
                          </p>
                        )}
                        {review.comment && (
                          <p className="mt-3 text-slate-700 leading-relaxed bg-white p-3 rounded border border-slate-200">{review.comment}</p>
                        )}
                      </div>
                    ))
                  ) : (
                    <p className="text-slate-500 py-4">This expert has no reviews yet.</p>
                  )}
                  {reviews.length > 5 && (
                    <div className="text-center">
                      <Button variant="link">Show all {reviews.length} reviews</Button>
                    </div>
                  )}
                </div>
              </section>
            </main>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExpertProfilePage;