// frontend/src/pages/ProjectDetailsPage.tsx

// frontend/src/pages/ProjectDetailsPage.tsx

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link, useLocation } from 'react-router-dom';
import { fetchProjectById, checkHasApplied, submitDelivery, completeProject } from '../services/apiService';
import { Project, User, Review as ReviewType } from '../../types';
import { useAuth } from '../contexts/AuthContext';
import Spinner from '../components/Spinner';
import Button from '../components/Button';
import ApplyProposalModal from '../components/ApplyProposalModal';
import NotificationModal from '../components/NotificationModal';
import LeaveReviewModal from '../components/LeaveReviewModal';
import ConfirmationModal from '../components/ConfirmationModal'; // Pastikan ini diimpor
import {
  ArrowLeftIcon, CalendarIcon, MapPinIcon, TagIcon,
  CpuChipIcon, BanknotesIcon, PencilSquareIcon, StarIcon
} from '../components/icons/HeroIcons';

// =========================================================================
// === Sub-komponen: Panel Aksi Dinamis ===
// =========================================================================
const ActionPanel: React.FC<{
  project: Project;
  user: User;
  onAction: () => void;
  onReviewClick: () => void;
  hasUserReviewed: boolean;
}> = ({ project, user, onAction, onReviewClick, hasUserReviewed }) => {
  const [deliveryText, setDeliveryText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [notificationModalState, setNotificationModalState] = useState<{
    isOpen: boolean;
    variant: 'success' | 'error';
    title: string;
    message: string;
  } | null>(null);

  const [isConfirmCompleteModalOpen, setIsConfirmCompleteModalOpen] = useState(false);

  const handleDeliverySubmit = async () => {
    if (!deliveryText.trim()) {
      setNotificationModalState({ isOpen: true, variant: 'error', title: 'Submission Failed', message: 'Please provide a description for your delivery.' });
      return;
    }
    setIsSubmitting(true);
    try {
      if (project.id) {
        await submitDelivery(project.id, { deliveryText });
        setNotificationModalState({ isOpen: true, variant: 'success', title: 'Work Submitted!', message: 'Your work has been submitted to the client for review.' });
      }
    } catch (error: any) {
      setNotificationModalState({ isOpen: true, variant: 'error', title: 'Submission Error', message: error.message || 'An unknown error occurred.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleOpenConfirmCompleteModal = () => {
    setIsConfirmCompleteModalOpen(true);
  };

  const executeProjectComplete = async () => {
    setIsSubmitting(true);
    try {
      if (project.id) {
        await completeProject(project.id);
        setNotificationModalState({ isOpen: true, variant: 'success', title: 'Project Completed!', message: 'This project has been successfully marked as complete.' });
      }
    } catch (error: any) {
      setNotificationModalState({ isOpen: true, variant: 'error', title: 'Completion Error', message: error.message || 'An unknown error occurred.' });
    } finally {
      setIsSubmitting(false);
      setIsConfirmCompleteModalOpen(false);
    }
  };

  const handleNotificationModalClose = () => {
    const wasSuccess = notificationModalState?.variant === 'success';
    setNotificationModalState(null);
    if (wasSuccess) {
      onAction();
    }
  };

  if (user?.role === 'expert' && user.id === project.assignedExpertId && project.status === 'In Progress') {
    return (
      <>
        <div className="mt-8 p-6 bg-cyan-50 border-l-4 border-cyan-500 rounded-r-lg">
          <h3 className="text-xl font-bold text-cyan-800">Submit Your Work</h3>
          <p className="mt-1 text-sm text-cyan-700">The project is in progress. Submit your deliverables here for the client to review.</p>
          <div className="mt-4 space-y-2">
            <label htmlFor="deliveryText" className="block text-sm font-medium text-slate-700">Description & Links</label>
            <textarea id="deliveryText" rows={4} className="w-full p-2 border border-slate-300 rounded-md shadow-sm focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500" placeholder="Describe your work and provide links to files (e.g., Google Drive, Dropbox)..." value={deliveryText} onChange={(e) => setDeliveryText(e.target.value)} />
          </div>
          <Button onClick={handleDeliverySubmit} className="mt-4" disabled={isSubmitting}>
            {isSubmitting ? <Spinner size="sm" /> : 'Submit Deliverables'}
          </Button>
        </div>
        {notificationModalState && (
          <NotificationModal isOpen={notificationModalState.isOpen} onClose={handleNotificationModalClose} variant={notificationModalState.variant} title={notificationModalState.title} buttonText="OK">
            {notificationModalState.message}
          </NotificationModal>
        )}
      </>
    );
  }

  if (user?.role === 'client' && user.id === project.clientId && project.status === 'Delivered') {
    return (
      <>
        <div className="mt-8 p-6 bg-green-50 border-l-4 border-green-500 rounded-r-lg">
          <h3 className="text-xl font-bold text-green-800">Work Submitted for Review</h3>
          <p className="mt-1 text-sm text-green-700">The expert has submitted their work. Please review it and complete the project if you are satisfied.</p>
          <div className="mt-4 p-4 bg-white rounded border">
            <h4 className="font-semibold">Expert's Submission:</h4>
            <p className="mt-2 whitespace-pre-wrap text-slate-800">{project.deliveryText || 'No description provided.'}</p>
          </div>
          <Button onClick={handleOpenConfirmCompleteModal} variant="success" className="mt-4" disabled={isSubmitting}>
            {isSubmitting && isConfirmCompleteModalOpen ? <Spinner size="sm" /> : 'Accept & Complete Project'}
          </Button>
        </div>

        {notificationModalState && (
          <NotificationModal isOpen={notificationModalState.isOpen} onClose={handleNotificationModalClose} variant={notificationModalState.variant} title={notificationModalState.title} buttonText="OK">
            {notificationModalState.message}
          </NotificationModal>
        )}

        <ConfirmationModal
          isOpen={isConfirmCompleteModalOpen}
          onClose={() => setIsConfirmCompleteModalOpen(false)}
          onConfirm={executeProjectComplete}
          title="Confirm Project Completion"
          confirmText="Yes, Mark as Complete"
          cancelText="No, Go Back"
          variant="primary"
        >
          Are you sure you want to mark this project as complete? This will finalize the project and typically triggers payment release and the review process. This action cannot be undone.
        </ConfirmationModal>
      </>
    );
  }

  if (project.status === 'Completed') {
    const isUserInvolved = user.id === project.clientId || user.id === project.assignedExpertId;
    if (isUserInvolved) {
      return (
        <div className="mt-8 p-6 bg-purple-50 border-l-4 border-purple-500 rounded-r-lg text-center">
          <h3 className="text-xl font-bold text-purple-800">Project Completed!</h3>
          <p className="mt-1 text-sm text-purple-700">Thank you for your collaboration on this project.</p>
          <Button variant="outline" className="mt-4" onClick={onReviewClick} disabled={hasUserReviewed} leftIcon={<PencilSquareIcon className="h-5 w-5" />}>
            {hasUserReviewed ? 'You Have Left a Review' : 'Leave a Review'}
          </Button>
        </div>
      )
    }
  }

  return null;
};

// Sub-komponen untuk menampilkan rating
const StarRatingDisplay: React.FC<{ rating?: number | string | null }> = ({ rating }) => {
  if (rating === null || rating === undefined) return null;
  const numericRating = parseFloat(String(rating));
  if (isNaN(numericRating) || numericRating <= 0) return null;
  return (
    <div className="flex items-center gap-1">
      <StarIcon className="h-4 w-4 text-yellow-400" />
      <span className="text-sm font-semibold text-slate-700">{numericRating.toFixed(2)}</span>
    </div>
  );
};

// =========================================================================
// === KOMPONEN UTAMA HALAMAN: ProjectDetailsPage (Lanjutan) ===
// =========================================================================
const ProjectDetailsPage: React.FC = () => {
  const { projectId } = useParams<{ projectId: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const { user, isAuthenticated } = useAuth();

  const [project, setProject] = useState<Project | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [hasApplied, setHasApplied] = useState(false);
  const [hasUserReviewed, setHasUserReviewed] = useState(false);

  // State untuk modal-modal
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false); // Untuk notifikasi sukses submit proposal
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [isThankYouModalOpen, setIsThankYouModalOpen] = useState(false); // Untuk notifikasi sukses submit review

  const backPath = location.state?.from || '/projects';

  const loadData = async () => {
    if (!projectId) {
      navigate('/projects');
      return;
    }
    setError('');
    try {
      const projectData = await fetchProjectById(projectId);
      if (!projectData) {
        setError('Project not found.');
        setProject(null);
      } else {
        setProject(projectData);
        if (isAuthenticated && user) {
          if (user.role === 'expert' && projectData.status === 'Open') {
            const applicationStatus = await checkHasApplied(projectId);
            setHasApplied(applicationStatus);
          }
          if (projectData.status === 'Completed') {
            const reviews: ReviewType[] = projectData.reviews || [];
            const userHasAlreadyReviewed = reviews.some(review => review.reviewerId === user.id);
            setHasUserReviewed(userHasAlreadyReviewed);
          }
        }
      }
    } catch (err: any) {
      setError(err.message || 'Failed to load project details.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    setIsLoading(true);
    loadData();
  }, [projectId, user?.id]); // Dependensi user?.id memastikan re-fetch jika user berubah

  const handleSubmissionSuccess = () => {
    setIsApplyModalOpen(false);
    setIsSuccessModalOpen(true);
    setHasApplied(true);
  };

  const handleSuccessAction = () => {
    setIsSuccessModalOpen(false);
    navigate('/my-applications');
  };

  const handleReviewSuccess = () => {
    setIsReviewModalOpen(false);
    setHasUserReviewed(true);
    setIsThankYouModalOpen(true);
  };

  if (isLoading) return <div className="flex justify-center items-center h-96"><Spinner size="lg" /></div>;
  if (error) return <div className="text-center p-12 text-red-500 bg-red-50 rounded-lg">{error}</div>;
  if (!project) return <div className="text-center p-12 text-slate-500">Project not found.</div>;

  const renderMainButton = () => {
    if (user?.role === 'client' && user.id === project.clientId && project.status === 'Open') {
      return (
        <Link to={`/my-projects/proposals/${project.id}`} state={{ from: location.pathname }}>
          <Button variant="secondary">View Proposals ({project.proposalsCount || 0})</Button>
        </Link>
      )
    }

    if (user?.role === 'expert' && project.status === 'Open') {
      return (
        <Button variant="primary" onClick={() => setIsApplyModalOpen(true)} disabled={hasApplied}>
          {hasApplied ? 'Proposal Submitted' : 'Apply for this Project'}
        </Button>
      );
    }

    if (!isAuthenticated && project.status === 'Open') {
      return (
        <Link to="/login" state={{ from: location }}>
          <Button variant="primary">Login to Apply</Button>
        </Link>
      );
    }
    return null;
  };

  return (
    <>
      <div className="max-w-5xl mx-auto py-8 px-4">
        <Link to={backPath} className="inline-flex items-center text-sm font-medium text-cyan-600 hover:text-cyan-800 mb-6">
          <ArrowLeftIcon className="h-4 w-4 mr-2" />
          Back to Projects
        </Link>

        <div className="bg-white p-8 rounded-xl shadow-lg border border-slate-200">
          <div className="flex flex-col md:flex-row justify-between items-start gap-4">
            <div>
              <span className="text-sm font-semibold text-cyan-600 bg-cyan-100 px-3 py-1 rounded-full">{project.status}</span>
              <h1 className="text-3xl font-bold text-slate-900 mt-2">{project.title}</h1>
              <div className="flex items-center gap-2 mt-2">
                <p className="text-slate-500">Posted by: <span className="font-medium text-slate-700">{project.clientName} {project.companyName && `(${project.companyName})`}</span></p>
                <StarRatingDisplay rating={project.clientAverageRating} />
              </div>
            </div>
            <div className="mt-4 md:mt-0 md:text-right flex-shrink-0">
              {renderMainButton()}
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-8 border-t border-b border-slate-200 py-6">
            <div className="flex items-start space-x-3">
              <BanknotesIcon className="h-6 w-6 text-slate-400 mt-1" />
              <div>
                <h3 className="text-sm font-semibold text-slate-500">Budget</h3>
                <p className="text-slate-900 font-medium">{project.budgetMin && project.budgetMax ? `${project.currency} ${project.budgetMin.toLocaleString()} - ${project.budgetMax.toLocaleString()}` : 'Not specified'}</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <MapPinIcon className="h-6 w-6 text-slate-400 mt-1" />
              <div>
                <h3 className="text-sm font-semibold text-slate-500">Location</h3>
                <p className="text-slate-900 font-medium">{project.locationType}</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <CalendarIcon className="h-6 w-6 text-slate-400 mt-1" />
              <div>
                <h3 className="text-sm font-semibold text-slate-500">Posted Date</h3>
                <p className="text-slate-900 font-medium">{new Date(project.postedDate).toLocaleDateString('en-GB')}</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              {/* Placeholder for another detail or can be removed */}
            </div>
          </div>

          <div className="mt-6">
            <h2 className="text-xl font-semibold text-slate-800">Project Description</h2>
            <p className="mt-3 text-slate-700 whitespace-pre-wrap leading-relaxed">{project.description}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
            <div>
              <h3 className="text-lg font-semibold text-slate-800 flex items-center"><TagIcon className="h-5 w-5 mr-2 text-cyan-500" />Required Skills</h3>
              <div className="flex flex-wrap gap-2 mt-3">
                {project.requiredSkills.map(skill => (
                  <span key={skill.id} className="bg-slate-100 text-slate-700 text-sm font-medium px-3 py-1 rounded-full">{skill.name}</span>
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-800 flex items-center"><CpuChipIcon className="h-5 w-5 mr-2 text-cyan-500" />Required Software</h3>
              <div className="flex flex-wrap gap-2 mt-3">
                {project.requiredSoftware.map(sw => (
                  <span key={sw.id} className="bg-slate-100 text-slate-700 text-sm font-medium px-3 py-1 rounded-full">{sw.name}</span>
                ))}
              </div>
            </div>
          </div>

          {/* Panel Aksi Dinamis */}
          {user && project && (
            <ActionPanel
              project={project}
              user={user}
              onAction={loadData}
              onReviewClick={() => setIsReviewModalOpen(true)}
              hasUserReviewed={hasUserReviewed}
            />
          )}
        </div>
      </div>

      {/* Modal untuk mengajukan proposal */}
      {isApplyModalOpen && project && (
        <ApplyProposalModal
          project={project}
          onClose={() => setIsApplyModalOpen(false)}
          onSubmissionSuccess={handleSubmissionSuccess}
        />
      )}

      {/* Modal notifikasi setelah submit proposal */}
      <NotificationModal
        isOpen={isSuccessModalOpen}
        onClose={handleSuccessAction}
        onAction={handleSuccessAction}
        variant="success"
        title="Proposal Submitted!"
        buttonText="View My Applications"
      >
        Your proposal has been sent to the client successfully. You will be notified if the client accepts your proposal.
      </NotificationModal>

      {/* Modal untuk memberikan ulasan */}
      {isReviewModalOpen && project && (
        <LeaveReviewModal
          projectId={project.id}
          onClose={() => setIsReviewModalOpen(false)}
          onSuccess={handleReviewSuccess}
        />
      )}

      {/* Modal notifikasi "Thank You" setelah submit ulasan */}
      <NotificationModal
        isOpen={isThankYouModalOpen}
        onClose={() => setIsThankYouModalOpen(false)}
        variant="success"
        title="Review Submitted"
        buttonText="Close"
      >
        Thank you for your feedback! Your review has been successfully recorded.
      </NotificationModal>
    </>
  );
};

export default ProjectDetailsPage;