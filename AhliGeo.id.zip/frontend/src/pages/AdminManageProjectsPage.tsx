// frontend/src/pages/AdminManageProjectsPage.tsx

import React, { useState, useEffect, useCallback } from 'react';
import { Project, ProjectStatus } from '../../types';
import { adminGetAllProjects, adminUpdateProjectStatus, adminReassignExpert } from '../services/apiService';
import Spinner from '../components/Spinner';
import toast from 'react-hot-toast';
import { EyeIcon, StopCircleIcon, UserGroupIcon } from '../components/icons/HeroIcons';
import AdminReassignExpertModal from '../components/AdminReassignExpertModal';

const useDebounce = (value: string, delay: number) => {
    const [debouncedValue, setDebouncedValue] = useState(value);

    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedValue(value);
        }, delay);

        return () => {
            clearTimeout(handler);
        };
    }, [value, delay]);

    return debouncedValue;
};

const AdminManageProjectsPage: React.FC = () => {
    const [projects, setProjects] = useState<Project[]>([]);
    const [loading, setLoading] = useState<boolean>(true);

    // State untuk filter
    const [statusFilter, setStatusFilter] = useState<string>('');
    const [searchTerm, setSearchTerm] = useState<string>('');
    const debouncedSearchTerm = useDebounce(searchTerm, 500);

    // State untuk modal re-assign
    const [isReassignModalOpen, setIsReassignModalOpen] = useState(false);
    const [projectToReassign, setProjectToReassign] = useState<Project | null>(null);

    const fetchProjects = useCallback(async () => {
        setLoading(true);
        try {
            const data = await adminGetAllProjects({
                status: statusFilter,
                searchTerm: debouncedSearchTerm,
            });
            setProjects(data);
        } catch (err: any) {
            console.error(err);
            toast.error(err.message || 'Failed to fetch projects.');
        } finally {
            setLoading(false);
        }
    }, [statusFilter, debouncedSearchTerm]);

    useEffect(() => {
        fetchProjects();
    }, [fetchProjects]);

    const handleStatusChange = async (projectId: string, newStatus: string) => {
        const originalProjects = [...projects];
        setProjects(prev => prev.map(p => p.id === projectId ? { ...p, status: newStatus as ProjectStatus } : p));
        const promise = adminUpdateProjectStatus(projectId, newStatus);

        toast.promise(promise, {
            loading: 'Updating status...',
            success: 'Status updated successfully!',
            error: (err) => {
                setProjects(originalProjects);
                return `Error: ${err.message || 'Failed to update status.'}`;
            }
        });
    };

    const handleViewDetails = (projectId: string) => {
        window.open(`/#/projects/${projectId}`, '_blank');
    };

    const handleSuspendProject = (projectId: string) => {
        toast('Suspend feature coming soon!', { icon: '🚧' });
    };

    // Fungsi untuk modal re-assign
    const openReassignModal = (project: Project) => {
        setProjectToReassign(project);
        setIsReassignModalOpen(true);
    };

    const closeReassignModal = () => {
        setProjectToReassign(null);
        setIsReassignModalOpen(false);
    };

    const handleReassignConfirm = async (newExpertId: string) => {
        if (!projectToReassign) return;
        const promise = adminReassignExpert(projectToReassign.id, newExpertId);

        toast.promise(promise, {
            loading: 'Re-assigning expert...',
            success: (response) => {
                setProjects(prev => prev.map(p => p.id === projectToReassign.id ? response.project : p));
                closeReassignModal();
                return response.message;
            },
            error: (err) => `Error: ${err.message || 'Failed to re-assign expert.'}`
        });
    };

    const projectStatuses = Object.values(ProjectStatus);

    return (
        <>
            <div className="container mx-auto px-4 py-8">
                <h1 className="text-3xl font-bold text-slate-800 mb-6">Manage Projects</h1>

                {/* Filter UI */}
                <div className="mb-6 grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-white rounded-lg shadow">
                    <div>
                        <label htmlFor="search" className="block text-sm font-medium text-slate-700 mb-1">
                            Search (Title, Client, Expert)
                        </label>
                        <input
                            type="text"
                            id="search"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            placeholder="e.g., Gold Exploration, Client Name..."
                            className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500"
                        />
                    </div>
                    <div>
                        <label htmlFor="status" className="block text-sm font-medium text-slate-700 mb-1">
                            Filter by Status
                        </label>
                        <select
                            id="status"
                            value={statusFilter}
                            onChange={(e) => setStatusFilter(e.target.value)}
                            className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500"
                        >
                            <option value="">All Statuses</option>
                            {projectStatuses.map(status => (
                                <option key={status} value={status}>{status}</option>
                            ))}
                        </select>
                    </div>
                </div>

                <div className="bg-white shadow-md rounded-lg overflow-x-auto">
                    {loading ? (
                        <div className="flex justify-center items-center h-64"><Spinner /></div>
                    ) : (
                        <table className="min-w-full divide-y divide-slate-200">
                            <thead className="bg-slate-50">
                                <tr>
                                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Project Title</th>
                                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Client / Expert</th>
                                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Posted Date</th>
                                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-slate-200">
                                {projects.length > 0 ? projects.map((project) => (
                                    <tr key={project.id} className="hover:bg-slate-50">
                                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">{project.title}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">
                                            <div className="font-semibold">C: {project.clientName}</div>
                                            <div>E: {project.expertName || 'N/A'}</div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <select
                                                value={project.status}
                                                onChange={(e) => handleStatusChange(project.id, e.target.value)}
                                                className="w-full px-2 py-1 border border-slate-300 rounded-md text-xs focus:outline-none focus:ring-cyan-500 focus:border-cyan-500"
                                                onClick={(e) => e.stopPropagation()}
                                            >
                                                {projectStatuses.map(status => (
                                                    <option key={status} value={status}>{status}</option>
                                                ))}
                                            </select>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                                            {new Date(project.postedDate).toLocaleDateString()}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium flex items-center space-x-4">
                                            <button onClick={() => handleViewDetails(project.id)} className="text-cyan-600 hover:text-cyan-900" aria-label={`View details for ${project.title}`} title="View Details">
                                                <EyeIcon className="h-5 w-5" />
                                            </button>
                                            <button onClick={() => handleSuspendProject(project.id)} className="text-yellow-600 hover:text-yellow-900" aria-label={`Suspend ${project.title}`} title="Suspend Project">
                                                <StopCircleIcon className="h-5 w-5" />
                                            </button>
                                            <button
                                                onClick={() => openReassignModal(project)}
                                                className="text-blue-600 hover:text-blue-900"
                                                aria-label={`Re-assign expert for ${project.title}`}
                                                title="Re-assign Expert"
                                            >
                                                <UserGroupIcon className="h-5 w-5" />
                                            </button>
                                        </td>
                                    </tr>
                                )) : (
                                    <tr>
                                        <td colSpan={5} className="px-6 py-4 text-center text-slate-500">
                                            No projects found with the current filters.
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    )}
                </div>
            </div>

            <AdminReassignExpertModal
                isOpen={isReassignModalOpen}
                onClose={closeReassignModal}
                onConfirm={handleReassignConfirm}
                project={projectToReassign}
            />
        </>
    );
};

export default AdminManageProjectsPage;