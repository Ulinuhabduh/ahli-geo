// frontend/src/pages/TermsPage.tsx

import React from 'react';
import { Link } from 'react-router-dom'; // Pastikan Link diimpor
import { DocumentTextIcon } from '../components/icons/HeroIcons';

const APP_NAME = "AhliGeo";

const TermsPage: React.FC = () => {
    return (
        <div className="py-12 md:py-20 bg-slate-100"> {/* Warna latar sedikit diubah untuk kontras */}
            <div className="container mx-auto px-4">
                <header className="text-center mb-12 md:mb-16">
                    <div className="inline-block p-4 bg-cyan-100 rounded-full mb-6">
                        <DocumentTextIcon className="h-12 w-12 md:h-16 md:w-16 text-cyan-600" />
                    </div>
                    <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900">
                        Terms of Service
                    </h1>
                    <p className="text-slate-600 mt-3 text-lg">
                        Last Updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })} {/* Ganti dengan tanggal update Anda */}
                    </p>
                </header>

                {/* Kontainer utama untuk konten dengan padding dan bayangan */}
                <div className="max-w-5xl mx-auto bg-white p-8 md:p-12 rounded-xl shadow-2xl border border-slate-200">

                    <article
                        className="
              prose prose-slate 
              lg:prose-lg 
              max-w-none 
              prose-headings:font-semibold prose-headings:text-slate-900 prose-headings:mb-3 prose-headings:mt-8
              prose-p:text-slate-700 prose-p:leading-relaxed prose-p:mb-5
              prose-ul:list-disc prose-ul:pl-5 prose-ul:space-y-2 prose-ul:text-slate-700
              prose-ol:list-decimal prose-ol:pl-5 prose-ol:space-y-2 prose-ol:text-slate-700
              prose-a:text-cyan-600 prose-a:font-medium hover:prose-a:text-cyan-700 hover:prose-a:underline
              prose-strong:font-semibold prose-strong:text-slate-800
            "
                    >

                        <h2><strong>1. Acceptance of Terms</strong></h2>
                        <p>
                            Welcome to {APP_NAME}! By accessing or using our platform (the "Service"), you agree to be bound by these Terms of Service ("Terms") and our Privacy Policy. If you do not agree with any part of these terms, you must not use our Service. We may update these Terms from time to time, and your continued use of the Service constitutes acceptance of those changes.
                        </p>

                        <h2><strong>2. Description of Service</strong></h2>
                        <p>
                            {APP_NAME} provides an online marketplace that connects clients seeking specialized geoscience services with independent geoscience professionals (Experts). Our Service facilitates project posting, proposal submission, communication between users, milestone management, and secure payment processing through an escrow system.
                        </p>

                        <h2><strong>3. User Accounts and Responsibilities</strong></h2>
                        <p>
                            To access most features of the Service, you must register for an account. You agree to provide accurate, current, and complete information during the registration process and to update such information to keep it accurate, current, and complete. You are responsible for safeguarding your password and for any activities or actions under your account. {APP_NAME} cannot and will not be liable for any loss or damage arising from your failure to comply with this security obligation.
                        </p>
                        <p>
                            Users are expected to conduct themselves in a professional and ethical manner. Any misuse of the platform, including but not limited to spamming, harassment, fraudulent activities, or infringement of intellectual property rights, may result in account suspension or termination.
                        </p>

                        <h2><strong>4.Project Postings, Proposals, and Agreements</strong></h2>
                        <p>
                            <strong>For Clients:</strong> You are responsible for clearly and accurately describing your project needs, budget, and timelines. By hiring an Expert, you agree to the terms outlined in their proposal and the platform's payment policies.
                        </p>
                        <p>
                            <strong>For Experts:</strong> You are responsible for the accuracy and professionalism of your profile and proposals. When submitting a proposal, you are committing to delivering the services described if hired.
                        </p>
                        <p>
                            Agreements for projects are solely between the Client and the Expert. {APP_NAME} is not a party to these agreements but provides the platform to facilitate them.
                        </p>

                        <h2><strong>5.Fees, Payments, and Refund</strong></h2>
                        <p>
                            {APP_NAME} charges a service fee (commission) on projects successfully completed through the platform. This fee will be clearly communicated before you finalize an agreement. All payments for projects are processed through our designated third-party payment gateway and are held in escrow. Funds are released to the Expert upon mutual confirmation of project completion.
                        </p>
                        <p>
                            Refund policies are subject to the terms of the specific project agreement and {APP_NAME}'s dispute resolution process. Generally, all sales are final once work has commenced and milestones are approved.
                        </p>

                        <h2><strong>Contact Information</strong></h2>
                        <p>
                            If you have any questions about these Terms of Service, please contact us at <Link to="/contact" className="text-blue-600 hover:text-blue-700 font-medium hover:underline" >our contact page</Link> or email us directly at <a className="text-blue-600 hover:text-blue-700 hover:underline" href="mailto:ahligeoid@outlook.com">ahligeoid@outlook.com</a>.
                        </p>
                    </article>
                </div>
            </div>
        </div >
    );
};

export default TermsPage;