// src/pages/ClientMyProjectsPage.tsx

import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { fetchProjects } from '../services/apiService';
import { Project, ProjectStatus } from '../../types';
import Spinner from '../components/Spinner';
import Button from '../components/Button';
import { ListBulletIcon, DocumentPlusIcon, MagnifyingGlassIcon, UserGroupIcon, CalendarDaysIcon } from '../components/icons/HeroIcons';

// Komponen kecil untuk menampilkan status dengan warna
const StatusBadge: React.FC<{ status: ProjectStatus }> = ({ status }) => {
  const statusStyles: { [key in ProjectStatus]: string } = {
    [ProjectStatus.OPEN]: 'bg-green-100 text-green-800 ring-1 ring-inset ring-green-600/20',
    [ProjectStatus.IN_PROGRESS]: 'bg-blue-100 text-blue-800 ring-1 ring-inset ring-blue-600/20',
    [ProjectStatus.COMPLETED]: 'bg-purple-100 text-purple-800 ring-1 ring-inset ring-purple-600/20',
    [ProjectStatus.CLOSED]: 'bg-gray-100 text-gray-800 ring-1 ring-inset ring-gray-500/20',
    [ProjectStatus.AWAITING_PAYMENT]: 'bg-yellow-100 text-yellow-800 ring-1 ring-inset ring-yellow-600/20',
  };
  return (
    <span className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-md ${statusStyles[status] || 'bg-gray-100 text-gray-800'}`}>
      {status}
    </span>
  );
};

// Komponen Kartu Proyek yang menerima 'currentPath' sebagai prop
const ClientProjectCard: React.FC<{ project: Project; currentPath: string }> = ({ project, currentPath }) => (
  <div className="bg-white rounded-lg shadow-md border border-slate-200 flex flex-col h-full overflow-hidden transition-all duration-300 hover:shadow-xl hover:border-cyan-300">
    <div className="p-5 flex-grow">
      <div className="flex justify-between items-start mb-3">
        <h3 className="text-lg font-bold text-slate-800 hover:text-cyan-600 pr-2">
          <Link to={`/projects/${project.id}`}>{project.title}</Link>
        </h3>
        <div className="flex-shrink-0">
          <StatusBadge status={project.status} />
        </div>
      </div>
      <p className="text-sm text-slate-500 mb-5 line-clamp-2 min-h-[40px]">{project.description}</p>
      <div className="space-y-3 text-sm border-t border-slate-100 pt-4">
        <div className="flex items-center text-slate-600">
          <UserGroupIcon className="h-5 w-5 mr-2 text-slate-400" />
          <span className="font-semibold">{project.proposalsCount || 0}</span> Proposals Received
        </div>
        <div className="flex items-center text-slate-600">
          <CalendarDaysIcon className="h-5 w-5 mr-2 text-slate-400" />
          Posted on {new Date(project.postedDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}
        </div>
      </div>
    </div>
    <div className="bg-slate-50/75 px-5 py-3 border-t border-slate-200 grid grid-cols-2 gap-3">
      <Link
        to={`/my-projects/proposals/${project.id}`}
        state={{ from: currentPath }} // Gunakan prop 'currentPath'
      >
        <Button variant="primary" className="w-full text-sm">View Proposals</Button>
      </Link>
      <Link
        to={`/my-projects/manage/${project.id}`}
        state={{ from: currentPath }} // Gunakan prop 'currentPath'
      >
        <Button variant="secondary" className="w-full text-sm">Manage Project</Button>
      </Link>
    </div>
  </div>
);


const ClientMyProjectsPage: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation(); // Panggil useLocation di sini, di level halaman

  const [projects, setProjects] = useState<Project[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<ProjectStatus | ''>('');

  useEffect(() => {
    if (!user) {
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    const debounceFetch = setTimeout(() => {
      fetchProjects({
        clientId: user.id,
        searchTerm: searchTerm || undefined,
        status: statusFilter || undefined,
      })
        .then(data => {
          setProjects(data);
        })
        .catch(error => {
          console.error("Failed to fetch client's projects", error);
          setError("Could not load your projects. Please try again.");
          setProjects([]);
        })
        .finally(() => {
          setIsLoading(false);
        });
    }, 300);

    return () => clearTimeout(debounceFetch);
  }, [user, searchTerm, statusFilter]);

  return (
    <div className="container mx-auto py-8 space-y-8">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-200 pb-6">
        <div className="flex items-center space-x-3">
          <ListBulletIcon className="h-8 w-8 text-cyan-600" />
          <div>
            <h1 className="text-3xl font-bold text-slate-800">My Projects</h1>
            <p className="text-slate-500">View and manage all projects you have created.</p>
          </div>
        </div>
        <Link to="/post-project">
          <Button leftIcon={<DocumentPlusIcon className="h-5 w-5" />}>
            Post New Project
          </Button>
        </Link>
      </header>

      {/* Filter Controls */}
      <div className="bg-white p-4 rounded-lg shadow-sm border grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="search" className="sr-only">Search My Projects</label>
          <div className="relative">
            <MagnifyingGlassIcon className="h-5 w-5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              id="search"
              placeholder="Search by title or description..."
              className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-md focus:ring-cyan-500 focus:border-cyan-500"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <div>
          <label htmlFor="status" className="sr-only">Filter by Status</label>
          <select
            id="status"
            className="w-full py-2 px-3 border border-slate-300 rounded-md focus:ring-cyan-500 focus:border-cyan-500"
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value as ProjectStatus | '')}
          >
            <option value="">All Statuses</option>
            {Object.values(ProjectStatus).map(status => (
              <option key={status} value={status}>{status}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Projects Grid */}
      <main>
        {isLoading ? (
          <div className="flex justify-center items-center h-64"><Spinner size="lg" /></div>
        ) : error ? (
          <div className="text-center py-16 text-red-500">{error}</div>
        ) : projects.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map(project => (
              // Lewatkan location.pathname sebagai prop
              <ClientProjectCard
                key={project.id}
                project={project}
                currentPath={location.pathname}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 px-6 bg-white rounded-lg border">
            <h3 className="text-xl font-semibold text-slate-700">No Projects Found</h3>
            <p className="text-slate-500 mt-2">No projects match your current filters, or you haven't posted any yet.</p>
            <Link to="/post-project" className="mt-6 inline-block">
              <Button variant="primary">Post Your First Project</Button>
            </Link>
          </div>
        )}
      </main>
    </div>
  );
};

export default ClientMyProjectsPage;