import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import Button from '../components/Button';
import { useAuth } from '../contexts/AuthContext';
import { Project, Payment, User } from '../../types';
import { fetchProjectById, makePayment as apiMakePayment } from '../services/apiService';
import { ArrowLeftIcon, CreditCardIcon, CurrencyDollarIcon, CheckCircleIcon } from '../components/icons/HeroIcons';
import Spinner from '../components/Spinner';

const SubmitPaymentPage: React.FC = () => {
  const { projectId } = useParams<{ projectId: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [project, setProject] = useState<Project | null>(null);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'Credit Card' | 'Bank Transfer' | 'Platform Wallet'>('Credit Card');

  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isLoadingProject, setIsLoadingProject] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!projectId) {
      setError("Project ID is missing.");
      setIsLoadingProject(false);
      return;
    }
    const loadProject = async () => {
      setIsLoadingProject(true);
      try {
        const foundProject = await fetchProjectById(projectId);
        if (foundProject) {
          if (user && foundProject.clientId === user.id) {
            setProject(foundProject);
            setPaymentAmount(foundProject.budgetMax?.toString() || foundProject.budgetMin?.toString() || '');
          } else {
            setError('You are not authorized to make payments for this project.');
            setProject(null);
          }
        } else {
          setError('Project not found.');
          setProject(null);
        }
      } catch (err) {
        setError('Failed to load project details.');
        console.error(err);
        setProject(null);
      } finally {
        setIsLoadingProject(false);
      }
    };
    loadProject();
  }, [projectId, user]);

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!project || !user) {
      setError('Cannot process payment. Project or user details missing.');
      return;
    }
    const amount = parseFloat(paymentAmount);
    if (isNaN(amount) || amount <= 0) {
      setError('Please enter a valid payment amount.');
      return;
    }

    setIsSubmitting(true);
    setError('');
    setSuccessMessage('');

    try {
      const paymentData = {
        projectId: project.id,
        clientId: user.id,
        amount: amount,
        currency: project.currency || 'IDR',
        paymentMethod: paymentMethod,
      };

      const newPayment = await apiMakePayment(paymentData, project, user as User);

      setSuccessMessage(`Payment of ${newPayment.currency} ${newPayment.amount.toLocaleString()} for project "${project.title}" processed successfully!`);
      setTimeout(() => {
        navigate(`/projects/${project.id}`);
      }, 3000);
    } catch (err: any) {
      setError(err.message || 'Payment processing failed.');
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoadingProject) {
    return <div className="flex justify-center items-center h-screen"><Spinner size="lg" /></div>;
  }

  if (error && !project && !successMessage) {
    return (
      <div className="text-center py-20">
        <h1 className="text-3xl font-bold text-red-600 mb-4">Access Denied or Error</h1>
        <p className="text-slate-500 mb-8">{error}</p>
        <Link to="/projects">
          <Button variant="secondary" leftIcon={<ArrowLeftIcon className="h-5 w-5" />}>Back to Projects</Button>
        </Link>
      </div>
    );
  }

  if (!project && !successMessage) {
    return <div className="text-center py-20 text-slate-600">Could not load project details for payment.</div>;
  }


  return (
    <div className="min-h-full flex flex-col items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-lg w-full space-y-8 bg-white p-10 rounded-xl shadow-2xl">
        <div className="text-center">
          <CurrencyDollarIcon className="mx-auto h-12 w-12 text-green-500" />
          <h2 className="mt-4 text-center text-3xl font-extrabold text-slate-900">
            Submit Payment
          </h2>
          {project && (
            <p className="mt-2 text-center text-sm text-slate-600">
              For project: <span className="font-semibold text-cyan-600">{project.title}</span>
            </p>
          )}
        </div>

        {successMessage ? (
          <div className="bg-green-50 border-l-4 border-green-500 p-6 rounded-md shadow-md text-center">
            <CheckCircleIcon className="h-12 w-12 text-green-500 mx-auto mb-3" />
            <h3 className="text-xl font-semibold text-green-700 mb-2">Payment Successful!</h3>
            <p className="text-green-600 mb-4">{successMessage}</p>
            {project &&
              <Link to={`/projects/${project.id}`}>
                <Button variant="outline" size="sm">View Project Details</Button>
              </Link>
            }
          </div>
        ) : project && (
          <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
            {error && (
              <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <span className="block sm:inline">{error}</span>
              </div>
            )}

            <div>
              <label htmlFor="paymentAmount" className="block text-sm font-medium text-slate-700">Payment Amount ({project.currency || 'IDR'})*</label>
              <input id="paymentAmount" name="paymentAmount" type="number" required value={paymentAmount}
                onChange={e => setPaymentAmount(e.target.value)} min="1" step="any"
                className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
                placeholder="e.g., 5000000" />
              {project.budgetMax && <p className="text-xs text-slate-500 mt-1">Project Max Budget: {project.currency} {project.budgetMax.toLocaleString()}</p>}
            </div>

            <div>
              <label htmlFor="paymentMethod" className="block text-sm font-medium text-slate-700">Payment Method*</label>
              <select id="paymentMethod" name="paymentMethod" required value={paymentMethod}
                onChange={e => setPaymentMethod(e.target.value as any)}
                className="mt-1 block w-full px-3 py-2 border border-slate-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm">
                <option value="Credit Card">Credit Card</option>
                <option value="Bank Transfer">Bank Transfer</option>
                <option value="Platform Wallet">Platform Wallet (Mock)</option>
              </select>
            </div>

            <div className="bg-slate-50 p-4 rounded-md border border-slate-200 text-sm text-slate-600">
              <p>You are about to make a payment of <strong className="text-slate-800">{project.currency || 'IDR'} {parseFloat(paymentAmount || "0").toLocaleString()}</strong> for the project "{project.title}".</p>
              <p className="mt-1">Payments are processed securely (this is a simulation).</p>
            </div>


            <div className="mt-8">
              <Button
                type="submit"
                variant="primary"
                className="w-full"
                isLoading={isSubmitting}
                leftIcon={<CreditCardIcon className="h-5 w-5" />}
              >
                Confirm and Pay {project.currency || 'IDR'} {parseFloat(paymentAmount || "0").toLocaleString()}
              </Button>
            </div>
            <div className="text-center mt-4">
              <Link to={`/projects/${project.id}`} className="text-sm font-medium text-cyan-600 hover:text-cyan-500">
                <ArrowLeftIcon className="h-4 w-4 inline mr-1" /> Cancel and return to project
              </Link>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

export default SubmitPaymentPage;