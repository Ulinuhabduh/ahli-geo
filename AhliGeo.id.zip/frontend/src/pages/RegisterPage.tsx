// frontend/src/pages/RegisterPage.tsx

import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
    fetchAllSkills, 
    fetchAllSoftware, 
    registerUser as apiRegisterUser,
    uploadProfileImage
} from '../services/apiService';
import { Skill as SkillType } from '../../types';
import Spinner from '../components/Spinner';
import toast from 'react-hot-toast';
import { MultiSelectCombobox } from '../components/MultiSelectCombobox';
import Button from '../components/Button';
import { UserPlusIcon, CameraIcon } from '../components/icons/HeroIcons';

const APP_NAME = "AhliGeo";

// Komponen helper untuk setiap langkah
const RegistrationStep: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="space-y-6 animate-fade-in">
        <h3 className="text-2xl font-bold text-slate-800">{title}</h3>
        {children}
    </div>
);

const RegisterPage: React.FC = () => {
    const [step, setStep] = useState(1);
    
    // Step 1 State
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [name, setName] = useState('');
    
    // Step 2 State
    const [role, setRole] = useState<'client' | 'expert'>('expert');
    
    // Step 3 State
    const [companyName, setCompanyName] = useState('');
    const [headline, setHeadline] = useState('');
    const [experienceYears, setExperienceYears] = useState('');
    const [bio, setBio] = useState('');
    const [selectedSkills, setSelectedSkills] = useState<SkillType[]>([]);
    const [selectedSoftware, setSelectedSoftware] = useState<SkillType[]>([]);
    const [profileImageFile, setProfileImageFile] = useState<File | null>(null);
    const [imagePreviewUrl, setImagePreviewUrl] = useState<string>('');
    const fileInputRef = useRef<HTMLInputElement>(null);

    // Data Loading
    const [availableSkills, setAvailableSkills] = useState<SkillType[]>([]);
    const [availableSoftware, setAvailableSoftware] = useState<SkillType[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [isOptionsLoading, setIsOptionsLoading] = useState(true);

    const navigate = useNavigate();

    useEffect(() => {
        const loadOptions = async () => {
            setIsOptionsLoading(true);
            try {
                const [skills, software] = await Promise.all([fetchAllSkills(), fetchAllSoftware()]);
                setAvailableSkills(skills || []);
                setAvailableSoftware(software || []);
            } catch (err) {
                toast.error("Could not load registration options. Please refresh.");
            } finally {
                setIsOptionsLoading(false);
            }
        };
        loadOptions();
    }, []);

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            if (file.size > 2 * 1024 * 1024) { // 2MB limit
                toast.error("File is too large. Maximum size is 2MB.");
                return;
            }
            setProfileImageFile(file);
            setImagePreviewUrl(URL.createObjectURL(file));
        }
    };

    const nextStep = () => setStep(prev => prev < 3 ? prev + 1 : 3);
    const prevStep = () => setStep(prev => prev > 1 ? prev - 1 : 1);

    const validateStep1 = () => {
        if (!name.trim() || !email.trim() || !password) {
            toast.error('Please fill in Name, Email, and Password.'); return false;
        }
        if (!/\S+@\S+\.\S+/.test(email)) {
            toast.error('Please enter a valid email address.'); return false;
        }
        if (password !== confirmPassword) {
            toast.error('Passwords do not match.'); return false;
        }
        if (password.length < 6) {
            toast.error('Password must be at least 6 characters.'); return false;
        }
        return true;
    };
    
    const handleNext = () => {
        if (step === 1 && validateStep1()) {
            nextStep();
        } else if (step === 2) {
            nextStep();
        }
    };

    const handleSubmit = async () => {
        if (role === 'expert' && (!headline.trim() || !experienceYears.trim() || !bio.trim())) {
            toast.error('Please fill in all required expert profile fields.');
            return;
        }

        setIsLoading(true);
        
        try {
            let uploadedImageUrl = '';
            if (profileImageFile) {
                const formData = new FormData();
                // PASTIKAN NAMA FIELD INI 'profileImage'
                formData.append('profileImage', profileImageFile); 
                const uploadResponse = await uploadProfileImage(formData);
                uploadedImageUrl = uploadResponse.imageUrl;
            }

            let payload: any = { 
                email, name, role, password,
                profileSetupCompleted: true
            };

            if (role === 'expert') {
                payload = {
                    ...payload,
                    headline,
                    experienceYears: parseInt(experienceYears, 10),
                    bio,
                    profileImageUrl: uploadedImageUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random&size=200`,
                    skillIds: selectedSkills.map(s => s.id),
                    softwareIds: selectedSoftware.map(s => s.id),
                };
            } else {
                payload.companyName = companyName.trim() || undefined;
            }
            
            await apiRegisterUser(payload);
            navigate('/login', {
                replace: true,
                state: { message: 'Registration successful! Please log in to continue.' }
            });
        } catch (err: any) {
            toast.error(err.message || 'Registration failed. An account with this email may already exist.');
        } finally {
            setIsLoading(false);
        }
    };
    
    return (
        <div className="flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
            <div className="w-full max-w-3xl space-y-8">
                <div>
                    <h2 className="text-center text-4xl font-extrabold text-slate-900">
                        Join <span className="text-cyan-600">{APP_NAME}</span>
                    </h2>
                    <p className="mt-2 text-center text-sm text-slate-600">
                        Step {step} of 3: {step === 1 ? 'Account Setup' : step === 2 ? 'Account Type' : 'Profile Details'}
                    </p>
                </div>
                
                <div className="bg-white p-10 rounded-xl shadow-2xl">
                    {step === 1 && (
                        <RegistrationStep title="Create Your Account">
                            <div className="space-y-4">
                                <div><label htmlFor="name-register" className="sr-only">Full Name</label><input id="name-register" type="text" autoComplete="name" required className="w-full px-3 py-3 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-cyan-500" placeholder="Full Name" value={name} onChange={(e) => setName(e.target.value)} /></div>
                                <div><label htmlFor="email-address-register" className="sr-only">Email address</label><input id="email-address-register" type="email" autoComplete="email" required className="w-full px-3 py-3 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-cyan-500" placeholder="Email address" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
                                <div><label htmlFor="password-register" className="sr-only">Password</label><input id="password-register" type="password" autoComplete="new-password" required className="w-full px-3 py-3 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-cyan-500" placeholder="Password (min. 6 characters)" value={password} onChange={(e) => setPassword(e.target.value)} /></div>
                                <div><label htmlFor="confirm-password" className="sr-only">Confirm Password</label><input id="confirm-password" type="password" autoComplete="new-password" required className="w-full px-3 py-3 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-cyan-500" placeholder="Confirm Password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} /></div>
                            </div>
                        </RegistrationStep>
                    )}

                    {step === 2 && (
                        <RegistrationStep title="What brings you here?">
                            <div className="space-y-4">
                                <div onClick={() => setRole('expert')} className={`p-6 border rounded-lg cursor-pointer transition-all ${role === 'expert' ? 'border-cyan-500 bg-cyan-50 shadow-md ring-2 ring-cyan-500' : 'border-slate-300 hover:border-slate-400'}`}>
                                    <h4 className="text-lg font-semibold text-slate-800">Geoscience Expert</h4>
                                    <p className="text-sm text-slate-600">I'm a freelancer looking for geoscience projects.</p>
                                </div>
                                <div onClick={() => setRole('client')} className={`p-6 border rounded-lg cursor-pointer transition-all ${role === 'client' ? 'border-cyan-500 bg-cyan-50 shadow-md ring-2 ring-cyan-500' : 'border-slate-300 hover:border-slate-400'}`}>
                                    <h4 className="text-lg font-semibold text-slate-800">Client / Company</h4>
                                    <p className="text-sm text-slate-600">I'm looking to hire geoscience talent for a project.</p>
                                </div>
                            </div>
                        </RegistrationStep>
                    )}

                    {step === 3 && (
                        <RegistrationStep title="Tell Us About Yourself">
                            {isOptionsLoading ? <Spinner /> : (
                                <>
                                    {role === 'client' && (
                                        <div className="space-y-4">
                                            <label htmlFor="companyName" className="block text-sm font-medium text-slate-700">Company Name (Optional)</label>
                                            <input id="companyName" type="text" value={companyName} onChange={e => setCompanyName(e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-cyan-500" placeholder="Your Company Inc." />
                                        </div>
                                    )}
                                    {role === 'expert' && (
                                        <div className="space-y-6">
                                            <div className="flex items-center space-x-6">
                                                <div className="shrink-0">
                                                    <img
                                                        className="h-20 w-20 object-cover rounded-full"
                                                        src={imagePreviewUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(name || 'A G')}&background=random&size=200`}
                                                        alt="Profile preview"
                                                    />
                                                </div>
                                                <label className="block">
                                                    <span className="sr-only">Choose profile photo</span>
                                                    <input type="file" ref={fileInputRef} onChange={handleImageChange} accept="image/png, image/jpeg, image/jpg" className="hidden"/>
                                                    <button 
                                                        type="button" 
                                                        onClick={() => fileInputRef.current?.click()}
                                                        className="px-3 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-md shadow-sm hover:bg-slate-50"
                                                    >
                                                        <CameraIcon className="h-5 w-5 inline-block mr-2" />
                                                        Upload Photo
                                                    </button>
                                                    <p className="text-xs text-slate-500 mt-1">PNG, JPG, JPEG up to 2MB.</p>
                                                </label>
                                            </div>
                                            <div>
                                                <label htmlFor="headline" className="block text-sm font-medium text-slate-700">Headline*</label>
                                                <input id="headline" type="text" required value={headline} onChange={e => setHeadline(e.target.value)} className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-cyan-500" placeholder="e.g., Senior Geophysicist" />
                                            </div>
                                            <div>
                                                <label htmlFor="experienceYears" className="block text-sm font-medium text-slate-700">Years of Experience*</label>
                                                <input id="experienceYears" type="number" required value={experienceYears} onChange={e => setExperienceYears(e.target.value)} min="0" className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-cyan-500" placeholder="e.g., 10" />
                                            </div>
                                            <div>
                                                <label htmlFor="bio" className="block text-sm font-medium text-slate-700">Bio / About Me*</label>
                                                <textarea id="bio" rows={3} required value={bio} onChange={e => setBio(e.target.value)} className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-cyan-500" placeholder="Tell clients about your expertise..."></textarea>
                                            </div>
                                            <div>
                                                <label className="block text-sm font-medium text-slate-700 mb-1">Skills</label>
                                                <MultiSelectCombobox 
                                                    options={availableSkills}
                                                    setOptions={setAvailableSkills}
                                                    selected={selectedSkills}
                                                    onChange={setSelectedSkills}
                                                    placeholder="Search or create skills..."
                                                    type="skill"
                                                />
                                            </div>
                                            <div>
                                                <label className="block text-sm font-medium text-slate-700 mb-1">Software</label>
                                                <MultiSelectCombobox 
                                                    options={availableSoftware}
                                                    setOptions={setAvailableSoftware}
                                                    selected={selectedSoftware}
                                                    onChange={setSelectedSoftware}
                                                    placeholder="Search or create software..."
                                                    type="software"
                                                />
                                            </div>
                                        </div>
                                    )}
                                </>
                            )}
                        </RegistrationStep>
                    )}
                    
                    <div className="mt-8 flex justify-between items-center">
                        {step > 1 ? (
                            <Button variant="secondary" onClick={prevStep}>
                                Back
                            </Button>
                        ) : <div />}
                        
                        {step < 3 ? (
                            <Button variant="primary" onClick={handleNext}>
                                Next
                            </Button>
                        ) : (
                            <Button variant="primary" onClick={handleSubmit} isLoading={isLoading || isOptionsLoading} disabled={isLoading || isOptionsLoading} leftIcon={<UserPlusIcon className="h-5 w-5" />}>
                                Finish Registration
                            </Button>
                        )}
                    </div>
                </div>
                
                <p className="mt-6 text-center text-sm text-slate-600">
                    Already have an account?{' '}
                    <Link to="/login" className="font-medium text-cyan-600 hover:text-cyan-500">
                        Sign in here
                    </Link>
                </p>
            </div>
        </div>
    );
};

export default RegisterPage;