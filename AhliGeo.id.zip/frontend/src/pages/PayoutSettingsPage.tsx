// frontend/src/pages/PayoutSettingsPage.tsx
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { getPayoutAccount, savePayoutAccount } from '../services/apiService'; // Fungsi API yang akan kita buat
import toast from 'react-hot-toast';
import Spinner from '../components/Spinner';
import Button from '../components/Button';

const PayoutSettingsPage: React.FC = () => {
    const [bankName, setBankName] = useState('');
    const [accountHolderName, setAccountHolderName] = useState('');
    const [accountNumber, setAccountNumber] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const { user } = useAuth();

    useEffect(() => {
        const fetchAccount = async () => {
            try {
                const account = await getPayoutAccount();
                if (account) {
                    setBankName(account.bankName);
                    setAccountHolderName(account.accountHolderName);
                    setAccountNumber(account.accountNumber);
                }
            } catch (error: any) {
                // Tidak apa-apa jika 404 (belum ada), tapi tampilkan error lain
                if (!error.message.includes('404')) {
                    toast.error(error.message || "Failed to load payout settings.");
                }
            } finally {
                setIsLoading(false);
            }
        };
        fetchAccount();
    }, []);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSaving(true);
        try {
            const data = { bankName, accountHolderName, accountNumber };
            await savePayoutAccount(data);
            toast.success("Payout information saved successfully!");
        } catch (error: any) {
            toast.error(error.message || "Failed to save settings.");
        } finally {
            setIsSaving(false);
        }
    };

    if (isLoading) return <Spinner />;

    return (
        <div className="max-w-2xl mx-auto">
            <h1 className="text-3xl font-bold text-slate-800 mb-6">Payout Settings</h1>
            <div className="bg-white p-8 rounded-lg shadow-md">
                <p className="text-sm text-slate-600 mb-6">
                    Please provide your bank account details below. This information will be used to send your earnings.
                </p>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label htmlFor="bankName" className="block text-sm font-medium text-slate-700">Bank Name</label>
                        <input id="bankName" type="text" value={bankName} onChange={e => setBankName(e.target.value)} required className="mt-1 w-full px-3 py-2 border rounded-md" placeholder="e.g., Bank Central Asia (BCA)" />
                    </div>
                    <div>
                        <label htmlFor="accountHolderName" className="block text-sm font-medium text-slate-700">Account Holder Name</label>
                        <input id="accountHolderName" type="text" value={accountHolderName} onChange={e => setAccountHolderName(e.target.value)} required className="mt-1 w-full px-3 py-2 border rounded-md" placeholder="Full name as on bank account" />
                    </div>
                    <div>
                        <label htmlFor="accountNumber" className="block text-sm font-medium text-slate-700">Account Number</label>
                        <input id="accountNumber" type="text" value={accountNumber} onChange={e => setAccountNumber(e.target.value)} required className="mt-1 w-full px-3 py-2 border rounded-md" />
                    </div>
                    <div className="pt-4">
                        <Button type="submit" isLoading={isSaving}>Save Payout Information</Button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default PayoutSettingsPage;