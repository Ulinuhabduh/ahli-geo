// frontend/src/contexts/AuthContext.tsx

import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { User } from '../../types';
import { fetchCurrentUser } from '../services/apiService';
import Spinner from '../components/Spinner';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (userData: User, token: string) => void;
  logout: () => void;
  updateUserAuthContext: (updatedUserData: User | null) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const validateToken = async () => {
      const token = localStorage.getItem('ahliGeoToken');
      if (token) {
        try {
          const currentUser = await fetchCurrentUser();
          setUser(currentUser);
        } catch (error) {
          console.error("Token invalid, logging out.", error);
          localStorage.removeItem('ahliGeoToken');
          setUser(null);
        }
      }
      setIsLoading(false);
    };
    validateToken();
  }, []);

  const login = (userData: User, token: string) => {
    localStorage.setItem('ahliGeoToken', token);
    setUser(userData);
  };

  const logout = () => {
    localStorage.removeItem('ahliGeoToken');
    setUser(null);
  };

  const updateUserAuthContext = (updatedUserData: User | null) => {
    setUser(prevUser => {
      if (prevUser && updatedUserData) {
        return { ...prevUser, ...updatedUserData };
      }
      return updatedUserData;
    });
  };

  const value = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    logout,
    updateUserAuthContext
  };

  // Kondisi loading yang lebih baik: jangan render children jika masih loading awal & belum ada user
  if (isLoading && !user && !localStorage.getItem('ahliGeoToken')) { // Cek juga token untuk kasus reload
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Spinner size="lg" />
      </div>
    );
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}; // <-- Kurung kurawal penutup untuk AuthProvider

// Hook kustom untuk mengonsumsi context
export const useAuth = () => { // <-- 'export' ada di sini, di top-level
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Export AuthContext untuk digunakan di komponen lain jika diperlukan
export default AuthContext;