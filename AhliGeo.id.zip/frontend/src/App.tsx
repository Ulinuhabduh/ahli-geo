// App.tsx

import React from 'react';
import { HashRouter, Routes, Route, Navigate, Outlet, useLocation } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { UserRole } from '../types'; // Pastikan tipe UserRole diimpor jika ada
import ChatPage from './pages/ChatPage';
import PaymentPage from './pages/PaymentPage';
import HowItWorksPage from './pages/HowItWorksPage';
import AboutPage from './pages/AboutPage';         // <-- IMPOR BARU
import ContactPage from './pages/ContactPage';       // <-- IMPOR BARU
import TermsPage from './pages/TermsPage';           // <-- IMPOR BARU
import PrivacyPage from './pages/PrivacyPage';
import ManageExpertProfilePage from './pages/ManageExpertProfilePage'
import AdminManageProjectsPage from './pages/AdminManageProjectsPage';

// Layout Components
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Spinner from './components/Spinner'; // Impor Spinner untuk loading state
import AdminRoute from './components/AdminRoute';


// Page Components
import HomePage from './pages/HomePage';
import ProjectsPage from './pages/ProjectsPage';
import ExpertsPage from './pages/ExpertsPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import ExpertProfilePage from './pages/ExpertProfilePage';
import ProjectDetailsPage from './pages/ProjectDetailsPage';
import ExpertDashboardPage from './pages/ExpertDashboardPage';
import ClientDashboardPage from './pages/ClientDashboardPage';
import MyApplicationsPage from './pages/MyApplicationPage';
import PostProjectPage from './pages/PostProjectPage';
import ClientMyProjectsPage from './pages/ClientMyProjectsPage';
import EditProjectPage from './pages/EditProjectPage';
import ProjectProposalsPage from './pages/ProjectProposalPage';
import InviteExpertPage from './pages/InviteExpertPage';
import AdminDashboardPage from './pages/AdminDashboardPage';
import AdminManageUsersPage from './pages/AdminManageUsersPage';
import PayoutSettingsPage from './pages/PayoutSettingsPage';

// ===================================================================
// SATU ProtectedRoute yang fleksibel untuk menangani semua logika
// ===================================================================
const ProtectedRoute: React.FC<{ allowedRoles?: UserRole[] }> = ({ allowedRoles }) => {
  const { isAuthenticated, user, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spinner size="lg" />
      </div>
    );
  }

  // 1. Jika tidak login, arahkan ke halaman login
  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // 2. Jika ada batasan peran dan peran user tidak cocok
  if (allowedRoles && user && !allowedRoles.includes(user.role)) {
    // Arahkan ke dashboard mereka sendiri untuk mencegah kebingungan
    const ownDashboardPath = user.role === 'client' ? '/my-projects' : '/dashboard/expert';
    return <Navigate to={ownDashboardPath} replace />;
  }

  // 3. Jika semua pemeriksaan lolos, render halaman yang dituju
  return <Outlet />;
};

// ===================================================================
// Komponen Utama App
// ===================================================================
const App: React.FC = () => {
  return (
    <AuthProvider>
      <HashRouter>
        <Toaster
          position="top-right"
          toastOptions={{
            success: {
              style: {
                background: '#F0FDF4', // green-50
                color: '#166534', // green-800
                border: '1px solid #A7F3D0', // green-200
              },
            },
            error: {
              style: {
                background: '#FEF2F2', // red-50
                color: '#991B1B', // red-800
                border: '1px solid #FECACA', // red-200
              },
            },
          }}
        />
        <div className="flex flex-col min-h-screen">
          <Navbar />
          <main className="flex-grow container mx-auto px-4 py-8">
            <Routes>

              {/* === RUTE PUBLIK (Bisa diakses semua orang) === */}
              <Route path="/" element={<HomePage />} />
              <Route path="/projects" element={<ProjectsPage />} />
              <Route path="/projects/:projectId" element={<ProjectDetailsPage />} />
              <Route path="/experts" element={<ExpertsPage />} />
              <Route path="/experts/:expertId" element={<ExpertProfilePage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />
              <Route path="/how-it-works" element={<HowItWorksPage />} />
              <Route path="/about" element={<AboutPage />} />             {/* <-- RUTE BARU */}
              <Route path="/contact" element={<ContactPage />} />           {/* <-- RUTE BARU */}
              <Route path="/terms" element={<TermsPage />} />               {/* <-- RUTE BARU */}
              <Route path="/privacy" element={<PrivacyPage />} />

              <Route element={<ProtectedRoute />}>
                <Route path="/chat" element={<ChatPage />} />
                <Route path="/chat/:sessionId" element={<ChatPage />} />

                {/* --- Rute Khusus CLIENT --- */}
                <Route element={<ProtectedRoute allowedRoles={['client']} />}>
                  <Route path="/my-projects" element={<ClientMyProjectsPage />} />
                  <Route path="/post-project" element={<PostProjectPage />} />
                  <Route path="/my-projects/manage/:projectId" element={<EditProjectPage />} />
                  <Route path="/my-projects/proposals/:projectId" element={<ProjectProposalsPage />} />
                  <Route path="/dashboard/client" element={<ClientDashboardPage />} />
                  <Route path="/experts/:expertId/invite" element={<InviteExpertPage />} />
                  <Route path="/payment/:paymentId" element={<PaymentPage />} />
                </Route>

                {/* --- Rute Khusus EXPERT --- */}
                <Route element={<ProtectedRoute allowedRoles={['expert']} />}>
                  <Route path="/dashboard/expert" element={<ExpertDashboardPage />} />
                  <Route path="/my-applications" element={<MyApplicationsPage />} />
                  <Route path="/profile/manage" element={<ManageExpertProfilePage />} />
                  <Route path="/settings/payout" element={<PayoutSettingsPage />} />
                </Route>
              </Route>

              <Route element={<AdminRoute />}>
                <Route path="/admin/dashboard" element={<AdminDashboardPage />} />
                <Route path="/admin/users" element={<AdminManageUsersPage />} />
                <Route path="/admin/projects" element={<AdminManageProjectsPage />} />
              </Route>

              {/* Rute "Catch-all" untuk halaman tidak ditemukan, arahkan ke home */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </HashRouter>
    </AuthProvider>
  );
};

export default App;