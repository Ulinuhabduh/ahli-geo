export enum ProjectLocation {
  REMOTE = "Remote",
  ON_SITE = "On-Site",
  HYBRID = "Hybrid"
}

export enum ProjectStatus {
  OPEN = 'Open',
  IN_PROGRESS = 'In Progress',
  COMPLETED = 'Completed',
  DELIVERED = 'Delivered',
  CLOSED = 'Closed',
  AWAITING_PAYMENT = 'Awaiting Payment'
}

export interface Skill {
  id: string;
  name: string;
}

export interface Software {
  id: string;
  name: string;
}

export interface Expert {
  id: string;
  name: string;
  headline: string;
  location: string;
  experienceYears: number;
  skills: Skill[];
  software: Skill[];
  rating: number;
  profileImageUrl: string;
  bio: string;
  verified: boolean;
  hourlyRate?: number;
}

export interface Review {
  id: string;
  projectId: string;
  reviewerId: string;
  revieweeId: string;
  rating: number;
  comment: string;
  createdAt: string;
  reviewerName: string; // Didapat dari JOIN di backend
  projectTitle?: string; // Juga dari JOIN, opsional
}

export interface Project {
  id: string;
  title: string;
  clientName: string; // Could be a Client object in a real app. For mock, string.
  clientId: string; // ID of the client user who posted/owns this project
  description: string;
  budgetMin?: number;
  budgetMax?: number;
  currency?: string;
  requiredSkills: Skill[];
  requiredSoftware: Skill[];
  locationType: ProjectLocation;
  specificLocation?: string;
  status: ProjectStatus;
  postedDate: string;
  deadlineDate?: string;
  proposalsCount?: number;
  assignedExpertId?: string; // ID of the expert if it's a direct hire or assigned
  isDirectHire?: boolean; // Flag if created through direct hire flow
  deliveryText?: string;
  deliveryAttachments?: any[];
  deliveredAt?: string;
  clientAverageRating?: number | string | null; // Tipe sudah benar
  clientReviewCount?: number;
  reviews?: Review[];
}

export interface User {
  id: string;
  email: string;
  role: 'client' | 'expert' | 'admin';
  name: string;
  profileSetupCompleted: boolean;
  companyName?: string;
  deletedAt?: string;
}

// Chat related types
export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: string;
  isRead?: boolean;
}

export interface ChatSession {
  id: string;
  targetType: 'expert' | 'project';
  targetId: string;
  targetName: string;
  participantIds: string[];
  messages: ChatMessage[];
  lastMessageTimestamp?: string;
  unreadCount?: number;
}

// Payment related type
export interface Payment {
  id: string;
  projectId: string;
  clientId: string; // User ID of the client making payment
  expertId?: string; // User ID of the expert receiving payment (if applicable)
  amount: number;
  currency: string;
  status: 'Pending' | 'Completed' | 'Failed';
  paymentMethod: 'Credit Card' | 'Bank Transfer' | 'Platform Wallet';
  paymentDate: string; // ISO Date string
  transactionId?: string; // Optional transaction ID from payment gateway
}

// Proposal related type
export interface Proposal {
  id: string;
  projectId: string;
  expertId: string;
  expertName: string; // Denormalized for easier display
  coverLetter: string;
  bidAmount?: number;
  currency?: string;
  estimatedDeliveryTime?: string; // e.g., "2 weeks", "1 month"
  submittedDate: string; // ISO Date string
  status: 'Pending' | 'Accepted' | 'Rejected' | 'Withdrawn';
}