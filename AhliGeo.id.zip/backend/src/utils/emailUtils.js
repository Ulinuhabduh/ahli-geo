// backend/src/utils/emailUtils.js
import nodemailer from 'nodemailer';

export const sendEmail = async (to, subject, html) => {
    try {
        // Configure the email transporter
        const transporter = nodemailer.createTransport({
            service: 'gmail', // Use your email service (e.g., Gmail, SendGrid, etc.)
            auth: {
                user: process.env.EMAIL_USER, // Your email address
                pass: process.env.EMAIL_PASS, // Your email password or app-specific password
            },
        });

        // Define the email options
        const mailOptions = {
            from: process.env.EMAIL_USER, // Sender address
            to, // Recipient address
            subject, // Email subject
            html, // Email body (HTML format)
        };

        // Send the email
        const info = await transporter.sendMail(mailOptions);
        console.log(`Email sent: ${info.response}`);
    } catch (error) {
        console.error('Error sending email:', error.message);
        throw new Error('Failed to send email.');
    }
};