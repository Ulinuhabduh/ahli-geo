// backend/src/routes/adminRoutes.js
import express from 'express';
import { getAllUsers, updateUserById, deleteUserById, restoreUserById, 
    getAllProjectsForAdmin, updateProjectStatus, getExpertList, reassignProjectExpert } from '../controllers/adminController.js';
import { protect } from '../middleware/authMiddleware.js'; // Middleware otentikasi
import { adminOnly } from '../middleware/adminMiddleware.js'; // Middleware otorisasi admin

const router = express.Router();

// Semua rute di file ini akan dilindungi oleh protect dan adminOnly
router.use(protect, adminOnly);

// Rute untuk User
router.route('/users').get(getAllUsers);
router.route('/users/:id').put(updateUserById).delete(deleteUserById);
router.route('/users/:id/restore').put(restoreUserById);
router.route('/projects').get(getAllProjectsForAdmin);
router.route('/projects/:id/status').put(updateProjectStatus);
// Rute baru untuk mengambil daftar expert
router.route('/list/experts').get(getExpertList);

// Rute baru untuk re-assign
router.route('/projects/:id/reassign').put(reassignProjectExpert);

export default router;