// src/routes/chatRoutes.js
import express from 'express';
// Gunakan nama fungsi yang benar dari controller
import {
    initiateChatSession,
    getUserSessions,
    getSessionMessages,
    postNewMessage
} from '../controllers/chatController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

// Semua rute di bawah ini memerlukan pengguna untuk login
router.use(protect);

// Endpoint untuk memulai/membuat sesi chat dengan pengguna lain
// URL: POST /api/v1/chat/sessions/initiate
router.post('/sessions/initiate', initiateChatSession);

// Endpoint untuk mengambil semua sesi chat milik pengguna yang login (inbox)
// URL: GET /api/v1/chat/sessions
router.get('/sessions', getUserSessions);

// Endpoint untuk mengambil semua pesan dari satu sesi chat
// URL: GET /api/v1/chat/sessions/:sessionId/messages
router.get('/sessions/:sessionId/messages', getSessionMessages);

// Endpoint untuk mengirim pesan baru ke dalam sebuah sesi
// URL: POST /api/v1/chat/sessions/:sessionId/messages
router.post('/sessions/:sessionId/messages', postNewMessage);

export default router;