// backend/src/routes/reviewRoutes.js
import express from 'express';
import { protect } from '../middleware/authMiddleware.js';
import { createReview, getReviewsForUser } from '../controllers/reviewController.js';

const router = express.Router();

router.post('/', protect, createReview);
router.get('/user/:userId', getReviewsForUser); // Endpoint publik untuk melihat ulasan

export default router;