// src/routes/authRoutes.js
import express from 'express';
import { register, login, getMe, setupProfile } from '../controllers/authController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.post('/register', register);
router.post('/login', login);
router.get('/me', protect, getMe); // 'getMe' is used here
router.post('/profile/setup', protect, setupProfile);

export default router;