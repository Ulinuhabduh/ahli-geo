// src/routes/projectRoutes.js
import express from 'express';
// Tambahkan updateProject ke import
import { getAllProjects, getProjectById, createProject, updateProject, submitDelivery, completeProject } from '../controllers/projectController.js';
import { protect, authorize } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/', getAllProjects);
router.post('/', protect, authorize('client'), createProject);

router.get('/:projectId', getProjectById);
// ===== TAMBAHKAN ROUTE BARU INI =====
router.put('/:projectId', protect, authorize('client'), updateProject);

router.post('/:projectId/deliver', protect, submitDelivery);
router.post('/:projectId/complete', protect, completeProject);

export default router;