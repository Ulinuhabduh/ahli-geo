// backend/src/routes/payoutRoutes.js

import express from 'express';
// Impor dari authMiddleware
import { protect, expertOnly } from '../middleware/authMiddleware.js'; 
import { getAccount, saveAccount } from '../controllers/payoutController.js';

const router = express.Router();

// Terapkan middleware pada semua rute di file ini
router.use(protect, expertOnly);

router.route('/account')
    .get(getAccount)
    .post(saveAccount);

export default router;