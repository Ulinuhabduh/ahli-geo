// src/routes/index.js
import express from 'express';
import authRoutes from './authRoutes.js';
import projectRoutes from './projectRoutes.js';
import expertRoutes from './expertRoutes.js';
import masterDataRoutes from './masterDataRoutes.js';
import proposalRoutes from './proposalRoutes.js'; // 
import notificationRoutes from './notificationRoutes.js';
import chatRoutes from './chatRoutes.js';
import paymentRoutes from './paymentRoutes.js';
import reviewRoutes from './reviewRoutes.js';
import adminRoutes from './adminRoutes.js';
import payoutRoutes from './payoutRoutes.js'

const router = express.Router();

// ...
// ...

// Gunakan router sebagai papan penunjuk arah (dispatcher)
router.use('/auth', authRoutes);
router.use('/projects', projectRoutes);
router.use('/experts', expertRoutes);
router.use('/master', masterDataRoutes);
router.use('/proposals', proposalRoutes);
router.use('/notifications', notificationRoutes);
router.use('/payments', paymentRoutes);
router.use('/chat', chatRoutes);
router.use('/reviews', reviewRoutes);
router.use('/admin', adminRoutes); // Gunakan prefix /api/admin
router.use('/payouts', payoutRoutes);


export default router;