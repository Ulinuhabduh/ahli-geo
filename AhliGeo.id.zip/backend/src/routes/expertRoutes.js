// backend/src/routes/expertRoutes.js

import express from 'express';
import { protect } from '../middleware/authMiddleware.js';
import { getAllExperts, getExpertById, updateMyProfile } from '../controllers/expertController.js';

const router = express.Router();

router.get('/', getAllExperts);
router.get('/:expertId', getExpertById);

// TAMBAHKAN RUTE INI
router.put('/profile', protect, updateMyProfile);

export default router;