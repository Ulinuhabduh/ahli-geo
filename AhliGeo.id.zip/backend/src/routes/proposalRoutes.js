// src/routes/proposalRoutes.js
import express from 'express';
import { createProposal, getProposalsForProject, checkExpertApplication, getMyProposals } from '../controllers/proposalController.js';
import { protect, authorize } from '../middleware/authMiddleware.js';

const router = express.Router();

// Route untuk membuat proposal baru oleh 'expert'
// URL: POST /api/v1/proposals/
router.post('/', protect, authorize('expert'), createProposal);

// Route untuk client melihat proposal untuk proyeknya
// URL: GET /api/v1/proposals/project/:projectId
router.get('/project/:projectId', protect, authorize('client'), getProposalsForProject);

// Route untuk client menerima proposal
// URL: PUT /api/v1/proposals/:proposalId/accept
// router.put('/:proposalId/accept', protect, authorize('client'), acceptProposal);

router.get('/check/:projectId', protect, authorize('expert'), checkExpertApplication);
router.get('/my-applications', protect, authorize('expert'), getMyProposals);

export default router;