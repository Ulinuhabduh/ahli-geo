// src/routes/paymentRoutes.js
import express from 'express';
import { processPayment } from '../controllers/paymentController.js';
import { protect, authorize } from '../middleware/authMiddleware.js';
import { createPaymentForProposal } from '../controllers/paymentController.js'; // Pastikan path ini benar
import { handleMidtransNotification } from '../controllers/webhookController.js';

const router = express.Router();

// POST /api/v1/payments - Client makes a payment for a project
router.post('/', protect, authorize('client'), processPayment);
router.post('/proposal/:proposalId', protect, createPaymentForProposal);
router.post('/midtrans-notification', handleMidtransNotification);

export default router;