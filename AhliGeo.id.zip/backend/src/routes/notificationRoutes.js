// src/routes/notificationRoutes.js
import express from 'express';
import { createInvitation, getMyNotifications } from '../controllers/notificationController.js';
import { protect, authorize } from '../middleware/authMiddleware.js';

const router = express.Router();

// Client mengundang expert
// URL: POST /api/v1/notifications/invitations
router.post('/invitations', protect, authorize('client'), createInvitation);

// Expert mengambil notifikasinya
// URL: GET /api/v1/notifications/
router.get('/', protect, getMyNotifications);

export default router;