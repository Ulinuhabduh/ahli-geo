// src/routes/masterDataRoutes.js
import express from 'express';
import { getAllSkills, getAllSoftware, getAllLocations, createSkill, createSoftware, uploadImage  } from '../controllers/masterDataController.js';
import { protect } from '../middleware/authMiddleware.js';
import multer from 'multer';
import { storage } from '../config/cloudinary.js';
// No 'protect' middleware needed if this data is public

const router = express.Router();
const upload = multer({ storage });

router.get('/skills', getAllSkills);
router.get('/software', getAllSoftware);
router.get('/locations', getAllLocations);
router.post('/skills', createSkill);
router.post('/software', createSoftware);
router.post('/upload-image', upload.single('profileImage'), uploadImage);

export default router;