// src/middleware/authMiddleware.js
import { verifyToken } from '../utils/jwtUtils.js';
import User from '../models/User.js'; // Optional: if you need to fetch full user from DB on every protected route

export const protect = async (req, res, next) => {
    let token;
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        try {
            token = req.headers.authorization.split(' ')[1];
            const decoded = verifyToken(token); // verifyToken should return payload or null

            if (!decoded || !decoded.userId) { // Check if decoded is valid and has userId
                return res.status(401).json({ message: 'Not authorized, token verification failed or malformed' });
            }
            req.user = decoded; // Decoded payload: { userId, email, role, iat, exp }
            next();
        } catch (error) { // Should not happen if verifyToken handles its own try/catch and returns null
            console.error("Auth middleware (protect) error:", error.message);
            return res.status(401).json({ message: 'Not authorized, token processing error' });
        }
    }
    if (!token) {
        return res.status(401).json({ message: 'Not authorized, no token provided' });
    }
};

export const authorize = (...roles) => {
    return (req, res, next) => {
        if (!req.user || !req.user.role || !roles.includes(req.user.role)) {
            return res.status(403).json({ message: `User role ${req.user ? req.user.role : 'unknown'} is not authorized for this resource` });
        }
        next();
    };
};

export const expertOnly = (req, res, next) => {
    // Middleware ini harus dijalankan SETELAH `protect`
    // agar `req.user` sudah tersedia.
    if (req.user && req.user.role === 'expert') {
        next(); // Lanjutkan jika peran adalah 'expert'
    } else {
        // Kirim status 403 Forbidden jika bukan 'expert'
        res.status(403).json({ message: 'Access denied. Expert privileges required.' });
    }
};