// ahli_geo_backend/src/middleware/errorMiddleware.js
import config from '../config/index.js'; // To access NODE_ENV

// Handles 404 errors - when no other route matches
export const notFound = (req, res, next) => {
    const error = new Error(`Not Found - ${req.originalUrl}`);
    res.status(404);
    next(error); // Pass the error to the global error handler
};

// Global error handler - catches errors passed by next(error)
export const errorHandler = (err, req, res, next) => {
    // Log the error for server-side debugging (important!)
    console.error("ERROR STACK:", err.stack);
    console.error("ERROR MESSAGE:", err.message);

    // Determine the status code:
    // If res.statusCode is already set and not 200 (e.g., by a previous error or manually in a controller), use that.
    // Otherwise, if err.statusCode is set (custom error), use that.
    // Otherwise, default to 500 (Internal Server Error).
    let statusCode = res.statusCode !== 200 ? res.statusCode : (err.statusCode || 500);

    // Ensure a valid HTTP status code
    if (statusCode < 400 || statusCode > 599) {
        statusCode = 500;
    }

    res.status(statusCode);

    res.json({
        message: err.message || 'An unexpected error occurred.',
        // Only include the stack trace in development for security reasons
        stack: config.nodeEnv === 'development' ? err.stack : undefined,
    });
};