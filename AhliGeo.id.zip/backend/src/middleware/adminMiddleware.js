// backend/src/middleware/adminMiddleware.js

export const adminOnly = (req, res, next) => {
    // Middleware ini harus dijalankan SETELAH authMiddleware (protect)
    // sehingga req.user sudah tersedia.
    if (req.user && req.user.role === 'admin') {
        next(); // Lanjutkan jika user adalah admin
    } else {
        // Kirim status 403 Forbidden jika bukan admin
        res.status(403).json({ message: 'Access denied. Admin privileges required.' });
    }
};