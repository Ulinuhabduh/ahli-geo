// backend/src/models/Review.js
import db from '../db/index.js';
import { v4 as uuidv4 } from 'uuid';

const Review = {
    async create({ projectId, reviewerId, revieweeId, rating, comment }) {
        const newId = uuidv4();
        const queryText = `
      INSERT INTO reviews (id, project_id, reviewer_id, reviewee_id, rating, comment)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *;
    `;
        const values = [newId, projectId, reviewerId, revieweeId, rating, comment];
        const { rows } = await db.query(queryText, values);
        return rows[0];
    },

    async findByProjectId(projectId) {
        const queryText = `
      SELECT 
        r.id,
        r.rating,
        r.comment,
        r.created_at AS "createdAt",
        r.reviewer_id AS "reviewerId",
        u_reviewer.name AS "reviewerName"
      FROM reviews r
      JOIN users u_reviewer ON r.reviewer_id = u_reviewer.id
      WHERE r.project_id = $1;
    `;
        const { rows } = await db.query(queryText, [projectId]);
        return rows;
    },

    async findByRevieweeId(revieweeId) {
        const queryText = `
      SELECT 
        r.id,
        r.rating,
        r.comment,
        r.created_at AS "createdAt",
        r.reviewer_id AS "reviewerId",
        u_reviewer.name AS "reviewerName",
        p.title AS "projectTitle"
      FROM reviews r
      JOIN users u_reviewer ON r.reviewer_id = u_reviewer.id
      JOIN projects p ON r.project_id = p.id
      WHERE r.reviewee_id = $1
      ORDER BY r.created_at DESC;
    `;
        const { rows } = await db.query(queryText, [revieweeId]);
        return rows;
    },

    // Fungsi untuk cek apakah user sudah memberikan review untuk proyek tertentu
    async hasUserReviewed(projectId, reviewerId) {
        const queryText = `
      SELECT 1 FROM reviews WHERE project_id = $1 AND reviewer_id = $2 LIMIT 1;
    `;
        const { rows } = await db.query(queryText, [projectId, reviewerId]);
        return rows.length > 0;
    }
};

export default Review;