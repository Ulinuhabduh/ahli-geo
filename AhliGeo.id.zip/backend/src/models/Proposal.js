// src/models/Proposal.js
import db from '../db/index.js';
import { v4 as uuidv4 } from 'uuid';
import Notification from './Notification.js'; // Pastikan Notification diimpor

const Proposal = {
    // GANTI SELURUH FUNGSI CREATE INI
    async create(proposalData) {
        const { projectId, expertId, coverLetter, proposedRate, expertName, clientOwnerId } = proposalData;
        const newProposalId = uuidv4();

        try {
            await db.query('BEGIN');

            // 1. INSERT proposal baru ke dalam tabel proposals
            const proposalInsertQuery = `
        INSERT INTO proposals(id, project_id, expert_id, cover_letter, proposed_rate)
        VALUES($1, $2, $3, $4, $5)
        RETURNING *;
      `;
            const proposalValues = [newProposalId, projectId, expertId, coverLetter, proposedRate || null];
            const { rows } = await db.query(proposalInsertQuery, proposalValues);

            // 2. UPDATE proposals_count di tabel projects
            const projectUpdateQuery = `
        UPDATE projects
        SET proposals_count = proposals_count + 1
        WHERE id = $1;
      `;
            await db.query(projectUpdateQuery, [projectId]);

            // 3. BUAT NOTIFIKASI UNTUK CLIENT
            const notificationMessage = `${expertName} has submitted a proposal for your project.`;
            // Panggil Notification.create dengan data yang benar
            await Notification.create({
                recipientId: clientOwnerId,
                type: 'NEW_PROPOSAL',
                message: notificationMessage,
                projectId: projectId,
            });

            await db.query('COMMIT');
            return rows[0];

        } catch (error) {
            await db.query('ROLLBACK');
            console.error('Error in Proposal.create transaction', error);
            throw error;
        }
    },

    // Fungsi lain (findByProjectId, accept, dll.) tidak perlu diubah dari versi sebelumnya yang sudah benar.
    async findByProjectId(projectId) {
        const queryText = `
      SELECT 
        p.id, p.project_id AS "projectId", p.expert_id AS "expertId",
        p.cover_letter AS "coverLetter", p.proposed_rate AS "proposedRate",
        p.status, p.submitted_date AS "submittedDate",
        u.name AS "expertName", ep.headline AS "expertHeadline"
      FROM proposals p
      JOIN users u ON p.expert_id = u.id
      LEFT JOIN expert_profiles ep ON u.id = ep.user_id
      WHERE p.project_id = $1 ORDER BY p.submitted_date DESC;
    `;
        const { rows } = await db.query(queryText, [projectId]);
        return rows;
    },

    async accept(proposalId, projectId, expertId) {
        try {
            await db.query('BEGIN');
            await db.query(`UPDATE proposals SET status = 'Accepted' WHERE id = $1`, [proposalId]);
            await db.query(`UPDATE proposals SET status = 'Rejected' WHERE project_id = $1 AND id != $2`, [projectId, proposalId]);
            await db.query(`UPDATE projects SET status = 'In Progress', assigned_expert_id = $1 WHERE id = $2`, [expertId, projectId]);
            await db.query('COMMIT');
            return { success: true, message: 'Proposal accepted.' };
        } catch (error) {
            await db.query('ROLLBACK');
            throw error;
        }
    },

    async findById(id) {
        const queryText = `
            SELECT 
                id, 
                project_id AS "projectId", 
                expert_id AS "expertId", 
                cover_letter AS "coverLetter", 
                proposed_rate AS "proposedRate", 
                status, 
                submitted_date AS "submittedDate"
            FROM proposals 
            WHERE id = $1;
        `;
        try {
            const { rows } = await db.query(queryText, [id]);
            // Kembalikan objek proposal pertama, atau null jika tidak ditemukan
            return rows.length > 0 ? rows[0] : null;
        } catch (error) {
            console.error(`Error finding proposal by ID ${id}:`, error);
            throw error;
        }
    },

    async findByProjectAndExpert(projectId, expertId) {
        const queryText = `SELECT id FROM proposals WHERE project_id = $1 AND expert_id = $2 LIMIT 1;`;
        const { rows } = await db.query(queryText, [projectId, expertId]);
        return rows[0];
    },

    async findByExpertId(expertId) {
        const queryText = `
      SELECT 
        prop.id, prop.status, prop.submitted_date AS "submittedDate",
        p.id AS "projectId", p.title AS "projectTitle", u.name AS "clientName"
      FROM proposals prop
      JOIN projects p ON prop.project_id = p.id
      JOIN users u ON p.client_id = u.id
      WHERE prop.expert_id = $1 ORDER BY prop.submitted_date DESC;
    `;
        const { rows } = await db.query(queryText, [expertId]);
        return rows;
    },
};

export default Proposal;