import db from '../db/index.js';
import { v4 as uuidv4 } from 'uuid';
// Generated code
const ChatMessage = {
    async create({ session_id, sender_id, sender_name, text }) {
        const id = uuidv4();
        const timestamp = new Date().toISOString();
        const is_read = false; // Default

        const queryText = `
      INSERT INTO chat_messages (id, session_id, sender_id, sender_name, text, timestamp, is_read)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING *;
    `;
        const values = [id, session_id, sender_id, sender_name, text, timestamp, is_read];
        try {
            const { rows } = await db.query(queryText, values);
            return rows[0];
        } catch (err) {
            console.error('Error creating chat message in DB:', err.message, err.stack);
            throw err;
        }
    },

    async findBySessionId(sessionId) {
        const queryText = `
        SELECT * FROM chat_messages 
        WHERE session_id = $1 
        ORDER BY timestamp ASC;
    `;
        try {
            const { rows } = await db.query(queryText, [sessionId]);
            return rows;
        } catch (err) {
            console.error('Error fetching messages by session ID:', err.message, err.stack);
            throw err;
        }
    }
    // Add methods for marking messages as read if needed
};
export default ChatMessage;