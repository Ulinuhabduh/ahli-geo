// backend/src/models/PayoutAccount.js

import db from '../db/index.js';
import { v4 as uuidv4 } from 'uuid';

const PayoutAccount = {
    /**
     * Menemukan akun payout berdasarkan ID expert.
     */
    async findByExpertId(expertId) {
        const queryText = `
            SELECT 
                id, 
                expert_id AS "expertId", 
                bank_name AS "bankName", 
                account_holder_name AS "accountHolderName",
                account_number AS "accountNumber"
            FROM payout_accounts 
            WHERE expert_id = $1;
        `;
        const { rows } = await db.query(queryText, [expertId]);
        return rows[0]; // Akan undefined jika tidak ditemukan
    },

    /**
     * Membuat atau memperbarui (upsert) akun payout untuk seorang expert.
     */
    async upsert({ expertId, bankName, accountHolderName, accountNumber }) {
        const queryText = `
            INSERT INTO payout_accounts (expert_id, bank_name, account_holder_name, account_number)
            VALUES ($1, $2, $3, $4)
            ON CONFLICT (expert_id) 
            DO UPDATE SET
                bank_name = EXCLUDED.bank_name,
                account_holder_name = EXCLUDED.account_holder_name,
                account_number = EXCLUDED.account_number,
                updated_at = NOW()
            RETURNING 
                id, 
                expert_id AS "expertId", 
                bank_name AS "bankName", 
                account_holder_name AS "accountHolderName",
                account_number AS "accountNumber";
        `;
        const values = [expertId, bankName, accountHolderName, accountNumber];
        const { rows } = await db.query(queryText, values);
        return rows[0];
    }
};

export default PayoutAccount;