
// ahli_geo_backend/src/models/ExpertProfile.js
import db from '../db/index.js';

const ExpertProfile = {
    async findAll(filters = {}) {
        let queryText = `
      SELECT
            u.id, u.name, u.email, u.role, u.profile_setup_completed,
            ep.headline, ep.location, ep.experience_years,
            ep.profile_image_url, ep.bio, ep.verified, ep.hourly_rate,

            -- === PERBAIKAN UTAMA: HITUNG RATING DARI TABEL REVIEWS ===
            (
                SELECT AVG(r.rating)
                FROM reviews r
                WHERE r.reviewee_id = u.id
            ) AS rating,
            (
                SELECT COUNT(r.id)
                FROM reviews r
                WHERE r.reviewee_id = u.id
            ) AS review_count,
        COALESCE(
            (SELECT json_agg(json_build_object('id', s.id, 'name', s.name))
             FROM skills s
             JOIN expert_skills es ON s.id = es.skill_id
             WHERE es.expert_user_id = u.id),
            '[]'::json
        ) AS skills,
        COALESCE(
            (SELECT json_agg(json_build_object('id', sw.id, 'name', sw.name))
             FROM software sw
             JOIN expert_software eso ON sw.id = eso.software_id
             WHERE eso.expert_user_id = u.id),
            '[]'::json
        ) AS software
      FROM users u
      LEFT JOIN expert_profiles ep ON u.id = ep.user_id 
      WHERE u.role = 'expert' 
    `;
        // Menggunakan LEFT JOIN agar expert yang belum memiliki entri di expert_profiles tetap muncul (meskipun field profilnya akan null)
        // Ini penting jika registrasi membuat user dulu, lalu profil expert.

        const queryParams = [];
        let paramIndex = 1;

        if (filters.searchTerm) {
            queryText += ` AND (u.name ILIKE $${paramIndex} OR ep.headline ILIKE $${paramIndex} OR ep.bio ILIKE $${paramIndex}) `;
            queryParams.push(`%${filters.searchTerm}%`);
            paramIndex++;
        }
        if (filters.minExperience !== undefined) {
            queryText += ` AND ep.experience_years >= $${paramIndex++} `;
            queryParams.push(filters.minExperience);
        }
        if (filters.showVerifiedOnly) {
            queryText += ` AND ep.verified = TRUE `;
        }
        if (filters.selectedSkills && filters.selectedSkills.length > 0) {
            queryText += ` AND EXISTS (SELECT 1 FROM expert_skills es_filter WHERE es_filter.expert_user_id = u.id AND es_filter.skill_id = ANY($${paramIndex++}::varchar[])) `;
            queryParams.push(filters.selectedSkills);
        }
        if (filters.selectedSoftware && filters.selectedSoftware.length > 0) {
            queryText += ` AND EXISTS (SELECT 1 FROM expert_software eso_filter WHERE eso_filter.expert_user_id = u.id AND eso_filter.software_id = ANY($${paramIndex++}::varchar[])) `;
            queryParams.push(filters.selectedSoftware);
        }

        queryText += ` ORDER BY ep.rating DESC NULLS LAST, u.name ASC `;

        if (filters.limit) {
            queryText += ` LIMIT $${paramIndex++} `;
            queryParams.push(filters.limit);
        }

        try {
            const { rows } = await db.query(queryText, queryParams);
            return rows.map(row => ({
                id: row.id,
                name: row.name,
                email: row.email,
                role: row.role,
                profileSetupCompleted: row.profile_setup_completed,
                headline: row.headline,
                location: row.location,
                experienceYears: row.experience_years,
                rating: row.rating,
                reviewCount: parseInt(row.review_count, 10),
                profileImageUrl: row.profile_image_url,
                bio: row.bio,
                verified: row.verified,
                hourlyRate: row.hourly_rate,
                skills: Array.isArray(row.skills) ? row.skills : [],
                software: Array.isArray(row.software) ? row.software : [],
            }));
        } catch (err) {
            console.error('Error fetching experts from DB (ExpertProfile.findAll):', err.message, err.stack);
            throw err;
        }
    },

    async findById(expertUserId) {
        const queryText = `
      SELECT
            u.id, u.name, u.email, u.role, u.profile_setup_completed,
            ep.headline, ep.location, ep.experience_years,
            ep.profile_image_url, ep.bio, ep.verified, ep.hourly_rate,

            -- === TERAPKAN PERBAIKAN YANG SAMA DI SINI ===
            (
                SELECT AVG(r.rating)
                FROM reviews r
                WHERE r.reviewee_id = u.id
            ) AS rating,
            (
                SELECT COUNT(r.id)
                FROM reviews r
                WHERE r.reviewee_id = u.id
            ) AS review_count,
        COALESCE(
            (SELECT json_agg(json_build_object('id', s.id, 'name', s.name))
             FROM skills s
             JOIN expert_skills es ON s.id = es.skill_id
             WHERE es.expert_user_id = u.id),
            '[]'::json
        ) AS skills,
        COALESCE(
            (SELECT json_agg(json_build_object('id', sw.id, 'name', sw.name))
             FROM software sw
             JOIN expert_software eso ON sw.id = eso.software_id
             WHERE eso.expert_user_id = u.id),
            '[]'::json
        ) AS software
      FROM users u
      LEFT JOIN expert_profiles ep ON u.id = ep.user_id 
      WHERE u.id = $1 AND u.role = 'expert';
    `;
        // Menggunakan LEFT JOIN di sini juga, untuk kasus di mana user expert ada tapi profilnya belum terisi lengkap
        try {
            const { rows } = await db.query(queryText, [expertUserId]);
            if (rows.length > 0) {
                const row = rows[0];
                return {
                    id: row.id,
                    name: row.name,
                    email: row.email,
                    role: row.role,
                    profileSetupCompleted: row.profile_setup_completed,
                    headline: row.headline, // Bisa null jika LEFT JOIN dan tidak ada data di ep
                    location: row.location,
                    experienceYears: row.experience_years,
                    rating: row.rating,
                    reviewCount: parseInt(row.review_count, 10),
                    profileImageUrl: row.profile_image_url,
                    bio: row.bio,
                    verified: row.verified !== undefined ? row.verified : false, // Default jika null dari DB
                    hourlyRate: row.hourly_rate,
                    skills: Array.isArray(row.skills) ? row.skills : [],
                    software: Array.isArray(row.software) ? row.software : [],
                };
            }
            return null; // Atau kembalikan data user dasar jika hanya user yang ditemukan
        } catch (err) {
            console.error('Error fetching expert by ID from DB (ExpertProfile.findById):', err.message, err.stack);
            throw err;
        }
    },

    async createOrUpdate(userId, expertData) {
        const {
            headline, location, experience_years, profile_image_url, bio,
            hourly_rate, skills = [], software = []
        } = expertData;

        // Query UPSERT (INSERT or UPDATE)
        const dynamicExpertProfileQuery = `
            INSERT INTO expert_profiles (user_id, headline, location, experience_years, profile_image_url, bio, hourly_rate, created_at, updated_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            ON CONFLICT (user_id) DO UPDATE SET
                headline = EXCLUDED.headline,
                location = EXCLUDED.location,
                experience_years = EXCLUDED.experience_years,
                profile_image_url = EXCLUDED.profile_image_url,
                bio = EXCLUDED.bio,
                hourly_rate = EXCLUDED.hourly_rate,
                updated_at = CURRENT_TIMESTAMP
            RETURNING *;
        `;
        const insertValues = [
            userId,
            headline || null,
            location || null,
            experience_years || 0,
            profile_image_url || null,
            bio || null,
            hourly_rate || null
        ];

        const client = await db.pool.connect();
        try {
            await client.query('BEGIN');

            await client.query(dynamicExpertProfileQuery, insertValues);

            // Hapus skill dan software lama, lalu masukkan yang baru
            await client.query('DELETE FROM expert_skills WHERE expert_user_id = $1', [userId]);
            await client.query('DELETE FROM expert_software WHERE expert_user_id = $1', [userId]);

            if (skills && Array.isArray(skills) && skills.length > 0) {
                for (const skill of skills) {
                    if (skill && skill.id) {
                        await client.query(
                            'INSERT INTO expert_skills (expert_user_id, skill_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
                            [userId, skill.id]
                        );
                    }
                }
            }
            if (software && Array.isArray(software) && software.length > 0) {
                for (const sw of software) {
                    if (sw && sw.id) {
                        await client.query(
                            'INSERT INTO expert_software (expert_user_id, software_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
                            [userId, sw.id]
                        );
                    }
                }
            }

            await client.query('COMMIT');
        } catch (err) {
            await client.query('ROLLBACK');
            console.error('Error in ExpertProfile.createOrUpdate:', err);
            throw err;
        } finally {
            client.release();
        }
    }
};

export default ExpertProfile;
