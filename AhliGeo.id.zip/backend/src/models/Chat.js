// src/models/Chat.js
import db from '../db/index.js';
import { v4 as uuidv4 } from 'uuid';

const Chat = {
    // Mencari sesi yang sudah ada antara dua pengguna
    async findExistingSession(user1Id, user2Id) {
        const query = `
      SELECT p1.session_id
      FROM chat_session_participants p1
      JOIN chat_session_participants p2 ON p1.session_id = p2.session_id
      WHERE p1.user_id = $1 AND p2.user_id = $2;
    `;
        const { rows } = await db.query(query, [user1Id, user2Id]);
        return rows[0] ? rows[0].session_id : null;
    },

    // Membuat sesi baru dan menambahkan kedua partisipan
    async createSession(user1Id, user2Id) {
        const newSessionId = uuidv4();
        try {
            await db.query('BEGIN');
            await db.query('INSERT INTO chat_sessions (id) VALUES ($1)', [newSessionId]);
            await db.query('INSERT INTO chat_session_participants (session_id, user_id) VALUES ($1, $2), ($1, $3)', [newSessionId, user1Id, user2Id]);
            await db.query('COMMIT');
            return newSessionId;
        } catch (error) {
            await db.query('ROLLBACK');
            throw error;
        }
    },

    // Mengambil semua sesi chat untuk seorang pengguna (untuk "inbox")
    async getSessionsForUser(userId) {
        const query = `
            WITH latest_messages AS (
                -- Pertama, temukan pesan terakhir untuk setiap sesi
                SELECT 
                    session_id,
                    message_text,
                    sender_id,
                    created_at,
                    -- Beri peringkat pesan dalam setiap sesi berdasarkan waktu
                    ROW_NUMBER() OVER(PARTITION BY session_id ORDER BY created_at DESC) as rn
                FROM chat_messages
            )
            SELECT 
                cs.id AS "sessionId",
                p_other.user_id AS "recipientId",
                u_other.name AS "recipientName",
                'https://ui-avatars.com/api/?name=' || REPLACE(u_other.name, ' ', '+') || '&background=random' AS "recipientProfileImageUrl",
                
                -- ===== PERUBAHAN LOGIKA UTAMA DI SINI =====
                -- Ambil pesan terakhir dari CTE (Common Table Expression) di atas
                lm.message_text AS "lastMessage",
                lm.created_at AS "lastMessageTimestamp",
                
                -- Tambahkan informasi siapa pengirim pesan terakhir
                lm.sender_id AS "lastMessageSenderId"

            FROM chat_session_participants AS p_current
            JOIN chat_session_participants AS p_other 
                ON p_current.session_id = p_other.session_id AND p_current.user_id != p_other.user_id
            JOIN users AS u_other 
                ON p_other.user_id = u_other.id
            JOIN chat_sessions AS cs 
                ON p_current.session_id = cs.id
            -- Gabungkan dengan pesan terakhir, hanya ambil yang peringkatnya #1
            LEFT JOIN latest_messages lm ON cs.id = lm.session_id AND lm.rn = 1
            WHERE p_current.user_id = $1
            ORDER BY "lastMessageTimestamp" DESC NULLS LAST;
        `;
        try {
            const { rows } = await db.query(query, [userId]);
            return rows;
        } catch (error) {
            console.error("Error in getSessionsForUser:", error);
            throw error;
        }
    },

    // Mengambil semua pesan untuk satu sesi
    async getMessagesForSession(sessionId) {
        const query = `
      SELECT
        id,
        sender_id AS "senderId",
        message_text AS "messageText",
        is_read AS "isRead",
        created_at AS "createdAt"
      FROM chat_messages
      WHERE session_id = $1
      ORDER BY created_at ASC;
    `;
        const { rows } = await db.query(query, [sessionId]);
        return rows;
    },

    // Membuat pesan baru
    async createMessage(senderId, sessionId, messageText) {
        const newMessageId = uuidv4();
        const query = `
      INSERT INTO chat_messages (id, sender_id, session_id, message_text)
      VALUES ($1, $2, $3, $4)
      RETURNING id, sender_id AS "senderId", message_text AS "messageText", is_read AS "isRead", created_at AS "createdAt";
    `;
        const { rows } = await db.query(query, [newMessageId, senderId, sessionId, messageText]);
        return rows[0];
    }
};

export default Chat;