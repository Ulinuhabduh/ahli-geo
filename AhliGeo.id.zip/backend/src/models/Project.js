// src/models/Project.js
import db from '../db/index.js';
import { v4 as uuidv4 } from 'uuid';

// Helper untuk membangun query dasar dengan ALIAS camelCase
// backend/src/models/Project.js

const buildBaseQuery = () => `
    SELECT 
        p.id,
        p.title,
        p.description,
        p.client_id AS "clientId",
        p.budget_min AS "budgetMin",
        p.budget_max AS "budgetMax",
        p.currency,
        p.location_type AS "locationType",
        p.specific_location AS "specificLocation",
        p.status,
        p.posted_date AS "postedDate",
        p.deadline_date AS "deadlineDate",
        p.proposals_count AS "proposalsCount",
        p.assigned_expert_id AS "assignedExpertId",
        p.is_direct_hire AS "isDirectHire",
        p.delivery_text AS "deliveryText",
        p.delivery_attachments AS "deliveryAttachments",
        p.delivered_at AS "deliveredAt",
        u.name AS "clientName",
        u.company_name AS "companyName",
        (
            SELECT AVG(r.rating)
            FROM reviews r
            WHERE r.reviewee_id = p.client_id
        ) AS "clientAverageRating",
        (
            SELECT COUNT(r.id)
            FROM reviews r
            WHERE r.reviewee_id = p.client_id
        ) AS "clientReviewCount",
        COALESCE(
            (SELECT json_agg(s.*) FROM project_required_skills prs JOIN skills s ON s.id = prs.skill_id WHERE prs.project_id = p.id),
            '[]'::json
        ) AS "requiredSkills",
        COALESCE(
            (SELECT json_agg(sw.*) FROM project_required_software prsw JOIN software sw ON sw.id = prsw.software_id WHERE prsw.project_id = p.id),
            '[]'::json
        ) AS "requiredSoftware",
        COALESCE(
            (SELECT json_agg(
                json_build_object(
                    'id', r.id,
                    'rating', r.rating,
                    'comment', r.comment,
                    'reviewerId', r.reviewer_id
                )
            )
            FROM reviews r WHERE r.project_id = p.id),
            '[]'::json
        ) AS "reviews"
    FROM projects p
    LEFT JOIN users u ON p.client_id = u.id
`;

const Project = {
    async findAll(filters = {}) {
        let queryText = buildBaseQuery();
        const whereClauses = [];
        const queryParams = [];
        let paramIndex = 1;

        if (filters.clientId) {
            whereClauses.push(`p.client_id = $${paramIndex++}`);
            queryParams.push(filters.clientId);
        }
        if (filters.status) {
            whereClauses.push(`p.status = $${paramIndex++}`);
            queryParams.push(filters.status);
        }
        if (filters.searchTerm) {
            whereClauses.push(`(p.title ILIKE $${paramIndex} OR p.description ILIKE $${paramIndex})`);
            queryParams.push(`%${filters.searchTerm}%`);
            paramIndex++;
        }
        if (filters.locationType) {
            whereClauses.push(`p.location_type = $${paramIndex++}`);
            queryParams.push(filters.locationType);
        }
        if (filters.selectedSkills && filters.selectedSkills.length > 0) {
            whereClauses.push(`p.id IN (SELECT project_id FROM project_required_skills WHERE skill_id = ANY($${paramIndex++}::varchar[]))`);
            queryParams.push(filters.selectedSkills);
        }
        if (filters.selectedSoftware && filters.selectedSoftware.length > 0) {
            whereClauses.push(`p.id IN (SELECT project_id FROM project_required_software WHERE software_id = ANY($${paramIndex++}::varchar[]))`);
            queryParams.push(filters.selectedSoftware);
        }

        if (whereClauses.length > 0) {
            queryText += ` WHERE ${whereClauses.join(' AND ')}`;
        }
        queryText += ` ORDER BY p.posted_date DESC`;
        if (filters.limit) {
            queryText += ` LIMIT $${paramIndex++}`;
            queryParams.push(filters.limit);
        }

        const { rows } = await db.query(queryText, queryParams);
        return rows.map(row => ({
            id: row.id,
            title: row.title,
            description: row.description,
            clientId: row.clientId,
            budgetMin: row.budgetMin,
            budgetMax: row.budgetMax,
            currency: row.currency,
            locationType: row.locationType,
            specificLocation: row.specificLocation,
            status: row.status,
            postedDate: row.postedDate,
            deadlineDate: row.deadlineDate,
            proposalsCount: row.proposalsCount,
            assignedExpertId: row.assignedExpertId,
            isDirectHire: row.isDirectHire,
            deliveryText: row.deliveryText,
            deliveryAttachments: row.deliveryAttachments,
            deliveredAt: row.deliveredAt,
            clientName: row.clientName,
            companyName: row.companyName,
            clientAverageRating: row.clientAverageRating, // Ini sudah ada
            clientReviewCount: row.clientReviewCount ? parseInt(row.clientReviewCount, 10) : 0, // Konversi ke integer, default 0
            requiredSkills: row.requiredSkills,
            requiredSoftware: row.requiredSoftware,
            reviews: row.reviews,
        }));
    },

    async findById(id) {
        let queryText = buildBaseQuery();
        queryText += ' WHERE p.id = $1';

        const { rows } = await db.query(queryText, [id]);
        if (rows.length > 0) {
            const row = rows[0];
            // === PASTIKAN ANDA MEMETAKAN HASILNYA DI SINI JUGA ===
            return {
                id: row.id,
                title: row.title,
                description: row.description,
                clientId: row.clientId,
                budgetMin: row.budgetMin,
                budgetMax: row.budgetMax,
                currency: row.currency,
                locationType: row.locationType,
                specificLocation: row.specificLocation,
                status: row.status,
                postedDate: row.postedDate,
                deadlineDate: row.deadlineDate,
                proposalsCount: row.proposalsCount,
                assignedExpertId: row.assignedExpertId,
                isDirectHire: row.isDirectHire,
                deliveryText: row.deliveryText,
                deliveryAttachments: row.deliveryAttachments,
                deliveredAt: row.deliveredAt,
                clientName: row.clientName,
                companyName: row.companyName,
                clientAverageRating: row.clientAverageRating,
                clientReviewCount: row.clientReviewCount ? parseInt(row.clientReviewCount, 10) : 0,
                requiredSkills: row.requiredSkills,
                requiredSoftware: row.requiredSoftware,
                reviews: row.reviews,
            }
        }
        return null; // Jika tidak ditemukan, kembalikan null
    },

    async create(projectData) {
        // Fungsi create Anda sudah benar.
        try {
            await db.query('BEGIN');
            const newProjectId = uuidv4();
            const projectInsertQuery = `
                INSERT INTO projects(id, title, description, client_id, budget_min, budget_max, currency, location_type, specific_location, deadline_date, status)
                VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);
            `;
            const projectValues = [
                newProjectId, projectData.title, projectData.description,
                projectData.client_id, projectData.budgetMin || null, projectData.budgetMax || null,
                projectData.currency, projectData.locationType, projectData.specificLocation || null,
                projectData.deadlineDate || null, 'Open'
            ];
            await db.query(projectInsertQuery, projectValues);
            if (projectData.required_skills && projectData.required_skills.length > 0) {
                const skillIds = projectData.required_skills.map(skill => skill.id);
                const skillInsertQuery = 'INSERT INTO project_required_skills (project_id, skill_id) SELECT $1, unnest($2::varchar[])';
                await db.query(skillInsertQuery, [newProjectId, skillIds]);
            }
            if (projectData.required_software && projectData.required_software.length > 0) {
                const softwareIds = projectData.required_software.map(sw => sw.id);
                const softwareInsertQuery = 'INSERT INTO project_required_software (project_id, software_id) SELECT $1, unnest($2::varchar[])';
                await db.query(softwareInsertQuery, [newProjectId, softwareIds]);
            }
            await db.query('COMMIT');
            return this.findById(newProjectId);
        } catch (error) {
            await db.query('ROLLBACK');
            console.error('Error in Project.create transaction, rolled back.', error);
            throw error;
        }
    },

    async submitDelivery(projectId, expertId, deliveryData) {
        const { deliveryText, deliveryAttachments } = deliveryData;
        const queryText = `
        UPDATE projects
        SET 
            status = 'Delivered',
            delivery_text = $1,
            delivery_attachments = $2,
            delivered_at = NOW()
        WHERE id = $3 AND assigned_expert_id = $4
        RETURNING *;
    `;
        // Konversi array attachments ke JSON string jika ada
        const attachmentsJson = deliveryAttachments ? JSON.stringify(deliveryAttachments) : null;
        const { rows } = await db.query(queryText, [deliveryText, attachmentsJson, projectId, expertId]);
        if (rows.length === 0) {
            throw new Error('Project not found or you are not the assigned expert.');
        }
        return rows[0];
    },

    async complete(projectId, clientId) {
        const queryText = `
        UPDATE projects
        SET status = 'Completed'
        WHERE id = $1 AND client_id = $2 AND status = 'Delivered'
        RETURNING *;
    `;
        const { rows } = await db.query(queryText, [projectId, clientId]);
        if (rows.length === 0) {
            throw new Error('Project cannot be completed. It might not be delivered yet or you are not the client.');
        }
        return rows[0];
    },

    async update(projectId, projectData) {
        try {
            // Gunakan db.query untuk transaksi, bukan db.connect()
            await db.query('BEGIN');

            // 1. Update tabel 'projects' utama
            const fields = [];
            const values = [];
            let paramIndex = 1;

            const addField = (name, value) => {
                // Hanya tambahkan field ke query jika nilainya bukan undefined
                // Ini penting agar kita tidak sengaja meng-update field menjadi NULL
                if (value !== undefined) {
                    fields.push(`${name} = $${paramIndex++}`);
                    values.push(value);
                }
            };

            addField('title', projectData.title);
            addField('description', projectData.description);
            addField('budget_min', projectData.budgetMin);
            addField('budget_max', projectData.budgetMax);
            addField('currency', projectData.currency);
            addField('location_type', projectData.locationType);
            addField('specific_location', projectData.specificLocation);
            addField('deadline_date', projectData.deadlineDate);
            addField('status', projectData.status);

            if (fields.length > 0) {
                values.push(projectId); // Tambahkan projectId sebagai parameter terakhir untuk klausa WHERE
                const projectUpdateQuery = `UPDATE projects SET ${fields.join(', ')} WHERE id = $${paramIndex}`;
                await db.query(projectUpdateQuery, values);
            }

            // 2. Update skills (hapus semua lalu insert yang baru)
            // Hanya jalankan jika properti requiredSkills ada di data yang dikirim
            if (projectData.requiredSkills) {
                await db.query('DELETE FROM project_required_skills WHERE project_id = $1', [projectId]);
                if (projectData.requiredSkills.length > 0) {
                    const skillIds = projectData.requiredSkills.map(s => s.id);
                    const skillInsertQuery = 'INSERT INTO project_required_skills (project_id, skill_id) SELECT $1, unnest($2::varchar[])';
                    await db.query(skillInsertQuery, [projectId, skillIds]);
                }
            }

            // 3. Update software (hapus semua lalu insert yang baru)
            if (projectData.requiredSoftware) {
                await db.query('DELETE FROM project_required_software WHERE project_id = $1', [projectId]);
                if (projectData.requiredSoftware.length > 0) {
                    const softwareIds = projectData.requiredSoftware.map(s => s.id);
                    const softwareInsertQuery = 'INSERT INTO project_required_software (project_id, software_id) SELECT $1, unnest($2::varchar[])';
                    await db.query(softwareInsertQuery, [projectId, softwareIds]);
                }
            }

            await db.query('COMMIT');
            return this.findById(projectId); // Kembalikan data terbaru

        } catch (error) {
            await db.query('ROLLBACK'); // Batalkan transaksi jika ada error
            console.error('Error in Project.update transaction', error);
            throw error;
        }
        // Tidak perlu blok 'finally' lagi
    },

    async updateStatusById(projectId, newStatus) {
        const queryText = `
        UPDATE projects 
        SET status = $1, updated_at = NOW() 
        WHERE id = $2 
        RETURNING id, title, status;
    `;
        try {
            const { rows } = await db.query(queryText, [newStatus, projectId]);
            if (rows.length === 0) {
                throw new Error('Project not found or status is already the same.');
            }
            return rows[0];
        } catch (error) {
            console.error('Error in Project.updateStatusById:', error);
            throw error;
        }
    },

    async reassignExpertById(projectId, newExpertId) {
        const queryText = `
        UPDATE projects
        SET assigned_expert_id = $1, updated_at = NOW()
        WHERE id = $2
        RETURNING id, assigned_expert_id;
    `;
        try {
            const { rows } = await db.query(queryText, [newExpertId, projectId]);
            if (rows.length === 0) {
                throw new Error('Project not found.');
            }
            // TODO: Kirim notifikasi ke expert lama (jika ada) dan expert baru.
            return rows[0];
        } catch (error) {
            console.error('Error in Project.reassignExpertById:', error);
            throw error;
        }
    },

    // Di dalam file backend/src/models/Project.js

    async findAllForAdmin(filters = {}) {
        let queryText = `
        SELECT 
            p.id, p.title, p.status, p.budget_min AS "budgetMin", p.budget_max AS "budgetMax",
            p.currency, p.posted_date AS "postedDate", client.name AS "clientName", expert.name AS "expertName"
        FROM projects p
        LEFT JOIN users client ON p.client_id = client.id
        LEFT JOIN users expert ON p.assigned_expert_id = expert.id
    `;
        const whereClauses = [];
        const queryParams = [];
        let paramIndex = 1;

        // --- PERUBAHAN DI SINI ---
        // Tambahkan filter berdasarkan ID proyek spesifik
        if (filters.projectId) {
            whereClauses.push(`p.id = $${paramIndex++}`);
            queryParams.push(filters.projectId);
        }
        // --- AKHIR PERUBAHAN ---

        if (filters.status) {
            whereClauses.push(`p.status = $${paramIndex++}`);
            queryParams.push(filters.status);
        }
        if (filters.searchTerm) {
            whereClauses.push(`(p.title ILIKE $${paramIndex} OR client.name ILIKE $${paramIndex} OR expert.name ILIKE $${paramIndex})`);
            queryParams.push(`%${filters.searchTerm}%`);
            paramIndex++;
        }

        if (whereClauses.length > 0) {
            queryText += ` WHERE ${whereClauses.join(' AND ')}`;
        }

        queryText += ` ORDER BY p.posted_date DESC`;

        try {
            const { rows } = await db.query(queryText, queryParams);
            // Jika kita memfilter berdasarkan projectId, kita tahu hasilnya hanya satu atau nol.
            if (filters.projectId) {
                return rows[0] || null;
            }
            return rows;
        } catch (error) {
            console.error('Error in Project.findAllForAdmin:', error);
            throw error;
        }
    },
};

export default Project;