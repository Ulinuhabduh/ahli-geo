// src/models/User.js
import db from '../db/index.js';
import { v4 as uuidv4 } from 'uuid';

const User = {
    async create({ email, name, password_hash, role, company_name = null }) {
        const id = uuidv4();
        const queryText = `
      INSERT INTO users (id, email, name, password_hash, role, profile_setup_completed, company_name)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING id, email, name, role, profile_setup_completed, company_name;
    `;
        const values = [id, email, name, password_hash, role, false, company_name];
        try {
            const { rows } = await db.query(queryText, values);
            return rows[0];
        } catch (err) {
            console.error('Error creating user in DB:', err.message, err.stack);
            throw err;
        }
    },

    async findByEmail(email) {
        // DITAMBAHKAN: Klausul WHERE untuk hanya mencari user yang aktif
        const queryText = 'SELECT * FROM users WHERE email = $1 AND deleted_at IS NULL;';
        try {
            const { rows } = await db.query(queryText, [email]);
            return rows[0];
        } catch (err) {
            console.error('Error finding user by email in DB:', err.message, err.stack);
            throw err;
        }
    },

    async findById(id) {
        const queryText = `
            SELECT 
                id, email, name, role, 
                profile_setup_completed AS "profileSetupCompleted", 
                company_name AS "companyName" 
            FROM users 
            WHERE id = $1 AND deleted_at IS NULL; -- DITAMBAHKAN: Hanya cari user yang aktif
        `;
        try {
            const { rows } = await db.query(queryText, [id]);
            return rows[0];
        } catch (err) {
            console.error('Error finding user by id in DB:', err.message, err.stack);
            throw err;
        }
    },

    async findAllForAdmin() {
        const queryText = `
            SELECT
                id, email, name, role,
                profile_setup_completed AS "profileSetupCompleted",
                company_name AS "companyName",
                created_at AS "createdAt",
                updated_at AS "updatedAt",
                deleted_at AS "deletedAt" -- DITAMBAHKAN: Ambil status deleted_at
            FROM users
            ORDER BY created_at DESC;
            -- Catatan: Admin bisa melihat SEMUA user, termasuk yang sudah dihapus.
            -- Kita akan memfilter di frontend atau bisa juga menambahkan WHERE clause di sini jika perlu.
        `;
        try {
            const { rows } = await db.query(queryText);
            return rows;
        } catch (error) {
            console.error('Error in User.findAllForAdmin:', error);
            throw error;
        }
    },

    /**
     * INI ADALAH FUNGSI deleteById YANG LAMA, SEKARANG DIGANTI NAMANYA
     * DAN LOGIKANYA MENJADI SOFT DELETE.
     */
    async softDeleteById(id) {
        // Logika diubah dari DELETE menjadi UPDATE
        const queryText = 'UPDATE users SET deleted_at = NOW() WHERE id = $1 AND deleted_at IS NULL RETURNING *;';
        try {
            const { rows } = await db.query(queryText, [id]);
            if (rows.length === 0) {
                // Ini bisa berarti user tidak ditemukan, atau sudah dihapus sebelumnya
                throw new Error('User not found or already deleted.');
            }
            return rows[0]; // Mengembalikan user yang di-soft-delete sebagai konfirmasi
        } catch (error) {
            console.error('Error in User.softDeleteById:', error);
            throw error;
        }
    },

    async restoreById(id) {
        const queryText = 'UPDATE users SET deleted_at = NULL WHERE id = $1 AND deleted_at IS NOT NULL RETURNING *;';
        try {
            const { rows } = await db.query(queryText, [id]);
            if (rows.length === 0) {
                throw new Error('User not found or is already active.');
            }
            return rows[0]; // Mengembalikan user yang direstore
        } catch (error) {
            console.error('Error in User.restoreById:', error);
            throw error;
        }
    },

    // ====================================================================

    // Saya menyarankan untuk menggunakan fungsi updateById yang lebih aman di bawah ini
    // daripada yang Anda miliki, karena ini mencegah pembaruan kolom 'id' atau 'created_at'
    async updateById(userId, dataToUpdate) {
        // Daftar kolom yang boleh diupdate oleh admin
        const allowedFields = ['name', 'email', 'role', 'profile_setup_completed', 'company_name'];
        const fieldsToUpdate = {};

        // Filter data yang masuk untuk hanya menyertakan kolom yang diizinkan
        for (const key in dataToUpdate) {
            if (allowedFields.includes(key)) {
                fieldsToUpdate[key] = dataToUpdate[key];
            }
        }

        const fields = Object.keys(fieldsToUpdate);
        if (fields.length === 0) {
            console.warn("Update attempt on user with no valid fields.");
            return this.findById(userId); // Kembalikan data saat ini jika tidak ada yang diupdate
        }

        const values = Object.values(fieldsToUpdate);
        const setClauses = fields.map((field, index) => `${field} = $${index + 1}`).join(', ');

        const queryText = `
            UPDATE users 
            SET ${setClauses}, updated_at = NOW() 
            WHERE id = $${fields.length + 1} 
            RETURNING id, name, email, role, profile_setup_completed AS "profileSetupCompleted", company_name AS "companyName";
        `;

        try {
            const { rows } = await db.query(queryText, [...values, userId]);
            return rows[0];
        } catch (error) {
            console.error('Error in User.updateById:', error);
            throw error;
        }
    },

    async updateProfile(id, updates) {
        const fields = [];
        const values = [];
        let paramCount = 1;

        const allowedUserFields = ['name', 'password_hash', 'profile_setup_completed', 'company_name'];

        Object.keys(updates).forEach(key => {
            if (allowedUserFields.includes(key) && updates[key] !== undefined) {
                fields.push(`${key} = $${paramCount++}`);
                values.push(updates[key]);
            }
        });

        if (fields.length === 0) {
            return this.findById(id);
        }

        fields.push(`updated_at = CURRENT_TIMESTAMP`);
        values.push(id);

        const queryText = `
      UPDATE users
      SET ${fields.join(', ')}
      WHERE id = $${paramCount}
      RETURNING id, email, name, role, profile_setup_completed, company_name;
    `;

        try {
            const { rows } = await db.query(queryText, values);
            return rows[0];
        } catch (err) {
            console.error('Error updating user profile in DB:', err.message, err.stack);
            throw err;
        }
    }
};

export default User; // <<< THIS LINE IS ESSENTIAL