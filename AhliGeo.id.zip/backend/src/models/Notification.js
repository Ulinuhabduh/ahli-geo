// backend/src/models/Notification.js

import db from '../db/index.js';
import { v4 as uuidv4 } from 'uuid';

const Notification = {
  /**
   * Membuat notifikasi baru. Fungsi ini fleksibel dan bisa menjadi bagian dari
   * transaksi database yang lebih besar jika 'dbClient' disediakan.
   * @param {object} notificationData - Data untuk notifikasi { recipientId, type, message, projectId }.
   * @param {object} [dbClient=null] - Klien database opsional untuk transaksi.
   */
  async create(notificationData, dbClient = null) {
    const { recipientId, type, message, projectId } = notificationData;
    const newNotificationId = uuidv4();

    // Menggunakan nama kolom yang konsisten: 'related_project_id'
    const queryText = `
      INSERT INTO notifications (id, recipient_id, type, message, related_project_id, is_read, created_at)
      VALUES ($1, $2, $3, $4, $5, false, NOW())
      RETURNING 
        id, 
        recipient_id AS "recipientId", 
        type, 
        message, 
        related_project_id AS "relatedProjectId",
        is_read AS "isRead",
        created_at AS "createdAt";
    `;
    const values = [newNotificationId, recipientId, type, message, projectId || null];

    // Gunakan dbClient jika ada (untuk transaksi), jika tidak gunakan koneksi default
    const executor = dbClient || db;

    try {
      const { rows } = await executor.query(queryText, values);
      return rows[0];
    } catch (error) {
      // Log error dengan konteks yang jelas
      console.error('Error in Notification.create:', error.message);
      // Lempar kembali error agar bisa ditangani oleh pemanggil (misal, di webhookController)
      throw error;
    }
  },

  /**
   * Menemukan semua notifikasi untuk seorang penerima.
   * Query ini menggunakan LEFT JOIN, yang aman bahkan jika proyek terkait tidak ada (NULL).
   * @param {string} recipientId - ID pengguna yang notifikasinya dicari.
   */
  async findByRecipientId(recipientId) {
    const queryText = `
      SELECT 
        n.id,
        n.recipient_id AS "recipientId",
        n.type,
        n.message,
        n.related_project_id AS "relatedProjectId",
        n.is_read AS "isRead",
        n.created_at AS "createdAt",
        p.title AS "projectTitle"
      FROM notifications n
      LEFT JOIN projects p ON n.related_project_id = p.id
      WHERE n.recipient_id = $1
      ORDER BY n.created_at DESC;
    `;
    try {
      const { rows } = await db.query(queryText, [recipientId]);
      return rows;
    } catch (error) {
      console.error(`Error in Notification.findByRecipientId for user ${recipientId}:`, error.message);
      throw error;
    }
  },

  /**
   * Menandai satu notifikasi sebagai sudah dibaca.
   * @param {string} notificationId - ID notifikasi yang akan diupdate.
   * @param {string} userId - ID user yang meminta, untuk otorisasi.
   */
  async markAsRead(notificationId, userId) {
    const queryText = `
      UPDATE notifications
      SET is_read = true
      WHERE id = $1 AND recipient_id = $2
      RETURNING *;
    `;
    try {
      const { rows } = await db.query(queryText, [notificationId, userId]);
      return rows[0];
    } catch (error) {
      console.error(`Error marking notification ${notificationId} as read:`, error.message);
      throw error;
    }
  },

  /**
   * Menandai semua notifikasi yang belum dibaca sebagai sudah dibaca untuk seorang user.
   * @param {string} recipientId - ID pengguna yang notifikasinya akan diupdate.
   */
  async markAllAsRead(recipientId) {
    const queryText = `
      UPDATE notifications
      SET is_read = true
      WHERE recipient_id = $1 AND is_read = false
      RETURNING id;
    `;
    try {
      const { rows } = await db.query(queryText, [recipientId]);
      return { success: true, updatedCount: rows.length };
    } catch (error) {
      console.error(`Error marking all notifications as read for user ${recipientId}:`, error.message);
      throw error;
    }
  }
};

export default Notification;