// backend/src/models/Payment.js
import db from '../db/index.js';
import { v4 as uuidv4 } from 'uuid';

const Payment = {
    async create({ projectId, proposalId, clientId, expertId, amount, currency }) {
        const id = uuidv4();
        const queryText = `
            INSERT INTO payments 
                (id, project_id, proposal_id, client_id, expert_id, amount, currency, status)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            RETURNING id, project_id AS "projectId", amount, status;
        `;
        // Status is 'pending' until the webhook confirms payment
        const values = [id, projectId, proposalId, clientId, expertId, amount, currency, 'pending'];

        try {
            const { rows } = await db.query(queryText, values);
            return rows[0];
        } catch (err) {
            console.error('Error creating pending payment in DB:', err.stack);
            throw err;
        }
    },

    // ===============================================
    // === FUNGSI BARU DITAMBAHKAN DI SINI ===
    // ===============================================
    /**
     * Menemukan pembayaran yang berhasil berdasarkan ID Proyek.
     * @param {string} projectId - ID proyek yang terkait.
     * @returns {Promise<Object|undefined>} Pembayaran yang ditemukan atau undefined.
     */
    async findByProjectId(projectId) {
        const queryText = `
            SELECT 
                id,
                project_id AS "projectId",
                client_id AS "clientId",
                expert_id AS "expertId",
                amount,
                currency,
                status,
                payment_date AS "paymentDate"
            FROM payments
            WHERE project_id = $1 AND status = 'success'
            ORDER BY payment_date DESC
            LIMIT 1;
        `;
        // Kita hanya mengambil pembayaran 'success' yang paling baru untuk proyek ini
        
        try {
            const { rows } = await db.query(queryText, [projectId]);
            return rows[0];
        } catch (err) {
            console.error(`Error finding payment by project ID ${projectId}:`, err.stack);
            throw err;
        }
    }
};

export default Payment;