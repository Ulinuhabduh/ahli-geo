// backend/src/models/Payout.js
import db from '../db/index.js';
import { v4 as uuidv4 } from 'uuid';

const Payout = {
    /**
     * Membuat catatan payout baru dengan status 'pending'.
     * @param {object} data - { projectId, expertId, payoutAccountId, amount, platformFee }
     * @returns {Promise<Object>} Catatan payout yang baru dibuat.
     */
    async create({ projectId, expertId, payoutAccountId, amount, platformFee }) {
        const id = uuidv4();
        const queryText = `
            INSERT INTO payouts
                (id, project_id, expert_id, payout_account_id, amount, platform_fee, status)
            VALUES ($1, $2, $3, $4, $5, $6, 'pending')
            RETURNING *;
        `;
        const values = [id, projectId, expertId, payoutAccountId, amount, platformFee];

        try {
            const { rows } = await db.query(queryText, values);
            return rows[0];
        } catch (err) {
            console.error('Error creating payout record:', err.stack);
            throw err;
        }
    },

    /**
     * Memperbarui status catatan payout, biasanya setelah mendapatkan respons dari API IRIS atau webhook.
     * @param {string} payoutId - ID dari catatan payout yang akan diupdate.
     * @param {string} newStatus - Status baru ('processing', 'completed', 'failed').
     * @param {string|null} irisReferenceNo - Nomor referensi dari IRIS.
     * @param {string|null} errorMessage - Pesan error jika statusnya 'failed'.
     * @returns {Promise<Object>} Catatan payout yang sudah diupdate.
     */
    async updateStatus(payoutId, newStatus, irisReferenceNo = null, errorMessage = null) {
        const queryText = `
            UPDATE payouts
            SET 
                status = $2,
                iris_reference_no = $3,
                error_message = $4,
                completed_at = CASE WHEN $2 = 'completed' THEN NOW() ELSE completed_at END
            WHERE id = $1
            RETURNING *;
        `;
        // Logika CASE WHEN akan mengisi `completed_at` hanya jika statusnya 'completed'
        
        const values = [payoutId, newStatus, irisReferenceNo, errorMessage];

        try {
            const { rows } = await db.query(queryText, values);
            return rows[0];
        } catch (err) {
            console.error(`Error updating payout status for ID ${payoutId}:`, err.stack);
            throw err;
        }
    }
};

export default Payout;