import db from '../db/index.js';
import { v4 as uuidv4 } from 'uuid';
// Generated code
const ChatSession = {
    async findOrCreateSession(currentUserId, targetType, targetId, targetName) {
        // Attempt to find an existing session between the current user and the target (expert or project specific participant)
        // This logic might need refinement depending on how participants are structured for project chats.
        // For expert chats, it's between currentUserId and targetId (expertId).
        // For project chats, it might be between currentUserId and project owner, or all participants.
        // Let's simplify: find a session where currentUserId is a participant AND targetId/targetType match.

        const findQuery = `
        SELECT cs.* 
        FROM chat_sessions cs
        JOIN chat_session_participants csp1 ON cs.id = csp1.session_id
        WHERE cs.target_type = $1 AND cs.target_id = $2 AND csp1.user_id = $3
        LIMIT 1;
    `;
        // This query assumes one-on-one expert chat or user joining a specific project chat context.
        // A more robust find for project chat might involve checking if *both* users are participants.
        // For now, if target is project, we assume targetId is project's ID and session is for that project.

        try {
            const { rows: existingSessions } = await db.query(findQuery, [targetType, targetId, currentUserId]);

            if (existingSessions.length > 0) {
                return existingSessions[0];
            }

            // If no session found, create a new one
            const newSessionId = uuidv4();
            const createSessionQuery = `
            INSERT INTO chat_sessions (id, target_type, target_id, target_name, last_message_timestamp)
            VALUES ($1, $2, $3, $4, NOW())
            RETURNING *;
        `;
            const { rows: newSessionRows } = await db.query(createSessionQuery, [newSessionId, targetType, targetId, targetName]);
            const newSession = newSessionRows[0];

            // Add participants
            // For expert chat: currentUserId and targetId (expertId)
            // For project chat: currentUserId (and potentially project owner if not current user, or all project members later)
            await db.query(
                'INSERT INTO chat_session_participants (session_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
                [newSession.id, currentUserId]
            );
            if (targetType === 'expert' && currentUserId !== targetId) { // Ensure expert is also a participant
                await db.query(
                    'INSERT INTO chat_session_participants (session_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
                    [newSession.id, targetId]
                );
            }
            // For project chats, you might need to add the project owner or other relevant parties.
            // This part is simplified for now.

            return newSession;
        } catch (err) {
            console.error('Error finding or creating chat session:', err.message, err.stack);
            throw err;
        }
    },

    async getSessionByIdWithMessages(sessionId) {
        const sessionQuery = 'SELECT * FROM chat_sessions WHERE id = $1;';
        const messagesQuery = `
        SELECT * FROM chat_messages 
        WHERE session_id = $1 
        ORDER BY timestamp ASC;
    `;
        try {
            const { rows: sessionRows } = await db.query(sessionQuery, [sessionId]);
            if (sessionRows.length === 0) return null;

            const session = sessionRows[0];
            const { rows: messages } = await db.query(messagesQuery, [sessionId]);
            session.messages = messages || []; // Attach messages to the session object
            return session;
        } catch (err) {
            console.error('Error getting session by ID with messages:', err.message, err.stack);
            throw err;
        }
    },

    async updateLastMessageTimestamp(sessionId) {
        const queryText = 'UPDATE chat_sessions SET last_message_timestamp = NOW() WHERE id = $1;';
        try {
            await db.query(queryText, [sessionId]);
        } catch (err) {
            console.error('Error updating last message timestamp:', err.message, err.stack);
            // Non-critical, so don't throw, just log
        }
    }
};
export default ChatSession;