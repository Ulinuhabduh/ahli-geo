// src/config/index.js
import dotenv from 'dotenv'; // Assuming dotenv is installed and supports ESM or you have a CJS interop strategy

dotenv.config();

const config = {
    port: process.env.PORT || 3001,
    databaseUrl: process.env.DATABASE_URL,
    jwtSecret: process.env.JWT_SECRET,
    jwtExpiresIn: process.env.JWT_EXPIRES_IN,
    nodeEnv: process.env.NODE_ENV || 'development',
};

export default config; // Use default export