// backend/src/config/midtrans.js
import midtransClient from 'midtrans-client';
import dotenv from 'dotenv';
dotenv.config();

// Klien untuk Midtrans Snap (yang sudah Anda gunakan untuk pembayaran)
export const snap = new midtransClient.Snap({
    isProduction: false,
    serverKey: process.env.MIDTRANS_SERVER_KEY,
    clientKey: process.env.MIDTRANS_CLIENT_KEY
});

// Klien BARU untuk Midtrans IRIS (Payout)
// Pastikan Anda sudah mendapatkan IRIS API Key dari dashboard Midtrans Anda
export const iris = new midtransClient.Iris({
    isProduction: false,
    serverKey: process.env.IRIS_API_KEY 
});