// backend/src/services/midtransService.js

import midtransClient from 'midtrans-client';

// Inisialisasi Midtrans Snap API.
// Konfigurasi ini akan dibaca sekali saat aplikasi dimulai.
const snap = new midtransClient.Snap({
    isProduction: process.env.NODE_ENV === 'production', // Otomatis berdasarkan environment Node.js
    serverKey: process.env.MIDTRANS_SERVER_KEY,
    clientKey: process.env.MIDTRANS_CLIENT_KEY
});

/**
 * Membuat transaksi Midtrans.
 * @param {string} paymentId - ID unik dari tabel 'payments' Anda. Digunakan sebagai order_id.
 * @param {number} amount - Jumlah kotor untuk transaksi.
 * @param {object} clientDetails - Informasi klien { name, email }.
 * @param {object} projectDetails - Informasi proyek { id, title }.
 * @returns {Promise<string>} - Token transaksi dari Midtrans untuk digunakan di frontend.
 */
export const createMidtransTransaction = async (paymentId, amount, clientDetails, projectDetails) => {

    // 1. Definisikan item_details terlebih dahulu untuk memastikan konsistensi.
    const itemDetails = [{
        id: projectDetails.id,
        price: Math.round(amount), // Pastikan harga adalah integer.
        quantity: 1,
        // Potong nama item agar tidak lebih dari 50 karakter untuk menghindari error.
        name: projectDetails.title.substring(0, 50),
        category: 'Geoscience Services',
        merchant_name: 'AhliGeo'
    }];

    // 2. Hitung gross_amount SECARA LANGSUNG dari item_details.
    // Ini adalah cara paling aman untuk memastikan totalnya selalu cocok.
    const grossAmount = itemDetails.reduce((total, item) => total + (item.price * item.quantity), 0);

    // 3. Susun parameter lengkap yang akan dikirim ke Midtrans.
    const parameter = {
        transaction_details: {
            order_id: paymentId,
            gross_amount: grossAmount, // Gunakan hasil perhitungan yang pasti benar.
        },
        item_details: itemDetails,
        customer_details: {
            first_name: clientDetails.name,
            email: clientDetails.email,
        },
        callbacks: {
            // Pastikan Anda sudah menambahkan FRONTEND_URL di file .env backend.
            finish: `${process.env.FRONTEND_URL}/#/my-projects`
        }
    };

    try {
        // 4. Kirim permintaan pembuatan transaksi ke Midtrans.
        const transaction = await snap.createTransaction(parameter);

        console.log("Successfully created Midtrans transaction. Token:", transaction.token);
        return transaction.token;

    } catch (error) {
        // 5. Tangani error dengan logging yang detail untuk kemudahan debugging.
        console.error('====================================================');
        console.error('MIDTRANS TRANSACTION CREATION FAILED');
        console.error('====================================================');
        console.error('Parameters Sent to Midtrans:', JSON.stringify(parameter, null, 2));

        // 'error.ApiResponse' berisi respons mentah dari server Midtrans yang paling informatif.
        console.error('\nError Details from Midtrans SDK:', error.ApiResponse || error);
        console.error('====================================================');

        // Buat pesan error yang lebih berguna untuk ditampilkan atau dilempar.
        const errorMessages = error.ApiResponse?.error_messages;
        const errorMessage = Array.isArray(errorMessages)
            ? errorMessages.join(', ')
            : 'Failed to create payment transaction. Check backend logs for details.';

        throw new Error(errorMessage);
    }
};

// Ekspor sebagai objek jika Anda berencana menambahkan fungsi lain nanti
// (misalnya, verifyWebhookSignature, dll.)
export default {
    createMidtransTransaction
};