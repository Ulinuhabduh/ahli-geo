// backend/src/services/payoutService.js

import { iris } from '../config/midtrans.js';
import PayoutAccount from '../models/PayoutAccount.js';
import Payout from '../models/Payout.js';
import { v4 as uuidv4 } from 'uuid';

export const createPayoutForCompletedProject = async (project, payment) => {
    // 1. Dapatkan detail rekening bank expert (tidak berubah)
    const payoutAccount = await PayoutAccount.findByExpertId(project.assignedExpertId);
    if (!payoutAccount) {
        throw new Error(`Payout account for expert ${project.assignedExpertId} not found.`);
    }

    // 2. Hitung jumlah payout (tidak berubah)
    const totalAmount = parseFloat(payment.amount);
    const payoutAmount = totalAmount * 0.90;
    const platformFee = totalAmount * 0.10;

    // 3. Buat catatan payout di database kita (tidak berubah)
    const payoutRecord = await Payout.create({
        projectId: project.id,
        expertId: project.assignedExpertId,
        payoutAccountId: payoutAccount.id,
        amount: payoutAmount,
        platformFee: platformFee,
        status: 'pending'
    });

    // ==========================================================
    // === LOGIKA KONDISIONAL BERDASARKAN ENVIRONMENT ===
    // ==========================================================

    if (process.env.NODE_ENV === 'production') {
        // --- JALANKAN INI HANYA DI PRODUKSI ---
        console.log('PRODUCTION MODE: Calling IRIS API...');
        const parameter = {
            beneficiary_name: payoutAccount.accountHolderName,
            beneficiary_account: payoutAccount.accountNumber,
            beneficiary_bank: payoutAccount.bankName.toLowerCase(),
            amount: payoutAmount.toString(),
            notes: `Payout for project: ${project.title}`,
            reference_no: payoutRecord.id 
        };

        try {
            const irisResponse = await iris.createPayouts(parameter);
            console.log('IRIS Payout Response:', irisResponse);
            await Payout.updateStatus(payoutRecord.id, irisResponse.status, irisResponse.reference_no);
            return irisResponse;
        } catch (error) {
            const errorMessage = error.response ? error.response.body.error_messages.join(', ') : error.message;
            await Payout.updateStatus(payoutRecord.id, 'failed', null, errorMessage);
            console.error('IRIS Payout Error:', errorMessage);
            throw new Error(`Failed to create payout: ${errorMessage}`);
        }

    } else {
        // --- JALANKAN INI HANYA DI DEVELOPMENT/SANDBOX ---
        console.log('DEVELOPMENT MODE: Simulating successful payout.');
        
        // Langsung update status menjadi 'completed' untuk simulasi.
        // Di dunia nyata, status awal dari IRIS adalah 'queued'.
        // Kita set 'completed' agar bisa langsung tes notifikasi akhir.
        const simulatedReferenceNo = `SIM_${uuidv4()}`;
        await Payout.updateStatus(payoutRecord.id, 'completed', simulatedReferenceNo);
        
        console.log(`Payout ${payoutRecord.id} simulated as completed.`);
        return { 
            status: 'completed',
            reference_no: simulatedReferenceNo,
            message: 'Payout simulated successfully in development mode.' 
        };
    }
};