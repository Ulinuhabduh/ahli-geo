// src/db/index.js
import pg from 'pg'; // pg library needs to support ESM or use dynamic import/createRequire for CJS interop
const { Pool } = pg; // Destructure Pool if pg exports it this way in ESM
import config from '../config/index.js';

const pool = new Pool({
    connectionString: config.databaseUrl,
});

pool.on('connect', () => {
    console.log('Successfully connected to the PostgreSQL database!');
});

pool.on('error', (err, client) => {
    console.error('Unexpected error on idle PostgreSQL client', err);
    process.exit(-1);
});

const db = {
    query: (text, params) => pool.query(text, params),
    pool,
};

export default db; // Export the db object as default