import ExpertProfile from '../models/ExpertProfile.js';
import User from '../models/User.js';

// Generated code
export const getAllExperts = async (req, res, next) => {
    console.log("GetAllExperts endpoint hit. Query params:", req.query);
    try {
        const {
            limit,
            searchTerm,
            skills, // string or array
            software, // string or array
            minExperience,
            verified
        } = req.query;

        const filters = {
            limit: limit ? parseInt(limit, 10) : undefined,
            searchTerm: searchTerm?.toString(),
            selectedSkills: skills ? (Array.isArray(skills) ? skills : skills.toString().split(',')) : undefined,
            selectedSoftware: software ? (Array.isArray(software) ? software : software.toString().split(',')) : undefined,
            minExperience: minExperience ? parseInt(minExperience, 10) : undefined,
            showVerifiedOnly: verified === 'true' // Convert string 'true' to boolean
        };

        const experts = await ExpertProfile.findAll(filters);
        res.status(200).json(experts);
    } catch (error) {
        console.error("GetAllExperts controller error:", error.message, error.stack);
        next(error);
    }
};

export const getExpertById = async (req, res, next) => {
    console.log("GetExpertById endpoint hit. Expert ID:", req.params.expertId);
    try {
        const { expertId } = req.params;
        if (!expertId) {
            return res.status(400).json({ message: 'Expert ID is required.' });
        }
        const expert = await ExpertProfile.findById(expertId);
        if (!expert) {
            return res.status(404).json({ message: 'Expert not found' });
        }
        res.status(200).json(expert);
    } catch (error) {
        console.error("GetExpertById controller error:", error.message, error.stack);
        next(error);
    }
};

export const handleExpertProfileSetupData = async (userId, expertSpecificData) => {
    try {
        const transformItems = (items) => {
            if (!items || !Array.isArray(items)) return [];
            return items.map(item => (typeof item === 'string' ? { id: item } : item)).filter(item => item && item.id);
        };

        const profileDataForDb = {
            ...expertSpecificData,
            // Ensure skills and software are arrays of objects like { id: 's1' } or { id: 's1', name: '...' }
            // The ExpertProfile.createOrUpdate model only needs the 'id' for linking.
            skills: transformItems(expertSpecificData.skills),
            software: transformItems(expertSpecificData.software),
        };

        const updatedExpertProfile = await ExpertProfile.createOrUpdate(userId, profileDataForDb);
        return updatedExpertProfile;
    } catch (error) {
        console.error("Error in handleExpertProfileSetupData (expertController):", error.message, error.stack);
        throw error;
    }
};

export const updateMyProfile = async (req, res, next) => {
    try {
        const userId = req.user.userId;
        const { name, ...expertSpecificData } = req.body;

        if (name && name !== req.user.name) {
            await User.updateById(userId, { name });
        }

        const profileDataForDb = {
            headline: expertSpecificData.headline,
            location: expertSpecificData.location,
            experience_years: expertSpecificData.experienceYears,
            profile_image_url: expertSpecificData.profileImageUrl,
            bio: expertSpecificData.bio,
            hourly_rate: expertSpecificData.hourlyRate,
            // Model mengharapkan array objek { id: '...' }
            skills: expertSpecificData.skillIds?.map(id => ({ id })) || [],
            software: expertSpecificData.softwareIds?.map(id => ({ id })) || [],
        };

        await ExpertProfile.createOrUpdate(userId, profileDataForDb);

        const updatedExpert = await ExpertProfile.findById(userId);

        res.status(200).json(updatedExpert); // Kirim kembali data yang sudah di-update
    } catch (error) {
        console.error("[UpdateMyProfile Controller Error]:", error);
        next(error);
    }
};