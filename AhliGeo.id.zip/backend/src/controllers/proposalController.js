// src/controllers/proposalController.js
import Proposal from '../models/Proposal.js';
import Project from '../models/Project.js';

// Hanya ada SATU fungsi createProposal
export const createProposal = async (req, res, next) => {
    try {
        const { projectId, coverLetter, proposedRate } = req.body;
        const expert = req.user; // Dapatkan seluruh info expert dari token

        const project = await Project.findById(projectId);
        if (!project || project.status !== 'Open') { /* ... */ }

        // Teruskan info yang dibutuhkan untuk membuat notifikasi
        const newProposal = await Proposal.create({
            projectId,
            expertId: expert.userId,
            coverLetter,
            proposedRate,
            expertName: expert.name, // Nama expert yang submit
            clientOwnerId: project.clientId // ID client pemilik proyek
        });

        res.status(201).json(newProposal);
    } catch (error) { /* ... */ }
};

export const checkExpertApplication = async (req, res, next) => {
    try {
        const { projectId } = req.params;
        const expertId = req.user.userId;

        const existingProposal = await Proposal.findByProjectAndExpert(projectId, expertId);

        // Kirim respons boolean
        res.status(200).json({ hasApplied: !!existingProposal });

    } catch (error) {
        console.error("CheckExpertApplication controller error:", error);
        next(error);
    }
};

export const getMyProposals = async (req, res, next) => {
    try {
        // Ambil ID expert dari token, bukan dari params, agar lebih aman
        const expertId = req.user.userId;
        const proposals = await Proposal.findByExpertId(expertId);
        res.status(200).json(proposals);
    } catch (error) {
        console.error("GetMyProposals controller error:", error);
        next(error);
    }
};

export const getProposalsForProject = async (req, res, next) => {
    try {
        const { projectId } = req.params;
        const project = await Project.findById(projectId);

        if (!project) {
            return res.status(404).json({ message: "Project not found." });
        }

        // GUNAKAN 'clientId' (camelCase) karena model Project kita mengembalikannya seperti itu
        if (req.user.role !== 'admin' && req.user.userId !== project.clientId) {
            return res.status(403).json({ message: "Not authorized to view proposals for this project." });
        }

        const proposals = await Proposal.findByProjectId(projectId);
        res.status(200).json(proposals);
    } catch (error) {
        console.error("GetProposalsForProject controller error:", error);
        next(error);
    }
};

// export const acceptProposal = async (req, res, next) => {
//     try {
//         const { proposalId } = req.params;
//         const { projectId, expertId } = req.body;
//         const project = await Project.findById(projectId);

//         if (!project) {
//             return res.status(404).json({ message: 'Project not found.' });
//         }
//         // GUNAKAN 'clientId' (camelCase)
//         if (project.clientId !== req.user.userId) {
//             return res.status(403).json({ message: 'Not authorized to accept proposals for this project.' });
//         }
//         if (project.status !== 'Open') {
//             return res.status(400).json({ message: 'This project is not in a state to accept proposals.' });
//         }

//         const result = await Proposal.accept(proposalId, projectId, expertId);
//         res.status(200).json(result);
//     } catch (error) {
//         console.error("AcceptProposal controller error:", error);
//         next(error);
//     }
// };