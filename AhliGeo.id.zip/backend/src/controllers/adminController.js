// backend/src/controllers/adminController.js
import User from '../models/User.js'; // Kita mungkin perlu membuat model User jika belum ada
import Project from '../models/Project.js';
import db from '../db/index.js'
import Notification from '../models/Notification.js';

// @desc    Get all users (for admin)
// @route   GET /api/admin/users
// @access  Admin
export const getAllUsers = async (req, res, next) => {
    try {
        // Anda perlu membuat fungsi User.findAllForAdmin() di model User Anda
        const users = await User.findAllForAdmin();
        res.status(200).json(users);
    } catch (error) {
        next(error);
    }
};

// @desc    Update a user (e.g., change role, verify)
// @route   PUT /api/admin/users/:id
// @access  Admin
export const updateUserById = async (req, res, next) => {
    try {
        const { id } = req.params;
        const updatedData = req.body; // e.g., { role: 'expert', profileSetupCompleted: true }
        // Anda perlu membuat fungsi User.updateById(id, data)
        const updatedUser = await User.updateById(id, updatedData);
        res.status(200).json(updatedUser);
    } catch (error) {
        next(error);
    }
};

// @desc    Delete a user
// @route   DELETE /api/admin/users/:id
// @access  Admin
export const deleteUserById = async (req, res, next) => {
    try {
        const { id } = req.params;
        // PANGGIL FUNGSI BARU KITA
        const deletedUser = await User.softDeleteById(id);

        // Pesan sukses yang lebih sesuai
        res.status(200).json({ message: `User ${deletedUser.name} has been deactivated successfully.` });
    } catch (error) {
        // Karena kita tidak lagi melakukan hard delete, error foreign key tidak akan terjadi.
        // Kita hanya perlu menangani kasus jika user tidak ditemukan.
        // Fungsi model kita sudah melempar error ini, jadi kita bisa langsung kirim ke error handler.
        next(error);
    }
};

export const restoreUserById = async (req, res, next) => {
    try {
        const { id } = req.params;
        const restoredUser = await User.restoreById(id);
        res.status(200).json({
            message: `User ${restoredUser.name} has been restored successfully.`,
            user: restoredUser // Kirim kembali data user yang sudah direstore
        });
    } catch (error) {
        next(error);
    }
};

export const getAllProjectsForAdmin = async (req, res, next) => {
    try {
        // Ambil filter dari query string
        const { status, searchTerm } = req.query;

        const projects = await Project.findAllForAdmin({ status, searchTerm });
        res.status(200).json(projects);
    } catch (error) {
        next(error);
    }
};

export const updateProjectStatus = async (req, res, next) => {
    try {
        const { id } = req.params;
        const { status } = req.body;

        if (!status) {
            return res.status(400).json({ message: 'Status is required.' });
        }

        const updatedProject = await Project.updateStatusById(id, status);
        res.status(200).json(updatedProject);
    } catch (error) {
        next(error);
    }
};

export const getExpertList = async (req, res, next) => {
    try {
        // Kita bisa buat fungsi spesifik di model, atau query langsung di sini untuk kesederhanaan.
        const { rows } = await db.query(
            "SELECT id, name FROM users WHERE role = 'expert' AND deleted_at IS NULL ORDER BY name ASC"
        );
        res.status(200).json(rows);
    } catch (error) {
        next(error);
    }
};

// @desc    Re-assign an expert to a project
// @route   PUT /api/admin/projects/:id/reassign
// @access  Admin
export const reassignProjectExpert = async (req, res, next) => {
    try {
        const { id: projectId } = req.params;
        const { newExpertId } = req.body;
        const adminWhoReassigned = req.user.name; // Ambil nama admin yang login

        if (!newExpertId) {
            return res.status(400).json({ message: 'New expert ID is required.' });
        }

        // --- Langkah 1: Dapatkan data proyek SEBELUM diubah ---
        // Kita butuh ID expert lama dan ID client
        const projectBeforeUpdate = await Project.findById(projectId);
        if (!projectBeforeUpdate) {
            return res.status(404).json({ message: 'Project not found.' });
        }
        const oldExpertId = projectBeforeUpdate.assignedExpertId;
        const clientId = projectBeforeUpdate.clientId;
        const projectTitle = projectBeforeUpdate.title;


        // --- Langkah 2: Lakukan Re-assignment ---
        await Project.reassignExpertById(projectId, newExpertId);


        // --- Langkah 3: Buat Notifikasi ---

        // a. Notifikasi untuk Expert Baru
        await Notification.create({
            recipientId: newExpertId,
            type: 'PROJECT_ASSIGNED',
            message: `You have been assigned to the project "${projectTitle}" by an administrator. You can now start working.`,
            projectId: projectId,
        });

        // b. Notifikasi untuk Expert Lama (jika ada)
        if (oldExpertId) {
            await Notification.create({
                recipientId: oldExpertId,
                type: 'PROJECT_REASSIGNED',
                message: `You have been un-assigned from the project "${projectTitle}" by an administrator.`,
                projectId: projectId,
            });
        }

        // c. Notifikasi untuk Client
        await Notification.create({
            recipientId: clientId,
            type: 'EXPERT_CHANGED',
            message: `The expert for your project "${projectTitle}" has been changed by an administrator. Please review the project details.`,
            projectId: projectId,
        });


        // --- Langkah 4: Kirim Respons Sukses ---
        const updatedProjectData = await Project.findAllForAdmin({ projectId: projectId });
        res.status(200).json({
            message: 'Expert has been re-assigned successfully and all parties have been notified.',
            project: updatedProjectData
        });

    } catch (error) {
        next(error);
    }
};