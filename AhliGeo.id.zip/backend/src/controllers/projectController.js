import Project from '../models/Project.js';
import { sendEmail } from '../utils/emailUtils.js';
import Payment from '../models/Payment.js'; // Model untuk mengambil info pembayaran
import { createPayoutForCompletedProject } from '../services/payoutService.js';
// import { v4 as uuidv4 } from 'uuid'; // uuid is used in model, not directly here

export const getAllProjects = async (req, res, next) => {
    console.log("GetAllProjects endpoint hit. Query params:", req.query);
    try {
        const {
            limit,
            clientId,
            status,
            searchTerm,
            skills,
            software,
            locationType
        } = req.query;

        const filters = {
            limit: limit ? parseInt(limit, 10) : undefined,
            clientId: clientId?.toString(),
            status: status?.toString(),
            searchTerm: searchTerm?.toString(),
            selectedSkills: skills ? (Array.isArray(skills) ? skills : skills.toString().split(',')) : undefined,
            selectedSoftware: software ? (Array.isArray(software) ? software : software.toString().split(',')) : undefined,
            locationType: locationType?.toString()
        };

        const projects = await Project.findAll(filters); // Asumsi Project.findAll sudah benar

        // ===== INI PERBAIKAN KRUSIAL =====
        // Bahkan jika 'projects' adalah undefined atau null dari model,
        // selalu kirim array kosong sebagai respons JSON.
        res.status(200).json(projects || []);

    } catch (error) {
        console.error("GetAllProjects controller error:", error.message, error.stack);
        next(error);
    }
};

export const getProjectById = async (req, res, next) => {
    console.log("GetProjectById endpoint hit. Project ID:", req.params.projectId);
    try {
        const { projectId } = req.params;
        if (!projectId) {
            return res.status(400).json({ message: 'Project ID is required.' });
        }
        const project = await Project.findById(projectId);
        if (!project) {
            return res.status(404).json({ message: 'Project not found' });
        }
        res.status(200).json(project);
    } catch (error) {
        console.error("GetProjectById controller error:", error.message, error.stack);
        next(error);
    }
};

// Di dalam file: backend/src/controllers/projectController.js
// ... (setelah fungsi 'updateProject')

export const submitDelivery = async (req, res, next) => {
    try {
        const { projectId } = req.params;
        const expertId = req.user.userId;

        // Validasi: pastikan expert yang login adalah expert yang ditugaskan
        if (req.user.role !== 'expert') {
            return res.status(403).json({ message: 'Only experts can submit work.' });
        }

        // Body request berisi: { deliveryText: "...", deliveryAttachments: [...] }
        const deliveryData = req.body;
        if (!deliveryData.deliveryText) {
            return res.status(400).json({ message: 'Delivery description is required.' });
        }

        const updatedProject = await Project.submitDelivery(projectId, expertId, deliveryData);

        // TODO: Buat notifikasi untuk client bahwa pekerjaan telah diserahkan.

        res.status(200).json(updatedProject);
    } catch (error) {
        next(error);
    }
};

export const completeProject = async (req, res, next) => {
    try {
        const { projectId } = req.params;
        const clientId = req.user.userId;

        // 1. Selesaikan proyek di database kita
        const completedProject = await Project.complete(projectId, clientId);
        if (!completedProject) {
            throw new Error('Project could not be completed.');
        }

        // 2. Ambil detail pembayaran terkait proyek ini
        const payment = await Payment.findByProjectId(projectId); // Anda perlu buat fungsi ini
        if (!payment || payment.status !== 'success') {
             throw new Error('Valid payment for this project not found.');
        }

        // --- INI BAGIAN BARU ---
        // 3. Trigger proses payout
        await createPayoutForCompletedProject(completedProject, payment);
        // -----------------------

        // 4. Kirim notifikasi ke expert
        await Notification.create({
            recipientId: completedProject.assignedExpertId,
            type: 'PROJECT_COMPLETED',
            message: `The project "${completedProject.title}" has been marked as complete by the client. Your payment is being processed.`,
            projectId: projectId,
        });

        res.status(200).json(completedProject);
    } catch (error) {
        next(error);
    }
};

export const createProject = async (req, res, next) => {
    console.log("CreateProject endpoint hit. Request body:", req.body);
    console.log("User from token:", req.user); // Check what req.user contains
    try {
        if (!req.user || !req.user.userId) {
            return res.status(401).json({ message: 'User not authenticated to create project.' });
        }
        if (req.user.role !== 'client') {
            return res.status(403).json({ message: 'Only clients can post projects.' });
        }

        const projectDataFromRequest = req.body;
        // Make sure requiredSkills and requiredSoftware are arrays of objects with an id property
        const transformSkillsOrSoftware = (items) => {
            if (!items || !Array.isArray(items)) return [];
            return items.map(item => (typeof item === 'string' ? { id: item } : item)).filter(item => item && item.id);
        };

        const projectDataForModel = {
            ...projectDataFromRequest,
            client_id: req.user.userId,
            client_name: req.user.name || projectDataFromRequest.clientName,
            required_skills: transformSkillsOrSoftware(projectDataFromRequest.requiredSkills),
            required_software: transformSkillsOrSoftware(projectDataFromRequest.requiredSoftware),
        };

        if (!projectDataForModel.title || !projectDataForModel.description) {
            return res.status(400).json({ message: 'Title and description are required for the project.' });
        }

        const newProject = await Project.create(projectDataForModel);
        res.status(201).json(newProject);
    } catch (error) {
        console.error("CreateProject controller error:", error.message, error.stack);
        next(error);
    }
};

export const updateProject = async (req, res, next) => {
    const { projectId } = req.params;
    const projectData = req.body;

    try {
        // Keamanan: Pastikan proyek ada sebelum update
        const existingProject = await Project.findById(projectId);
        if (!existingProject) {
            return res.status(404).json({ message: 'Project not found.' });
        }

        // Keamanan: Pastikan user yang mengupdate adalah pemilik proyek
        if (existingProject.clientId !== req.user.userId) {
            return res.status(403).json({ message: 'User not authorized to update this project.' });
        }

        const updatedProject = await Project.update(projectId, projectData);
        res.status(200).json(updatedProject);

    } catch (error) {
        console.error("UpdateProject controller error:", error.message);
        next(error);
    }
};

export const inviteExpert = async (req, res, next) => {
    try {
        const { expertId, projectId } = req.body;

        // Fetch project and expert details (assuming you have these models)
        const project = await Project.findById(projectId);
        const expert = await User.findById(expertId);

        if (!project || !expert) {
            return res.status(404).json({ message: 'Project or Expert not found.' });
        }

        // Send email to the expert
        const emailSubject = `Invitation to Join Project: ${project.title}`;
        const emailBody = `
            <p>Dear ${expert.name},</p>
            <p>You have been invited to join the project <strong>${project.title}</strong>.</p>
            <p>Please log in to your account to view more details.</p>
            <p><a href="https://your-frontend-url.com/projects/${projectId}">View Project</a></p>
        `;

        await sendEmail(expert.email, emailSubject, emailBody);

        res.status(200).json({ message: 'Invitation sent successfully!' });
    } catch (error) {
        next(error);
    }
};