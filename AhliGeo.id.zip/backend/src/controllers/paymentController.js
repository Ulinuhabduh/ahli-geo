// src/controllers/paymentController.js
import Payment from '../models/Payment.js';
import Project from '../models/Project.js'; // To get project details
import Proposal from '../models/Proposal.js';
import { createMidtransTransaction } from '../services/midtransService.js';

export const processPayment = async (req, res, next) => {
    console.log("ProcessPayment endpoint hit. Request body:", req.body);
    console.log("User from token:", req.user);
    try {
        if (!req.user || req.user.role !== 'client') {
            return res.status(403).json({ message: 'Only clients can make payments.' });
        }

        const { projectId, amount, currency, paymentMethod } = req.body;
        const clientId = req.user.userId;

        if (!projectId || !amount || !currency || !paymentMethod) {
            return res.status(400).json({ message: 'Project ID, amount, currency, and payment method are required.' });
        }

        const project = await Project.findById(projectId);
        if (!project) {
            return res.status(404).json({ message: "Project not found for payment." });
        }
        if (project.client_id !== clientId) {
            return res.status(403).json({ message: "You are not authorized to make payments for this project." });
        }
        // Further checks: e.g., ensure project status allows payment, amount matches expected, etc.

        const newPayment = await Payment.create({
            project_id: projectId,
            client_id: clientId,
            expert_id: project.assigned_expert_id, // Assuming payment goes to assigned expert if any
            amount: parseFloat(amount),
            currency: currency,
            payment_method: paymentMethod,
        });

        // Optionally, update project status after payment (e.g., to 'In Progress' or 'Completed')
        // await Project.updateStatus(projectId, 'In Progress'); 

        res.status(201).json(newPayment);
    } catch (error) {
        console.error("ProcessPayment controller error:", error.message, error.stack);
        next(error);
    }
};

export const createPaymentForProposal = async (req, res, next) => {
    try {
        const { proposalId } = req.params;
        const clientId = req.user.userId;

        // 1. Ambil detail proposal dan proyek untuk validasi
        const proposal = await Proposal.findById(proposalId);
        if (!proposal) {
            return res.status(404).json({ message: 'Proposal not found.' });
        }

        const project = await Project.findById(proposal.projectId);
        if (!project) {
            return res.status(404).json({ message: 'Project not found.' });
        }

        // 2. Validasi Keamanan
        if (project.clientId !== clientId) {
            return res.status(403).json({ message: 'You are not authorized to accept proposals for this project.' });
        }
        if (project.status !== 'Open') {
            return res.status(400).json({ message: 'This project is not open for new proposals.' });
        }

        // 3. Buat record pembayaran 'pending' di database kita
        const newPayment = await Payment.create({
            projectId: project.id,
            proposalId: proposal.id,
            clientId: project.clientId,
            expertId: proposal.expertId,
            amount: proposal.proposedRate,
            currency: project.currency,
        });

        // 4. Buat transaksi dengan Midtrans untuk mendapatkan token
        // SEKARANG 'createMidtransTransaction' sudah terdefinisi karena diimpor di atas
        const transactionToken = await createMidtransTransaction(
            newPayment.id,
            proposal.proposedRate,
            { name: req.user.name, email: req.user.email },
            { id: project.id, title: project.title }
        );

        // 5. Kirim token kembali ke frontend
        res.status(201).json({
            message: 'Payment transaction initiated.',
            paymentId: newPayment.id,
            transactionToken,
        });

    } catch (error) {
        console.error("createPaymentForProposal controller error:", error);
        next(error);
    }
};