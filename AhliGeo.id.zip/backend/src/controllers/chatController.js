// src/controllers/chatController.js
import Chat from '../models/Chat.js';

// Memulai atau mengambil sesi chat yang sudah ada
export const initiateChatSession = async (req, res, next) => {
    try {
        const senderId = req.user.userId;
        const { recipientId } = req.body;

        if (!recipientId || senderId === recipientId) {
            return res.status(400).json({ message: 'Valid recipient ID is required.' });
        }

        let sessionId = await Chat.findExistingSession(senderId, recipientId);

        if (!sessionId) {
            sessionId = await Chat.createSession(senderId, recipientId);
        }

        res.status(200).json({ sessionId });
    } catch (error) {
        next(error);
    }
};

// Mengambil semua sesi chat pengguna (inbox)
export const getUserSessions = async (req, res, next) => {
    try {
        const userId = req.user.userId;
        const sessions = await Chat.getSessionsForUser(userId);
        res.status(200).json(sessions);
    } catch (error) {
        next(error);
    }
};

// Mengambil pesan untuk satu sesi
export const getSessionMessages = async (req, res, next) => {
    try {
        const { sessionId } = req.params;
        // Di aplikasi nyata, tambahkan validasi untuk memastikan user adalah partisipan
        const messages = await Chat.getMessagesForSession(sessionId);
        res.status(200).json(messages);
    } catch (error) {
        next(error);
    }
};

// Mengirim pesan baru
export const postNewMessage = async (req, res, next) => {
    try {
        const { sessionId } = req.params;
        const senderId = req.user.userId;
        const { messageText } = req.body;

        if (!messageText || !messageText.trim()) {
            return res.status(400).json({ message: 'Message text cannot be empty.' });
        }

        const newMessage = await Chat.createMessage(senderId, sessionId, messageText);
        res.status(201).json(newMessage);
    } catch (error) {
        next(error);
    }
};