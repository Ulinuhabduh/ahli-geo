// src/controllers/notificationController.js
import Notification from '../models/Notification.js';
import Project from '../models/Project.js';
import User from '../models/User.js'; // Asumsi Anda punya model User

// Controller untuk membuat undangan/invitasi
export const createInvitation = async (req, res, next) => {
    try {
        const { expertId, projectId } = req.body;
        const client = req.user; // User client yang sedang login

        const project = await Project.findById(projectId);
        const expert = await User.findById(expertId); // Dapatkan info expert

        if (!project || !expert) {
            return res.status(404).json({ message: 'Project or Expert not found.' });
        }
        // Keamanan: Pastikan client adalah pemilik proyek
        if (project.clientId !== client.userId) {
            return res.status(403).json({ message: 'You are not authorized to invite experts to this project.' });
        }

        const message = `${client.name} from ${client.companyName || 'their company'} has invited you to apply for the project "${project.title}".`;

        const notification = await Notification.create({
            recipientId: expertId,
            type: 'PROJECT_INVITATION',
            message,
            projectId,
        });

        res.status(201).json({ message: 'Invitation sent successfully!', notification });
    } catch (error) {
        next(error);
    }
};

// Controller untuk expert mengambil notifikasinya
export const getMyNotifications = async (req, res, next) => {
    try {
        const recipientId = req.user.userId;
        const notifications = await Notification.findByRecipientId(recipientId);
        res.status(200).json(notifications);
    } catch (error) {
        next(error);
    }
};