// backend/src/controllers/payoutController.js

import PayoutAccount from '../models/PayoutAccount.js';

/**
 * Mengambil detail akun payout untuk expert yang sedang login.
 */
export const getAccount = async (req, res, next) => {
    try {
        const expertId = req.user.userId; // Diambil dari middleware 'protect'
        const account = await PayoutAccount.findByExpertId(expertId);
        
        if (!account) {
            // Ini bukan error, ini adalah kondisi valid.
            // Expert belum mengatur rekeningnya.
            return res.status(404).json({ message: 'Payout account not found.' });
        }

        res.status(200).json(account);
    } catch (error) {
        next(error);
    }
};

/**
 * Menyimpan atau memperbarui detail akun payout untuk expert yang sedang login.
 */
export const saveAccount = async (req, res, next) => {
    try {
        const expertId = req.user.userId;
        const { bankName, accountHolderName, accountNumber } = req.body;

        if (!bankName || !accountHolderName || !accountNumber) {
            return res.status(400).json({ message: 'All fields are required.' });
        }

        const savedAccount = await PayoutAccount.upsert({
            expertId,
            bankName,
            accountHolderName,
            accountNumber,
        });

        res.status(200).json(savedAccount);
    } catch (error) {
        next(error);
    }
};