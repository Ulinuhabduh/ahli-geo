// backend/src/controllers/webhookController.js

import crypto from 'crypto';
import db from '../db/index.js'; // 'db' adalah objek { query, pool }
import Notification from '../models/Notification.js';

export const handleMidtransNotification = async (req, res) => {
    const notificationJson = req.body;
    // Definisikan 'client' di sini agar bisa diakses di blok 'finally'
    let client;

    try {
        // 1. Verifikasi Signature Midtrans
        const serverKey = process.env.MIDTRANS_SERVER_KEY;
        const signatureKey = crypto.createHash('sha512')
            .update(notificationJson.order_id + notificationJson.status_code + notificationJson.gross_amount + serverKey)
            .digest('hex');

        if (signatureKey !== notificationJson.signature_key) {
            console.warn(`Webhook signature mismatch for order_id: ${notificationJson.order_id}. Ignoring request.`);
            return res.status(403).json({ message: 'Forbidden: Invalid signature' });
        }

        // 2. Proses notifikasi jika signature valid
        const { order_id, transaction_status, fraud_status } = notificationJson;
        const paymentId = order_id;

        // Hanya proses transaksi yang sukses dan aman
        if ((transaction_status === 'capture' || transaction_status === 'settlement') && fraud_status === 'accept') {

            // =================================================================
            // === PERBAIKAN UTAMA: Dapatkan koneksi client dari db.pool ===
            // =================================================================
            client = await db.pool.connect();
            // =================================================================

            try {
                // MULAI TRANSAKSI DATABASE
                await client.query('BEGIN');

                // a. Update status pembayaran dari 'pending' ke 'success'
                const paymentUpdateResult = await client.query(
                    `UPDATE payments SET status = 'success', payment_date = NOW() WHERE id = $1 AND status = 'pending' RETURNING *`,
                    [paymentId]
                );

                // b. Idempotency Check: Jika tidak ada baris yang di-update, berarti sudah diproses.
                if (paymentUpdateResult.rowCount === 0) {
                    console.log(`Webhook for order_id: ${order_id} has already been processed. Ignoring duplicate.`);
                    await client.query('COMMIT'); // Selesaikan transaksi kosong
                    // Tetap kirim 200 OK ke Midtrans
                    return res.status(200).json({ message: 'Notification already processed.' });
                }

                // c. Ambil ID penting dari hasil update pembayaran
                const { project_id, proposal_id } = paymentUpdateResult.rows[0];

                // d. Ambil ID expert dari proposal yang diterima (lebih akurat)
                const proposalRes = await client.query('SELECT expert_id FROM proposals WHERE id = $1', [proposal_id]);
                if (proposalRes.rowCount === 0) throw new Error(`Proposal with ID ${proposal_id} not found.`);
                const expert_id = proposalRes.rows[0].expert_id;

                // e. Update status proyek dan tetapkan expert
                const projectUpdateResult = await client.query(
                    `UPDATE projects SET status = 'In Progress', assigned_expert_id = $1 WHERE id = $2 RETURNING title`,
                    [expert_id, project_id]
                );
                const projectTitle = projectUpdateResult.rows[0].title;

                // f. Update status semua proposal terkait
                await client.query(`UPDATE proposals SET status = 'Accepted' WHERE id = $1`, [proposal_id]);
                await client.query(`UPDATE proposals SET status = 'Rejected' WHERE project_id = $1 AND id != $2`, [project_id, proposal_id]);

                // g. Buat notifikasi untuk Expert
                const notificationMessage = `Congratulations! Your proposal for the project "${projectTitle}" has been accepted. You can start working now.`;
                await Notification.create({
                    recipientId: expert_id,
                    type: 'PROPOSAL_ACCEPTED',
                    message: notificationMessage,
                    projectId: project_id,
                }, client);

                // SELESAIKAN TRANSAKSI DATABASE
                await client.query('COMMIT');

                console.log(`Successfully processed payment and started project for order_id: ${order_id}`);

            } catch (e) {
                // Jika terjadi error di dalam blok try, batalkan semua perubahan
                console.error(`Database transaction failed for order_id: ${order_id}`, e);
                // Pastikan client ada sebelum mencoba rollback
                if (client) {
                    await client.query('ROLLBACK');
                }
                throw e; // Lempar error untuk ditangkap oleh blok catch luar
            }
        }

        // 3. Selalu respon 200 OK ke Midtrans jika signature valid, agar tidak dikirim ulang.
        res.status(200).json({ message: 'Notification received successfully.' });

    } catch (error) {
        // Tangani error umum (misal: verifikasi signature gagal atau error transaksi)
        console.error('Webhook processing error:', error.message);
        res.status(500).json({ message: 'Internal Server Error' });
    } finally {
        // 4. Selalu lepaskan koneksi client kembali ke pool jika sudah didapatkan.
        // Ini SANGAT PENTING untuk mencegah kebocoran koneksi.
        if (client) {
            client.release();
        }
    }
};