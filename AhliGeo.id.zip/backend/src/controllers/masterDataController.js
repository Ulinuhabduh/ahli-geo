// src/controllers/masterDataController.js
import db from '../db/index.js'; // For fetching skills/software from DB
import { v4 as uuidv4 } from 'uuid'

// Example: Locations might be predefined for now if not in DB
const PREDEFINED_LOCATIONS = [
    "Jakarta, Indonesia",
    "Bandung, Indonesia",
    "Surabaya, Indonesia",
    "Yogyakarta, Indonesia",
    "Medan, Indonesia",
    "Makassar, Indonesia",
    "Semarang, Indonesia",
    "Palembang, Indonesia",
    "Remote"
];

export const getAllSkills = async (req, res, next) => {
    try {
        const { rows } = await db.query('SELECT id, name FROM skills ORDER BY name ASC');
        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching skills:", error.message, error.stack);
        next(error);
    }
};

export const getAllSoftware = async (req, res, next) => {
    try {
        const { rows } = await db.query('SELECT id, name FROM software ORDER BY name ASC');
        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching software:", error.message, error.stack);
        next(error);
    }
};

export const getAllLocations = async (req, res, next) => {
    try {
        // For now, returning a predefined list.
        // If you create a 'locations' table in your DB, query it here instead.
        res.status(200).json(PREDEFINED_LOCATIONS);
    } catch (error) { // Unlikely to error with predefined list, but good practice
        console.error("Error fetching locations:", error.message, error.stack);
        next(error);
    }
};

// Fungsi generik untuk membuat master data baru
const createMasterDataItem = (tableName) => async (req, res, next) => {
    const { name } = req.body;
    if (!name || !name.trim()) {
        return res.status(400).json({ message: 'Name is required.' });
    }

    const itemName = name.trim();

    try {
        // 1. Cek apakah item dengan nama yang sama sudah ada (case-insensitive)
        const checkRes = await db.query(`SELECT * FROM ${tableName} WHERE LOWER(name) = LOWER($1)`, [itemName]);
        if (checkRes.rowCount > 0) {
            // Jika sudah ada, kembalikan data yang ada
            return res.status(200).json(checkRes.rows[0]);
        }
        
        // 2. Jika belum ada, buat yang baru
        const newId = uuidv4();
        const insertRes = await db.query(
            `INSERT INTO ${tableName} (id, name) VALUES ($1, $2) RETURNING *`,
            [newId, itemName]
        );
        
        res.status(201).json(insertRes.rows[0]);

    } catch (error) {
        next(error);
    }
};

export const uploadImage = (req, res) => {
    if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded.' });
    }
    // `req.file.path` akan berisi URL aman dari Cloudinary
    res.status(200).json({ imageUrl: req.file.path });
};

export const createSkill = createMasterDataItem('skills');
export const createSoftware = createMasterDataItem('software');