
// ahli_geo_backend/src/controllers/authController.js
import User from '../models/User.js';
import ExpertProfile from '../models/ExpertProfile.js'; // Pastikan ExpertProfile diimpor
import { hashPassword, comparePassword } from '../utils/passwordUtils.js';
import { generateToken } from '../utils/jwtUtils.js';
// Kita akan menggunakan ExpertProfile.createOrUpdate langsung jika memungkinkan,
// atau membuat fungsi helper jika diperlukan.
// import { handleExpertProfileSetupData } from './expertController.js'; // Mungkin tidak perlu jika ExpertProfile.createOrUpdate cukup

export const register = async (req, res, next) => {
    console.log("Register endpoint hit. Request body:", JSON.stringify(req.body, null, 2));
    const {
        email, name, password, role,
        // Expert specific fields from frontend (RegisterPage.tsx)
        headline, location, experienceYears, bio, profileImageUrl, hourlyRate,
        skillIds, // Array of string IDs
        softwareIds, // Array of string IDs
        // Client specific fields
        companyName
    } = req.body;

    if (!email || !name || !password || !role) {
        return res.status(400).json({ message: 'Fields email, name, password, and role are required' });
    }
    if (password.length < 6) {
        return res.status(400).json({ message: 'Password must be at least 6 characters long' });
    }
    if (!['client', 'expert'].includes(role)) {
        return res.status(400).json({ message: 'Invalid role specified. Must be "client" or "expert".' });
    }

    try {
        const existingUser = await User.findByEmail(email);
        if (existingUser) {
            return res.status(400).json({ message: 'Email already registered' });
        }

        const hashedPassword = await hashPassword(password);
        // Create user in users table
        const newUserInUserTable = await User.create({
            email,
            name,
            password_hash: hashedPassword,
            role,
            // company_name diatur oleh User.create jika role adalah client
            company_name: role === 'client' ? companyName : null,
        });

        let finalUserResponse = { ...newUserInUserTable }; // Start with basic user data

        // If the role is 'expert', create their expert profile
        if (role === 'expert') {
            if (!headline || !location || experienceYears === undefined || !bio) {
                // Hapus user yang baru saja dibuat karena setup profil expert gagal karena data kurang
                // Ini penting untuk konsistensi data, atau buat transaksi database
                // await User.deleteById(newUserInUserTable.id); // Anda perlu menambahkan fungsi deleteById di User model
                console.warn("Expert registration: Missing required profile fields (headline, location, experienceYears, bio). User created, but profile incomplete.");
                // return res.status(400).json({ message: 'Expert profile fields (headline, location, experienceYears, bio) are required.' });
                // Untuk sekarang, biarkan user dibuat, tapi profil tidak akan lengkap. Frontend seharusnya sudah memvalidasi ini.
            }

            const expertProfileData = {
                headline,
                location,
                experience_years: parseInt(experienceYears, 10) || 0,
                bio,
                profile_image_url: profileImageUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random&size=200`,
                hourly_rate: hourlyRate ? parseInt(hourlyRate, 10) : null,
                // Ubah skillIds dan softwareIds menjadi array objek {id: string} yang diharapkan oleh ExpertProfile.createOrUpdate
                skills: Array.isArray(skillIds) ? skillIds.map(id => ({ id })) : [],
                software: Array.isArray(softwareIds) ? softwareIds.map(id => ({ id })) : [],
                verified: false, // Default saat registrasi
                rating: null,    // Default saat registrasi
            };

            // Membuat atau memperbarui profil expert dan menangani skills/software
            // User ID dari newUserInUserTable.id
            await ExpertProfile.createOrUpdate(newUserInUserTable.id, expertProfileData);

            // Tandai profile_setup_completed menjadi true di tabel users untuk expert
            // karena registrasi sudah mencakup detail profil
            const updatedUser = await User.updateProfile(newUserInUserTable.id, { profile_setup_completed: true });
            if (updatedUser) {
                finalUserResponse = { ...finalUserResponse, ...updatedUser }; // Gabungkan update dari users table
            }

            // Ambil profil expert yang lengkap (termasuk data dari users dan expert_profiles) untuk respons
            const fullExpertProfile = await ExpertProfile.findById(newUserInUserTable.id);
            if (fullExpertProfile) {
                finalUserResponse = fullExpertProfile; // Ini seharusnya sudah berisi semua data gabungan
            }
        } else if (role === 'client') {
            // Untuk client, profil setup juga dianggap selesai karena field companyName sudah dihandle
            const updatedUser = await User.updateProfile(newUserInUserTable.id, { profile_setup_completed: true });
            if (updatedUser) {
                finalUserResponse = { ...finalUserResponse, ...updatedUser };
            }
        }


        // Hapus password_hash dari respons akhir jika masih ada
        delete finalUserResponse.password_hash;


        const tokenPayload = { userId: finalUserResponse.id, email: finalUserResponse.email, role: finalUserResponse.role, name: finalUserResponse.name };
        const token = generateToken(tokenPayload);

        res.status(201).json({
            message: 'User registered successfully',
            user: finalUserResponse, // Kirim data pengguna yang sudah lengkap
            token,
        });
    } catch (error) {
        console.error("Register controller error:", error.message, error.stack);
        next(error);
    }
};

export const login = async (req, res, next) => {
    console.log("Login endpoint hit. Request body:", req.body);
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: 'Email and password are required' });
    }

    try {
        const userFromDb = await User.findByEmail(email);
        if (!userFromDb) {
            return res.status(401).json({ message: 'Invalid email or password (user not found)' });
        }

        const isMatch = await comparePassword(password, userFromDb.password_hash);
        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid email or password (password mismatch)' });
        }

        let userResponseData = { ...userFromDb };
        delete userResponseData.password_hash; // Hapus hash dari data respons

        // Jika expert, gabungkan dengan data dari expert_profiles
        if (userResponseData.role === 'expert') {
            const expertFullProfile = await ExpertProfile.findById(userResponseData.id);
            if (expertFullProfile) {
                userResponseData = expertFullProfile; // Ganti dengan profil lengkap
            } else {
                // Ini bisa terjadi jika expert_profiles belum dibuat, meskipun seharusnya sudah
                // jika profile_setup_completed adalah true.
                console.warn(`Expert user ${userResponseData.id} logged in, but no full expert profile found. Sending basic user data.`);
            }
        }

        // Pastikan profile_setup_completed ada di userResponseData
        // Jika tidak, ambil dari userFromDb (sebelum diganti oleh expertFullProfile yang mungkin belum ada)
        if (userResponseData.profile_setup_completed === undefined) {
            userResponseData.profile_setup_completed = userFromDb.profile_setup_completed;
        }


        const tokenPayload = { userId: userResponseData.id, email: userResponseData.email, role: userResponseData.role, name: userResponseData.name };
        const token = generateToken(tokenPayload);

        res.status(200).json({
            message: 'Login successful',
            token,
            user: userResponseData,
        });
    } catch (error) {
        console.error("Login controller error:", error.message, error.stack);
        next(error);
    }
};

export const getMe = async (req, res, next) => {
    console.log("GetMe endpoint hit. User from token (req.user):", req.user);
    try {
        if (!req.user || !req.user.userId) {
            return res.status(401).json({ message: 'Not authorized, user data missing from token payload' });
        }

        let userProfile;
        if (req.user.role === 'expert') {
            userProfile = await ExpertProfile.findById(req.user.userId);
            if (!userProfile) {
                // Jika profil expert tidak ada, fallback ke data user dasar
                // Ini bisa terjadi jika profil belum sepenuhnya dibuat
                console.warn(`Expert user ${req.user.userId} requested, but ExpertProfile not found. Fetching basic user data.`);
                userProfile = await User.findById(req.user.userId);
            }
        } else {
            userProfile = await User.findById(req.user.userId);
        }

        if (!userProfile) {
            return res.status(404).json({ message: 'User not found in database' });
        }

        // Hapus password_hash jika ada di objek userProfile (seharusnya tidak jika dari findById yang aman)
        delete userProfile.password_hash;

        res.status(200).json(userProfile);
    } catch (error) {
        console.error("GetMe controller error:", error.message, error.stack);
        next(error);
    }
};

// Fungsi setupProfile tetap ada untuk pembaruan profil pasca-registrasi jika diperlukan,
// tetapi registrasi sekarang harusnya sudah 'setup completed'.
export const setupProfile = async (req, res, next) => {
    const userId = req.user?.userId;
    const userRole = req.user?.role;
    const {
        name, companyName, // Common user fields
        headline, location, experienceYears, bio, hourlyRate,
        skills, // Array of skill objects or IDs {id: "..."}
        software, // Array of software objects or IDs {id: "..."}
        profileImageUrl
    } = req.body;

    console.log("SetupProfile endpoint hit for userId:", userId, "role:", userRole);
    console.log("Request body for setup:", JSON.stringify(req.body, null, 2));

    if (!userId) {
        return res.status(401).json({ message: 'User not authenticated for profile setup.' });
    }

    try {
        let userTableUpdateData = { profile_setup_completed: true }; // Setup selalu menandai completed
        if (name !== undefined && name.trim() !== "") userTableUpdateData.name = name.trim();

        if (userRole === 'client') {
            if (companyName !== undefined) userTableUpdateData.company_name = companyName.trim();
        } else if (userRole === 'expert') {
            // Data untuk ExpertProfile.createOrUpdate
            const expertSpecificDataForUpdate = {
                headline: headline?.trim(),
                location,
                experience_years: experienceYears !== undefined ? parseInt(experienceYears, 10) : undefined,
                bio: bio?.trim(),
                hourly_rate: hourlyRate !== undefined ? parseInt(hourlyRate, 10) : undefined,
                // skills dan software harus berupa array objek {id: string}
                skills: Array.isArray(skills) ? skills : [], // Pastikan array
                software: Array.isArray(software) ? software : [], // Pastikan array
                profile_image_url: profileImageUrl?.trim()
            };
            // Filter out undefined values so they don't overwrite existing db values with null
            const definedExpertData = Object.fromEntries(
                Object.entries(expertSpecificDataForUpdate).filter(([_, v]) => v !== undefined)
            );

            if (Object.keys(definedExpertData).length > 0) {
                await ExpertProfile.createOrUpdate(userId, definedExpertData);
            }
        } else {
            return res.status(400).json({ message: 'Invalid user role for profile setup.' });
        }

        const updatedUserInUserTable = await User.updateProfile(userId, userTableUpdateData);
        if (!updatedUserInUserTable) {
            return res.status(404).json({ message: 'User record not found for final update in users table.' });
        }

        // Ambil profil yang sudah lengkap dan terbaru untuk respons
        let finalUserResponse;
        if (userRole === 'expert') {
            finalUserResponse = await ExpertProfile.findById(userId);
        } else { // client or other roles
            finalUserResponse = await User.findById(userId);
        }

        if (!finalUserResponse) {
            console.error(`Failed to fetch final user profile for ${userId} after setup.`);
            return res.status(500).json({ message: 'Profile updated, but failed to retrieve final profile.' });
        }

        delete finalUserResponse.password_hash;


        res.status(200).json({
            message: 'Profile setup/update complete.',
            user: finalUserResponse
        });
    } catch (error) {
        console.error("SetupProfile controller error:", error.message, error.stack);
        next(error);
    }
};
