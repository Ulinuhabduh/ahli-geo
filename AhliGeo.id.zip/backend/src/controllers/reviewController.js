// backend/src/controllers/reviewController.js
import Review from '../models/Review.js';
import Project from '../models/Project.js';

export const createReview = async (req, res, next) => {
    try {
        const { projectId, rating, comment } = req.body;
        const reviewerId = req.user.userId;

        // 1. Validasi Input
        if (!projectId || !rating) {
            return res.status(400).json({ message: 'Project ID and rating are required.' });
        }

        // 2. Dapatkan detail proyek
        const project = await Project.findById(projectId);
        if (!project) {
            return res.status(404).json({ message: 'Project not found.' });
        }

        // 3. Validasi Logika Bisnis
        if (project.status !== 'Completed') {
            return res.status(403).json({ message: 'Reviews can only be left for completed projects.' });
        }

        const isClientReviewing = project.clientId === reviewerId;
        const isExpertReviewing = project.assignedExpertId === reviewerId;

        if (!isClientReviewing && !isExpertReviewing) {
            return res.status(403).json({ message: 'You are not part of this project.' });
        }

        const hasReviewed = await Review.hasUserReviewed(projectId, reviewerId);
        if (hasReviewed) {
            return res.status(400).json({ message: 'You have already reviewed this project.' });
        }

        // Tentukan siapa yang di-review
        const revieweeId = isClientReviewing ? project.assignedExpertId : project.clientId;

        // 4. Buat Review
        const newReview = await Review.create({
            projectId,
            reviewerId,
            revieweeId,
            rating,
            comment,
        });

        // TODO: Tambahkan logika untuk update rating rata-rata di tabel expert_profiles

        res.status(201).json(newReview);
    } catch (error) {
        next(error);
    }
};

export const getReviewsForUser = async (req, res, next) => {
    try {
        const { userId } = req.params;
        const reviews = await Review.findByRevieweeId(userId);
        res.status(200).json(reviews);
    } catch (error) {
        next(error);
    }
}