// backend/hash-password.js
import bcrypt from 'bcryptjs';

// Ambil password dari argumen command line
const password = 'ahligeosemogasukses2030';

if (!password) {
    console.error('Please provide a password as an argument.');
    console.log('Usage: node hash-password.js "YourSecurePassword"');
    process.exit(1);
}

const salt = bcrypt.genSaltSync(10);
const hash = bcrypt.hashSync(password, salt);

console.log('Password:', password);
console.log('Generated Hash:', hash);