// ahli_geo_backend/server.js

// ES Module Imports
import config from './src/config/index.js'; // Make sure config/index.js uses 'export default'
import express from 'express';
import cors from 'cors';
import mainApiRouter from './src/routes/index.js'; // Changed variable name for clarity
import { errorHandler, notFound } from './src/middleware/errorMiddleware.js';
import db from './src/db/index.js';

const app = express();

// Middleware
app.use(cors()); // Enable Cross-Origin Resource Sharing
app.use(express.json()); // To parse JSON request bodies
app.use(express.urlencoded({ extended: true })); // To parse URL-encoded request bodies

// Test DB connection (optional, good for immediate feedback)
db.query('SELECT NOW()', (err, dbResponse) => { // Renamed 'res' to 'dbResponse' to avoid conflict
    if (err) {
        console.error('Error connecting to database on startup:', err.stack);
    } else {
        if (dbResponse && dbResponse.rows && dbResponse.rows.length > 0) {
            console.log('Database responded at:', dbResponse.rows[0].now);
        } else {
            console.log('Database responded but no rows returned from SELECT NOW() or response structure unexpected.');
        }
    }
});

// API Routes - Prefix all API routes with /api/v1
app.use('/api/v1', mainApiRouter);

// Simple root route for basic server health check
app.get('/', (req, res) => { // Renamed 'res' inside route handler
    res.send(`Ahli Geo Backend is running in ${config.nodeEnv} mode!`);
});

// Error Handling Middleware (must be defined AFTER all other routes and middleware)
app.use(notFound); // Handles requests to routes that don't exist (404)
app.use(errorHandler); // Handles all other errors passed via next(error)

const PORT = config.port;

app.listen(PORT, () => {
    console.log(`Server running in ${config.nodeEnv} mode on port ${PORT}`);
    console.log(`JWT Secret Loaded: ${config.jwtSecret ? 'Yes' : 'NO (CRITICAL!)'}`);
    console.log(`Database URL Loaded: ${config.databaseUrl ? 'Yes' : 'NO (CRITICAL!)'}`);
});